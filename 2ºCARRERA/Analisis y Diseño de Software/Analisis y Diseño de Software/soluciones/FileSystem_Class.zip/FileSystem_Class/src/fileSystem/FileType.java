package fileSystem;

public enum FileType {
	R, RW, W
}
