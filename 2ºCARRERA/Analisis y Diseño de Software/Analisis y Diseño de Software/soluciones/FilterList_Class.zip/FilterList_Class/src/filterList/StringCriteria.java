package filterList;

public abstract class StringCriteria {
	public abstract boolean test(String s);
}
