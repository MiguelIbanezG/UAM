package ejemplos;

public class Happy2018 {

	public static void main(String... args) {
	    System.out.println("Happy 2018!" ); 
	  }


}
