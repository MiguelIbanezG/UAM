package ejemplos;

import java.time.LocalDate;

public class HappyNewYear {

	public static void main(String... args) {
		System.out.println("Happy " + LocalDate.now().getYear() );
	}

}
