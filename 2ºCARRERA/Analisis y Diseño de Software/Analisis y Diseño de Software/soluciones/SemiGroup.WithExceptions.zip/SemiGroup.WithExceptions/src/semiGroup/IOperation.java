package semiGroup;

public interface IOperation {
	Integer operate (Integer a, Integer b);
}
