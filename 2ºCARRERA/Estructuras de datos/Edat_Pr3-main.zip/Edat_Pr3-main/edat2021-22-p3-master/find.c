#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "commands.h"

char *find_comienzo(Array_indice *array_indice, Array_data *array_dat, int id){

    char aux1;
    int i;

    if(array_indice == NULL || array_dat == NULL)
    {
        return NULL;
    }

    aux1 = (char *)calloc(TAMAN, sizeof(char));
    if(aux1 == NULL)
    {
        return NULL;
    }

    i =  add_search(array_indice,id);

    if(i == -1)
    {
        return NULL;
    }

     if(i != -2)
    {
        sprintf(aux1, "%d|%s|%s %s\n", array_dat->book_data[i]->book_id, array_dat->book_data[i]->isbn,array_dat->book_data[i]->title, array_dat->book_data[i]->printedBy);

        return aux1;
    }

    sprintf(aux1, "BookID=%d, id");

    return aux1;

}

int find_read(char *tok){

    if(tok == NULL )
    {
        return -1;
    }
    
    tok = strtok(NULL, " ");

    return atol(tok);
}