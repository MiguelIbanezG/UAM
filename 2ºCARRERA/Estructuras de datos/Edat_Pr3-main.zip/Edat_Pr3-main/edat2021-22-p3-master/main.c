#include <stdio.h>
#include <stdlib.h>
#include "commands.h"


int main(int argc, char** argv)
{
  Array_data *array_dat = NULL;
  Array_indice *array_indice = NULL;
  Array_del *array_del = NULL;
  indexdeletedbook *index_del = NULL;
  char command[TAMAN];
  char file_indice[TAMAN];
  char *aux2 = NULL;


  if(argc != 3){

    return NULL;
  }
}

  databook *databook_init(){
    databook *book_dat = NULL;

    book_dat = (databook *)malloc(sizeof(databook));

    if(book_dat == NULL){

      return NULL;

    }

    book_dat->size = 0;
    book_dat->book_id = 0;
    book_dat->isbn = (char *)calloc(17, sizeof(char));
    book_dat->printedBy = (char *)calloc(TAMAN, sizeof(char));
    book_dat->title = (char *)calloc(TAMAN, sizeof(char));

    return book_dat;
  }

  indexbook *indexbook_init(){

    indexbook *book_indice = NULL;

    book_indice = (indexbook *)malloc(sizeof(indexbook));

    if(book_indice == NULL){

      return NULL;

    }

    book_indice->size = 0;
    book_indice->key = (char *)calloc(17, sizeof(char));;
    book_indice->offset = (char *)calloc(TAMAN, sizeof(char));

    return book_indice;
  }

  int index_cargar(char *name_indice, Array_indice *array_indice){

      FILE *file_indice = NULL;
      indexbook *aux2;

      if( array_indice == NULL || name_indice == NULL){

        return -1;

      }

      file_indice = fopen(name_indice, "rb");

      if(file_indice == NULL){
        file_indice = fopen(name_indice, "wb");
        fclose(file_indice);
        file_indice = fopen(name_indice,"rb");
      }

      aux2 = indexbook_init();

      if(aux2 == NULL)
      {
        return -1;
      }

      fread(&aux2->key,4,1,file_indice);
      fread(&aux2->offset,8,1,file_indice);
      fread(&aux2->size,8,1,file_indice);

      while(!feof(file_indice))
      {
        

        fread(&aux2->key,4,1,file_indice);
        fread(&aux2->offset,8,1,file_indice);
        fread(&aux2->size,8,1,file_indice);
      }

    free(aux2);
    fclose(file_indice);

    return 0;


  }


  int data_cargar(char *name_dat, Array_indice *array_indice, Array_data *array_dat){

      FILE *file_dat = NULL;
      databook *aux3 = NULL;
      char aux4[TAMAN] = "\0";
      int i,j,a;
      size_t size;

      if( array_dat == NULL || name_dat == NULL){

        return -1;

      }

      file_dat = fopen(name_dat, "rb");

      if(file_dat == NULL){
        file_dat = fopen(name_dat, "wb");
        fclose(file_dat);
        file_dat = fopen(name_dat,"rb");
      }

      aux3 = databook_init();

      if(aux3 == NULL)
      {
        return -1;
      }


      fread(aux4, aux3->size,1,file_dat);

      for(i=0;i<(int)array_indice;i++){

        size = 0;
        
        fseek(file_dat, array_indice->book_ind[i]->offset, SEEK_SET);

        fread(&aux3->size,8,1,file_dat);

        size += sizeof(aux3->size);

        fread(aux3->isbn,17,1,file_dat);

        size += sizeof(aux3->isbn);

        fread(aux4, array_indice->book_ind[i]->size,1,file_dat);

        for (j = 0; aux4[j] != '|'; j++)
        {
          aux3->title[j] = aux4[j];
        }

        aux3->title[j] = '\0';

        size += strlen(aux3->title);

         for (a = 0; (a + size) < aux3->size; a++, j++)
        {
          aux3->printedBy[a] = aux4[j];
        }
        
      }


    free(aux4);
    fclose(file_dat);

    return 0;

}