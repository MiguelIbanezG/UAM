#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "commands.h"

Array_data *init_array_data(size_t size){

    int i=0;
    Array_data *array_dat;

    array_dat = (Array_data *)malloc(sizeof(array_dat));

    if(array_dat == NULL){

        return NULL;

    }

    array_dat->book_data = (databook **)calloc(size, sizeof(databook));

    if(array_dat->book_data == NULL){

        return NULL;

    }

    for(i=0; i<size; i++){
        
        array_dat->book_data[i] = NULL;
    }

    array_dat->use = 0;
    array_dat->size = size;

    return array_dat;

}

Array_indice *init_array_indice(size_t size){

    int i=0;
    Array_indice *array_indice;

    array_indice = (Array_indice *)malloc(sizeof(array_indice));

    if(array_indice == NULL){

        return NULL;

    }

    array_indice->book_ind = (indexbook **)calloc(size, sizeof(indexbook));

    if(array_indice->book_ind == NULL){

        return NULL;

    }

    array_indice->use = 0;
    array_indice->size = size;

    return array_indice;

}

Array_del *init_array_delete(size_t size){

    int i=0;
    Array_del*array_del;

    array_del = (Array_del *)malloc(sizeof(array_del));

    if(array_del == NULL){

        return NULL;

    }

    array_del->book_del = (indexdeletedbook **)calloc(size, sizeof(indexdeletedbook));

    if(array_del->book_del == NULL){

        return NULL;

    }

    for(i=0; i<size; i++){
        
        array_del->book_del[i] = NULL;
    }

    array_del->use = 0;
    array_del->size = size;

    return array_del;

}

int copy_book(databook *book_dat, databook *book_dat1){

    if(book_dat == NULL || book_dat1 == NULL){
        return -1;
    }
    book_dat->size = book_dat1->size;
    book_dat->book_id = book_dat1->book_id;
    strcpy(book_dat->isbn, book_dat1->isbn);
    strcpy(book_dat->title, book_dat1->title);
    strcpy(book_dat->printedBy, book_dat1->printedBy);

    return 0;
}

