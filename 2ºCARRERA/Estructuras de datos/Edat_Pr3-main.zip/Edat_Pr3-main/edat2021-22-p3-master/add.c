#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "commands.h"

int add_search(Array_indice *array_indice, int book_id){
    int i = 0;
    int A = 0;
    int B = 0;
    int L = array_indice->use -1;

    if(array_indice == NULL || B > L || book_id < 0)
    {
        return NULL;
    }

    while(B<=L){
        
        i = B + (L-B)/2;

        if(array_indice->book_ind[i]->key == book_id && array_indice-> book_ind[i] != NULL)
        {
            return NULL;
        }
         
        if(array_indice->book_ind[i] == NULL || array_indice->book_ind[i]->key < book_id)
        {
            B = i +1;
        }
        else{
            L = i -1;
        }
    }

    return -2;
}

