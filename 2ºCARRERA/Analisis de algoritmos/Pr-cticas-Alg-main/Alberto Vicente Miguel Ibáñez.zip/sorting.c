/**
 *
 * Descripcion: Implementation of sorting functions
 *
 * Fichero: sorting.c
 * Autor: Carlos Aguirre
 * Version: 1.0
 * Fecha: 16-09-2019
 *
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "permutations.h"
#include "sorting.h"
#include <assert.h>

#define NDBUG

/***************************************************/
/* Function: InsertSort    Date:  06/10/2021       */
/* Authors: Alberto Vicente y Miguel Ibañez        */
/*                                                 */
/* Rutine that sort a permutation by               */
/* comparing elements in the array                 */
/*                                                 */
/* Input:                                          */
/* int* array: The permutation to sort             */
/* int ip: starting point in the array             */
/* int iu: last number in the array                */
/* Output:                                         */
/* int: obs needing                                */
/***************************************************/
int BubbleSort(int* array, int ip, int iu)
{
  int i, j, ob=0;

  assert(ip>=0);

  for(i=iu;i>ip;i--){
    for(j=ip;j<i;j++){
      ob++;
      if(array[j]>array[j+1]){
        swap(&array[j],&array[j+1]);
      }
    }
  }

  return ob;
}

int BubbleSortFlag(int* array, int ip, int iu)
{

  int flag=1, i, j, ob=0;

  assert(ip>=0);

  for(i=iu;flag==1 && i>ip;i--){
    flag=0;
    for(j=ip;j<i;j++){
      ob++;
      if(array[j]>array[j+1]){
        swap(&array[j],&array[j+1]);
        flag=1;
      }
    }
  }

  return ob;
}


