"""Implementatio of tic-tac-toe.

    Authors:
        Fabiano Baroni <fabiano.baroni@uam.es>,
        Alejandro Bellogin <alejandro.bellogin@uam.es>
        Alberto Suárez <alberto.suarez@uam.es>
"""

from __future__ import annotations  # For Python 3.7

import copy
from tkinter import *
from tkinter import messagebox
from typing import Any, Callable, List, Optional, Tuple

import numpy as np

from game import Player, TwoPlayerGame, TwoPlayerGameState


class TicTacToe(TwoPlayerGame):
    """Specific definitions for Tic-Tac-Toe."""

    def __init__(
        self,
        player1: Player,
        player2: Player,
        dim_board: int,
    ) -> None:
        super().__init__(
            "Tictactoe",
            player1,
            player2,
        )
        self.player1.label = 1
        self.player2.label = -1
        self.dim_board = dim_board
        self.max_score = 1
        self.min_score = -1

    # Private functions
    def _determine_player_label_complete_line(
        self,
        lines: List[np.ndarray],
    ) -> Optional[int]:

        player_label_complete_line = 0
        i = 0
        while (i < len(lines)) and (player_label_complete_line == 0):
            line = lines[i]
            i += 1
            unique_elements = np.unique(line)

            if (len(unique_elements) == 1) and (unique_elements[0] != 0):
                player_label_complete_line = unique_elements[0]
            else:
                player_label_complete_line = 0

        return player_label_complete_line

    def _player_label_to_index(self, label: int) -> int:
        return (1 - label) // 2

    # Public methods

    def initialize_board(self) -> np.ndarray:
        """Initialize board with standard configuration."""
        return np.zeros((self.dim_board, self.dim_board))


    def display(self, state: TwoPlayerGameState, gui: bool = False) -> None:
        """Display the game state."""
        super().display(state, gui)
        print(state.board)
        print()

    def generate_successors(
        self,
        state: TwoPlayerGameState,
    ) -> List[TwoPlayerGameState]:
        """Generate the list of successors of a game state."""
        successors = []

        n_rows, n_columns = np.shape(state.board)
        for i in range(n_rows):
            for j in range(n_columns):
                if (state.board[i, j] == 0):
                    # Prevent modification of the board
                    board_successor = copy.deepcopy(state.board)
                    assert isinstance(state.next_player, Player)
                    board_successor[i, j] = state.next_player.label
                    move_code = self._matrix_to_display_coordinates(i, j)
                    successor = state.generate_successor(
                        board_successor,
                        move_code,
                    )

                    successors.append(successor)

        return successors

    def _matrix_to_display_coordinates(
        self,
        i: int,
        j: int,
    ) -> str:
        return '({}, {})'.format(chr(ord('a') + i), j + 1)

    def score(
        self,
        state: TwoPlayerGameState,
    ) -> Tuple[bool, Optional[np.ndarray]]:
        """Determine whether a game state is terminal."""
        board = state.board
        diagonal = np.diagonal(board)
        reverse_diagonal = np.diagonal(np.fliplr(board))

        lines = [diagonal, reverse_diagonal]

        n_rows, n_columns = np.shape(board)

        for i in range(n_rows):
            lines.append(board[i, :])
        for j in range(n_columns):
            lines.append(board[:, j])

        player_label_complete_line = (
            self._determine_player_label_complete_line(lines)
        )

        end_of_game = (
            (player_label_complete_line != 0)  # player has completed a line
            or np.all(board != 0)  # Board is full
        )

        scores = np.zeros(self.n_players, dtype=float)
        players = (self.player1, self.player2)
        for player in players:
            if player_label_complete_line == player.label:
                scores[self._player_label_to_index(player.label)] = 1

        return end_of_game, scores

    def initialize_buttons(self, board: Any, gui_frame) -> Any:
        gui_buttons = {}
        # Put buttons and labels the first time this is called
        for row in range(-1, self.dim_board):
            for col in range(-1, self.dim_board):
                piece = Label(gui_frame)  # Dummy piece
                if col > -1 and row > -1:  # Actual buttons
                    color = ""
                    status = DISABLED
                    if board[row, col] == self.player1.label:
                        color = "white"
                    elif board[row, col] == self.player2.label:
                        color = "black"
                    else:
                        color = "green"
                        status = NORMAL
                    piece = Button(gui_frame, bg=color, state=status)
                    gui_buttons[(row, col)] = piece  # Record button
                if col == -1 and row > -1:  # Vertical number axis
                    row_label = chr(ord('a') + row)
                    piece = Label(gui_frame, text=row_label)
                if row == -1 and col > -1:  # Horizontal number axis
                    col_label = col + 1
                    piece = Label(gui_frame, text=col_label)
                # Place piece
                piece.grid(row=row+1, column=col+1)
        return gui_buttons

    def gui_update(self, state: TwoPlayerGameState, gui_buttons, gui_root, moves: list = [], click_function = None) -> None:
        board = state.board
        for row in range(0, self.dim_board):
            for col in range(0, self.dim_board):
                pos = (row, col)
                move_code = self._matrix_to_display_coordinates(row, col)
                if move_code in moves:  # Valid moves
                    gui_buttons[pos].configure(
                        bg="blue" if state.next_player.label == self.player1.label else "red", state=NORMAL)
                    if click_function:
                        gui_buttons[pos].bind(
                            "<Button-1>",
                            lambda event, move=move_code: click_function(move),
                        )
                else:  # Black and white
                    if board[pos] == self.player1.label:
                        color = "white"
                    elif board[pos] == self.player2.label:
                        color = "black"
                    else:
                        color = "green"
                    gui_buttons[pos].configure(bg=color, state=DISABLED)
        gui_root.update()  # Refresh UI

"""
class Solution1(StudentHeuristic):
  def get_name(self) -> str:
    return "solution1"
  def evaluation_function(self, state: TwoPlayerGameState) -> float:
    # let's use an auxiliary function
    if state.end_of_game:
      finalscore = state.scores[0] - state.scores[1]
      if state.is_player_max(state.player1):
        value = finalscore
      elif state.is_player_max(state.player2):
        value = - finalscore
    else:
      valueplayer1 = 0
      valueplayer2 = 0
      for i in range(0, 7):
        for j in range(0, 7):
          if state.board.get((i, j)) == state.player1.label:
            valueplayer1 += self.distanceToCorner(i, j)
          elif state.board.get((i, j)) == state.player2.label:
            valueplayer2 += self.distanceToCorner(i, j)
      
      if state.is_player_max(state.player1):
        value = valueplayer2 - valueplayer1
      elif state.is_player_max(state.player2):
        value = valueplayer1 - valueplayer2
            
    return value

  def distanceToCorner(self, x: int, y: int) -> float:
    distances = list()
    firstcorner = np.square(pow(0 - x, 2) + pow(0 - y, 2))
    distances.append(firstcorner)
    secondcorner = np.square(pow(7 - x, 2) + pow(0 - y, 2))
    distances.append(secondcorner)
    thirdcorner = np.square(pow(0 - x, 2) + pow(7 - y, 2))
    distances.append(thirdcorner)
    fourthcorner = np.square(pow(7 - x, 2) + pow(7 - y, 2))
    distances.append(fourthcorner)

    return min(distances)
"""

"""class Solution1(StudentHeuristic):
  def get_name(self) -> str:
    return "SINCOPE"
  def evaluation_function(self, state: TwoPlayerGameState) -> float:
    if not state:
      return None

    tablero = from_dictionary_to_array_board(state.board, 8, 8)

    if state.is_player_max(state.next_player):
      jugador = state.next_player.label
      if state.previous_player:
        contrario = state.previous_player.label
      else:
        contrario = None
    else:
      if state.previous_player:
        jugador = state.previous_player.label
      else:
        jugador = None
      contrario = state.next_player.label
    
    esquinas = ((0,0), (0,7), (7,0), (7,7))
    casillas1 = ((1,1), (1,6), (6,1), (6,6))
    casillas2 = ((2,2), (5,5), (2,5), (5,2))
    casillas3 = ((0,1), (1,0), (1,7), (0,6), (7,1), (6,0), (7,6), (6,7))
    casillas4 = ((0,2), (2,0), (0,5), (5,0), (7,2), (2,7), (7,5), (5,7))
    casillas5 = ((0,3), (3,0), (0,4), (4,0), (7,3), (3,7), (7,4), (4,7))
    casillas6 = ((2,3), (3,2), (2,4), (4,2), (5,3), (3,5), (5,4), (4,5))
    casillas7 = ((1,2), (1,5), (6,2), (6,5), (2,1), (2,6), (5,1), (5,6))
    casillas8 = ((1,3), (1,4), (6,3), (6,4), (3,1), (3,6), (4,1), (4,6))

    valor = 999

    for casilla in esquinas:
      if tablero[casilla[0]][casilla[1]] == jugador:
        valor += 100
      elif tablero[casilla[0]][casilla[1]] == contrario:
        valor -= 100
      
    for casilla in casillas1:
      if tablero[casilla[0]][casilla[1]] == jugador:
        valor += 35
      elif tablero[casilla[0]][casilla[1]] == contrario:
        valor -= 35

    for casilla in casillas2:
      if tablero[casilla[0]][casilla[1]] == jugador:
        valor += 15
      elif tablero[casilla[0]][casilla[1]] == contrario:
        valor -= 15
      
    for casilla in casillas3:
      if tablero[casilla[0]][casilla[1]] == jugador:
        valor += 20
      elif tablero[casilla[0]][casilla[1]] == contrario:
        valor -= 20
    
    for casilla in casillas4:
      if tablero[casilla[0]][casilla[1]] == jugador:
        valor += 25
      elif tablero[casilla[0]][casilla[1]] == contrario:
        valor -= 25

    for casilla in casillas5:
      if tablero[casilla[0]][casilla[1]] == jugador:
        valor += 10
      elif tablero[casilla[0]][casilla[1]] == contrario:
        valor -= 10
    
    for casilla in casillas6:
      if tablero[casilla[0]][casilla[1]] == jugador:
        valor += 5
      elif tablero[casilla[0]][casilla[1]] == contrario:
        valor -= 5

    for casilla in casillas7:
      if tablero[casilla[0]][casilla[1]] == jugador:
        valor += -5
      elif tablero[casilla[0]][casilla[1]] == contrario:
        valor -= -5

    for casilla in casillas8:
      if tablero[casilla[0]][casilla[1]] == jugador:
        valor += -5
      elif tablero[casilla[0]][casilla[1]] == contrario:
        valor -= -5

    return valor"""
