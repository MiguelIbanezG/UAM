"""
@author: Mario Garcia Iribas
@notas: 
"""
from __future__ import annotations  # For Python 3.7
import timeit
from importlib import import_module
mod = import_module('1322_p2_03_Garcia_Ibáñez', package=None)
my_heuristic = mod.Solution1()
from game import Player, TwoPlayerGameState, TwoPlayerMatch
from heuristic import heuristic
from simple_game_tree import SimpleGameTree
from strategy import (
    MinimaxAlphaBetaStrategy,
    MinimaxStrategy,
)

# Define players

player1_minimax = Player(
    name='Minimax 1',
    strategy=MinimaxStrategy(
        heuristic=my_heuristic,
        max_depth_minimax=4,
        verbose=3,
    ),
)

player2_minimax = Player(
    name='Minimax 4',
    strategy=MinimaxStrategy(
        heuristic=heuristic,
        max_depth_minimax=4,
        verbose=3,
    ),
)

player1_minimax_alpha_beta = Player(
    name='Minimax + alpha-beta 1',
    strategy=MinimaxAlphaBetaStrategy(
        heuristic=heuristic,
        max_depth_minimax=4,
        verbose=3,
    ),
)


player2_minimax_alpha_beta = Player(
    name='Minimax + alpha-beta 2',
    strategy=MinimaxAlphaBetaStrategy(
        heuristic=heuristic,
        max_depth_minimax=4,
        verbose=3,
    ),
)

# Select players

# player1, player2 = player1_minimax, player2_minimax


player1, player2 = player1_minimax_alpha_beta, player2_minimax_alpha_beta


game = SimpleGameTree(
    player1=player1,
    player2=player2,
)

"""
Here you can initialize the board and the player who moves first
to any valid state; e.g., it can be an intermediate state.
"""

# Select initial player

initial_player = player1

# Setup and play match

game_state = TwoPlayerGameState(
    game=game,
    initial_player=initial_player,
    board='A',
)

match = TwoPlayerMatch(
    game_state,
    max_seconds_per_move=10000,
)


tiempo = timeit.timeit('scores = match.play_match()', globals=globals() ,number=50)
time = tiempo / 50

player1, player2 = player1_minimax_alpha_beta, player2_minimax_alpha_beta

tiempo2 = timeit.timeit('scores = match.play_match()', globals=globals(), number=50)
time2 = tiempo2 / 50


resta = time2 - time

print("La media del MinimaxAlphaBeta en 50 ejecuciones es " + str(time2))
print("La media del Minimax en 50 ejecuciones es " + str(time))
print("La diferencia de tiempo entre MinimaxAlphabeta y Minimax es: MinimaxAlphabeta - Minimax= " + str(resta))