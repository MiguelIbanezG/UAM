1. Explore the demos.
1.1 Play matches among different players with different strategies (manual, random, minimax, minimax with alpha beta pruning). Some demos will fail because the minimax with alpha beta pruning is not implemented. Fix them by changing the players.
1.2 Setup and play match from an intermediate game state.
1.3 Setup and play a tournament.

2. Implement and analyze alpha-beta pruning in strategy.py
   Look for comment # NOTE <YOUR CODE HERE>

3. Design your own reversi players to participate in the tournaments.
