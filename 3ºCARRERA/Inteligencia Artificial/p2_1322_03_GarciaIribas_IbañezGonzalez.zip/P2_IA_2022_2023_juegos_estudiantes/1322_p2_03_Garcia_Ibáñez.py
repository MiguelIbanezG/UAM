from game import (
    TwoPlayerGameState,
)
from heuristic import (
    simple_evaluation_function,
)
from tournament import (
    StudentHeuristic,
)

from reversi import (
  from_dictionary_to_array_board,
)

import numpy as np

class Solution1(StudentHeuristic):
  def get_name(self) -> str:
    return "Heuristica_final"
  def evaluation_function(self, state: TwoPlayerGameState) -> float:
    tablero = from_dictionary_to_array_board(state.board, 8, 8)
    if(state.is_player_max(state.next_player)):
      firstP = state.next_player.label
      if not state.previous_player:
        secP = None
      else:
        secP = state.previous_player.label
    else:
      if not state.previous_player:
        firstP = None
      else:
        firstP = state.previous_player.label
      secP = state.next_player.label

    HORIZ = [-1, -1, 0, 1, 1, 1, 0, -1]
    VERTI = [0, 1, 1, 1, 0, -1, -1, -1]
    MATRIZ = [[95, -35,  7,  3,  3, 7, -35, 95], [-35,  -35, -9, -9, -9, -9, -35,  -35], [7,   -9,  -1,  -6,  -6,  -1, -9, 7], [3,   -9,  -4,  -6,  -6,  -4, -9,   3], [3,   -9,  -4,  -6,  -6,  -4, -9,   3], [7,   -9,  -1,  -6,  -6,  -1, -9,   7], [-35,  -35, -9, -9, -9, -9, -35,  -35], [95, -35,  7,  3,  3,  7, -35, 95]]
    s1 = 0
    s2 = 0
    s3 = 0
    celdas1 = 0
    celdas2 = 0
    celdas_frontera1 = 0
    celdas_frontera2 = 0

    for i in range(8):
      for j in range(8):
        if tablero[i][j] == firstP:
          s1 += MATRIZ[i][j]
          celdas1 += 1
        elif tablero[i][j] == secP:
          s1 -= MATRIZ[i][j]
          celdas2 += 1
        
        if tablero[i][j] != '_'   :
          for k in range(8)  :
            h = i + HORIZ[k]
            v = j + VERTI[k]
            if h >= 0 and h < 8 and v >= 0 and v < 8 and tablero[h][v] == '_':
              if tablero[i][j] == firstP:
                celdas_frontera1+=1
              else :
                celdas_frontera2+=1
              break
  
    if celdas1 > celdas2:
      s3 = (100.0 * celdas1)/(celdas1 + celdas2)
    elif celdas1 < celdas2:
      s3 = -(100.0 * celdas2)/(celdas1 + celdas2)
    else:
      s3 = 0
    
    if celdas_frontera1 > celdas_frontera2:
      s2 = -(100.0 * celdas_frontera1)/(celdas_frontera1 + celdas_frontera2)
    elif celdas_frontera1 < celdas_frontera2:
      s2 = (100.0 * celdas_frontera2)/(celdas_frontera1 + celdas_frontera2)
    else :
      s2 = 0
    
    celdas1 = celdas2 = 0
    if tablero[0][0] == firstP:
      celdas1+=1
    elif tablero[0][0] == secP:
      celdas2+=1
    if tablero[0][7] == firstP:
      celdas1+=1
    elif tablero[0][7] == secP:
      celdas2+=1
      
    if tablero[7][0] == firstP:
      celdas1+=1
    elif tablero[7][0] == secP:
      celdas2+=1
    if tablero[7][7] == firstP:
      celdas1+=1
    elif tablero[7][7] == secP:
      celdas2+=1
    s4 = 25 * (celdas1 - celdas2)

    celdas1 = celdas2 = 0
    if tablero[0][0] == '_':   
      if tablero[0][1] == firstP: 
        celdas1+=1
      elif tablero[0][1] == secP:
        celdas2+=1
      if tablero[1][1] == firstP: 
        celdas1+=1
      elif tablero[1][1] == secP:
        celdas2+=1
      if tablero[1][0] == firstP: 
        celdas1+=1
      elif tablero[1][0] == secP:
        celdas2+=1
    
    if tablero[0][7] == '_': 
      if tablero[0][6] == firstP: 
        celdas1+=1
      elif tablero[0][6] == secP:
        celdas2+=1
      if tablero[1][6] == firstP: 
        celdas1+=1
      elif tablero[1][6] == secP:
        celdas2+=1
      if tablero[1][7] == firstP: 
        celdas1+=1
      elif tablero[1][7] == secP:
        celdas2+=1
    
    if tablero[7][0] == '_': 
      if tablero[7][1] == firstP: 
        celdas1+=1
      elif tablero[7][1] == secP:
        celdas2+=1
      if tablero[6][1] == firstP: 
        celdas1+=1
      elif tablero[6][1] == secP:
        celdas2+=1
      if tablero[6][0] == firstP: 
        celdas1+=1
      elif tablero[6][0] == secP:
        celdas2+=1
    if tablero[7][7] == '_':  
      if tablero[6][7] == firstP: 
        celdas1+=1
      elif tablero[6][7] == secP:
        celdas2+=1
      if tablero[6][6] == firstP: 
        celdas1+=1
      elif tablero[6][6] == secP:
        celdas2+=1
      if tablero[7][6] == firstP: 
        celdas1+=1
      elif tablero[7][6] == secP:
        celdas2+=1
    
    s5 = -5.0 * (celdas1 - celdas2)
    #Movilidad
    celdas1 = len(state.game._get_valid_moves(state.board, firstP))
    celdas2 = len(state.game._get_valid_moves(state.board,secP))
    if celdas1 > celdas2:
      s6 = (100.0 * celdas1)/(celdas1 + celdas2)
    elif celdas1 < celdas2 :
      s6 = -(100.0 * celdas2)/(celdas1 + celdas2)
    else:
      s6 = 0

    return ((10.0 * s3) + (800.0 * s4) + (380.0 * s5) + (80.0 * s6) + (75.0 * s2) + (10.0 * s1))
