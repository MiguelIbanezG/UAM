 
from faker import Faker

import random

faker = Faker()



pf = faker.simple_profile()

name = str(pf['name']).split(' ')


print(pf['name'])
print(name[0])
print(name[1])

print(pf['birthdate'])

lista = []

lista.append("0")
lista.append("1")
lista.append("2")

print(lista[0])
print(lista[1])

print(random.randint(0, int(10-1)))