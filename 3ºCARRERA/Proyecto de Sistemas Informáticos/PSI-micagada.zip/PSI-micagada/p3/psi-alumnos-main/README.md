auxiliary files for PSI 2022-23 Assignments 3 & 4
