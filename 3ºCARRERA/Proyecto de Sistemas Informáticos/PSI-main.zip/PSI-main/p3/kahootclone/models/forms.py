from .models import Questionnaire, User, Question
from django.contrib.auth.forms import UserCreationForm
from django import forms


class SignUpForm(UserCreationForm):
    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name',
                  'email', 'password1', 'password2', )


class QuestionnaireCreateForm(forms.ModelForm):

    class Meta:
        model = Questionnaire
        fields = ('title', )
        labels = {
            'title': '',
        }
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control',
                                            'id': 'qform'}),
        }



class QuestionCreateForm(forms.ModelForm):

    class Meta:
        model = Question
        fields = ('question', 'answerTime', )
        labels = {
            'question': '',
            'answerTime': '',
        }
        widgets = {
        }
