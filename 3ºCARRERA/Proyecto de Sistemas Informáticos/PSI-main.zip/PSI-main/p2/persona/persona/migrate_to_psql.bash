pgloader sqlite:///home/sergio/Escritorio/uni/3o/2o_cuatri/psi/p2/persona/persona.db postgres://alumnodb:alumnodb@localhost:5432/psip2
createdb -U alumnodb psip2
