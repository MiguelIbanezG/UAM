"""kliente URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
import kaxarros.views as kaxarros
from django.urls import path, include
from rest_framework import routers

router = routers.DefaultRouter()

router.register('kaxarroSwitch', kaxarros.restKaxarroSwitch)
router.register('kaxarroSensor', kaxarros.restKaxarroSensor)
router.register('kaxarroClock', kaxarros.restKaxarroClock)
router.register('ruleSensor', kaxarros.restRuleSensor)
router.register('ruleClock', kaxarros.restRuleClock)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', kaxarros.home_view, name='home'),
    path('api/', include(router.urls)),

    # lista kaxarros
    path('kaxarroList/', kaxarros.kaxarroList.as_view(), name='kaxarroList'),

    # hacer
    path('createKaxarroSwitch/', kaxarros.createKaxarroSwitch.as_view(), name='createKaxarroSwitch'),
    path('createKaxarroSensor/', kaxarros.createKaxarroSensor.as_view(), name='createKaxarroSensor'),
    path('createKaxarroClock/', kaxarros.createKaxarroClock.as_view(), name='createKaxarroClock'),
    path('createRuleSensor/', kaxarros.createRuleSensor.as_view(), name='createRuleSensor'),
    path('createRuleClock/', kaxarros.createRuleClock.as_view(), name='createRuleClock'),

    # borrar
    path('deleteKaxarroSwitch/<int:pk>', kaxarros.deleteKaxarroSwitch.as_view(), name='deleteKaxarroSwitch'),
    path('deleteKaxarroSensor/<int:pk>', kaxarros.deleteKaxarroSensor.as_view(), name='deleteKaxarroSensor'),
    path('deleteKaxarroClock/<int:pk>', kaxarros.deleteKaxarroClock.as_view(), name='deleteKaxarroClock'),
    path("deleteRuleSensor/<int:pk>", kaxarros.deleteRuleSensor.as_view(), name="deleteRuleSensor"),
    path("deleteRuleClock/<int:pk>", kaxarros.deleteRuleClock.as_view(), name="deleteRuleClock"),

    # editar
    path('editKaxarroSwitch/<int:pk>', kaxarros.updateKaxarroSwitch.as_view(), name='editKaxarroSwitch'),
    path('editKaxarroSensor/<int:pk>', kaxarros.updateKaxarroSensor.as_view(), name='editKaxarroSensor'),
    path('editKaxarroClock/<int:pk>', kaxarros.updateKaxarroClock.as_view(), name='editKaxarroClock'),
    path('editRuleSensor/<int:pk>', kaxarros.updateRuleSensor.as_view(), name='editRuleSensor'),
    path('editRuleClock/<int:pk>', kaxarros.updateRuleClock.as_view(), name='editRuleClock'),
]
