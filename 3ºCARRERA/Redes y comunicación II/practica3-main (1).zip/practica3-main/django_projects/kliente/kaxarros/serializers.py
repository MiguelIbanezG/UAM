from rest_framework import serializers
from .models import *

class KaxarroSensorSerializer(serializers.ModelSerializer):
    class Meta:
        model = KaxarroSensor
        fields = '__all__'

class KaxarroSwitchSerializer(serializers.ModelSerializer):
    class Meta:
        model = KaxarroSwitch
        fields = '__all__'

class KaxarroClockSerializer(serializers.ModelSerializer):
    class Meta:
        model = KaxarroClock
        fields = '__all__'

class RuleSensorSerializer(serializers.ModelSerializer):
    class Meta:
        model = RuleSensor
        fields = '__all__'

class RuleClockSerializer(serializers.ModelSerializer):
    class Meta:
        model = RuleClock
        fields = '__all__'
