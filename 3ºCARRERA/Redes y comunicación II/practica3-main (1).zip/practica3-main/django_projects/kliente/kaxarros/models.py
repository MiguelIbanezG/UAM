from django.db import models

class Kaxarro(models.Model):
    id = models.IntegerField(primary_key=True)
    
    class Meta:
        abstract = True

    def __str__(self):
        return str(self.id)

class KaxarroSensor(Kaxarro):
    last_value = models.IntegerField(default=0)

    
    def __str__(self):
        return "Sensor" + str(self.id)

class KaxarroSwitch(Kaxarro):
    enxufao = models.BooleanField(default=False)
    
    def __str__(self):
        return "Switch" + str(self.id)

    
class KaxarroClock(Kaxarro):
    time = models.CharField(default="00:00:00", max_length=8)
    
    def __str__(self):
        return "Clock" + str(self.id)

class Rule(models.Model):
    id = models.AutoField(primary_key=True)
    operator = models.CharField(max_length=1)
    encendido = models.BooleanField()
    switch = models.ForeignKey(KaxarroSwitch, on_delete=models.CASCADE)

    class Meta:
        abstract = True

class RuleSensor(Rule):
    sensor = models.ForeignKey(KaxarroSensor, on_delete=models.CASCADE)
    valor = models.IntegerField()

class RuleClock(Rule):
    clock = models.ForeignKey(KaxarroClock, on_delete=models.CASCADE)
    valor = models.CharField(max_length=8)