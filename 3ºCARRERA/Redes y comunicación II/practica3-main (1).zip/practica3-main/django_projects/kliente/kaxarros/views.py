from django.shortcuts import render
from .serializers import *
from rest_framework import viewsets
from django.views.generic import CreateView, DeleteView, ListView, UpdateView
from django.urls import reverse_lazy
from django import forms

def home_view(request):
    return render(request, 'home.html')

class restKaxarroSensor(viewsets.ModelViewSet):
    queryset = KaxarroSensor.objects.all()
    serializer_class = KaxarroSensorSerializer

class restKaxarroSwitch(viewsets.ModelViewSet):
    queryset = KaxarroSwitch.objects.all()
    serializer_class = KaxarroSwitchSerializer

class restKaxarroClock(viewsets.ModelViewSet):
    queryset = KaxarroClock.objects.all()
    serializer_class = KaxarroClockSerializer

class restRuleSensor(viewsets.ModelViewSet):
    queryset = RuleSensor.objects.all()
    serializer_class = RuleSensorSerializer

class restRuleClock(viewsets.ModelViewSet):
    queryset = RuleClock.objects.all()
    serializer_class = RuleClockSerializer

# view to list all kaxarro subclasses in a single page (kaxarroList.html)
class kaxarroList(ListView):
    model = KaxarroSwitch
    template_name = 'kaxarros/kaxarroList.html'
    context_object_name = 'kaxarroList'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['kaxarroSensorList'] = KaxarroSensor.objects.all()
        context['kaxarroSwitchList'] = KaxarroSwitch.objects.all()
        context['kaxarroClockList'] = KaxarroClock.objects.all()
        context['ruleSensorList'] = RuleSensor.objects.all()
        context['ruleClockList'] = RuleClock.objects.all()

        return context
    
class createKaxarroSwitch(CreateView):
    model = KaxarroSwitch
    fields = ['id']
    success_url = reverse_lazy('kaxarroList')
    template_name = 'kaxarros/createKaxarroSwitch.html'


class createKaxarroSensor(CreateView):
    model = KaxarroSensor
    fields = ['id']
    success_url = reverse_lazy('kaxarroList')
    template_name = 'kaxarros/createKaxarroSensor.html'

class createKaxarroClock(CreateView):
    model = KaxarroClock
    fields = ['id']
    success_url = reverse_lazy('kaxarroList')
    template_name = 'kaxarros/createKaxarroClock.html'

COMPARACION_OPCIONES = [
    ('', 'Seleccionar una opción'),
    ('>', 'Mayor que'),
    ('<', 'Menor que'),
    ('=', 'Igual a'),
]

class RuleSensorForm(forms.ModelForm):
    operator = forms.ChoiceField(label='Operador', choices=COMPARACION_OPCIONES)

    class Meta:
       model = RuleSensor
       fields = ['sensor', 'operator', 'valor', 'switch', 'encendido']

class RuleClockForm(forms.ModelForm):
    operator = forms.ChoiceField(label='Operador', choices=COMPARACION_OPCIONES)

    class Meta:
       model = RuleClock
       fields = ['clock', 'operator', 'valor', 'switch', 'encendido']

class createRuleSensor(CreateView):
    form_class = RuleSensorForm
    success_url = reverse_lazy('kaxarroList')
    template_name = 'kaxarros/createRuleSensor.html'

class createRuleClock(CreateView):
    form_class = RuleClockForm
    success_url = reverse_lazy('kaxarroList')
    template_name = 'kaxarros/createRuleClock.html'

class updateRuleSensor(UpdateView):
    model = RuleSensor
    form_class = RuleSensorForm
    success_url = reverse_lazy('kaxarroList')
    template_name = 'kaxarros/editRuleSensor.html'

class updateRuleClock(UpdateView):
    model = RuleClock
    form_class = RuleClockForm
    success_url = reverse_lazy('kaxarroList')
    template_name = 'kaxarros/editRuleClock.html'

class deleteRuleSensor(DeleteView):
    model = RuleSensor
    template_name = 'kaxarros/deleteRuleSensor.html'
    success_url = reverse_lazy('kaxarroList')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['kaxarro'] = RuleSensor.objects.get(id=self.kwargs['pk'])
        return context
    
class deleteRuleClock(DeleteView):
    model = RuleClock
    template_name = 'kaxarros/deleteRuleClock.html'
    success_url = reverse_lazy('kaxarroList')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['kaxarro'] = RuleClock.objects.get(id=self.kwargs['pk'])
        return context

class updateKaxarroSwitch(UpdateView):
    model = KaxarroSwitch
    fields = ['id']
    success_url = reverse_lazy('kaxarroList')
    template_name = 'kaxarros/editKaxarroSwitch.html'

class updateKaxarroSensor(UpdateView):
    model = KaxarroSensor
    fields = ['id']
    success_url = reverse_lazy('kaxarroList')
    template_name = 'kaxarros/editKaxarroSensor.html'

class updateKaxarroClock(UpdateView):
    model = KaxarroClock
    fields = ['id']
    success_url = reverse_lazy('kaxarroList')
    template_name = 'kaxarros/editKaxarroClock.html'

class deleteKaxarroSwitch(DeleteView):
    model = KaxarroSwitch
    template_name = 'kaxarros/deleteKaxarroSwitch.html'
    success_url = reverse_lazy('kaxarroList')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['kaxarro'] = KaxarroSwitch.objects.get(id=self.kwargs['pk'])
        return context
    
class deleteKaxarroSensor(DeleteView):
    model = KaxarroSensor
    template_name = 'kaxarros/deleteKaxarroSensor.html'
    success_url = reverse_lazy('kaxarroList')
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['kaxarro'] = KaxarroSensor.objects.get(id=self.kwargs['pk'])
        return context
    
class deleteKaxarroClock(DeleteView):
    model = KaxarroClock
    template_name = 'kaxarros/deleteKaxarroClock.html'
    success_url = reverse_lazy('kaxarroList')
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['kaxarro'] = KaxarroClock.objects.get(id=self.kwargs['pk'])
        return context