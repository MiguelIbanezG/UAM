import subprocess
import dummy_sensor as sensor
import dummy_switch as switch
import _thread
import paho.mqtt.client as mqtt
import time

print("compenzando test sensor...")

expected_args = (
    "python",
    "dummy_sensor.py",
    "--host",
    "localhost",
    "--port",
    "1883",
    "-i",
    "1",
    "-m",
    "20",
    "-M",
    "30",
    "--increment",
    "1",
    "--test-args",
    "1",
)

expected_args_switch = (
    "python",
    "dummy_switch.py",
    "--host",
    "localhost",
    "--port",
    "1883",
    "-P",
    "1",
    "--test-args",
    "1",
)

expected_output = (
    f'Host: {expected_args[3]}',
    f'Port: {expected_args[5]}',
    f'Tiempo entre envíos: {expected_args[7]} segundos',
    f'Valor mínimo: {expected_args[9]}',
    f'Valor máximo: {expected_args[11]}',
    f'Incremento: {expected_args[13]}',
    f'ID del sensor: {expected_args[15]}',
    'Solo se han probado los argumentos',
)

expected_output_switch = (
    f'Host: {expected_args_switch[3]}',
    f'Port: {expected_args_switch[5]}',
    f'Probabilidad de fallo: {expected_args_switch[7]}',
    f'ID del dispositivo: {expected_args_switch[9]}',
    'Solo se han probado los argumentos',
)

print("Comprobando argumentos sensor...")


result = subprocess.run(expected_args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)

for e in expected_output:
    linia = ''
    for stdout_line in result.stdout.splitlines():
        if stdout_line.strip() == e:
            linia = stdout_line.strip()
            break
            
            assert linia == e, "Van fatal los argumentos"

print("Argumentos correctos")

print("Comprobando argumentos switch...")

result = subprocess.run(expected_args_switch, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)

for e in expected_output_switch:
    linia = ''
    for stdout_line in result.stdout.splitlines():
        if stdout_line.strip() == e:
            linia = stdout_line.strip()
            break
        
            assert linia == e, "Van fatal los argumentos"

print("Argumentos correctos")

print("Comprobando que se enxufa el sensor...")

kaxarro = sensor.KaxarroSensor(expected_args[15], int(expected_args[9]), int(expected_args[11]), int(expected_args[13]), int(expected_args[7]), int(expected_args[9]))

def kaxarrear():
    kaxarro.enxufarse(expected_args[3], int(expected_args[5]))
    thread = _thread.start_new_thread(kaxarro.operar, ())

    assert kaxarro.client != None, "No se ha enxufado"

    kaxarro.operar()

_thread.start_new_thread(kaxarrear, ())

print("Enxufado")

 # Krear moskito sensorCliente
sensorClient = mqtt.Client(client_id=f'testeo_{[expected_args[15]]}')

# Enxufar el kaxarro a la cosa
sensorClient.connect(host=expected_args[3], port=int(expected_args[5]))


kaxarroSwitch = switch.KaxarroSwitch(expected_args_switch[9], int(expected_args_switch[7]), False)

def on_message(client, userdata, message):
    
    valor = int(str(message.payload.decode("utf-8")))
    print("Mensaje recibido: " + str(valor))
    
    vuelta = 0

    if valor >= int(expected_args[11]) - 1:
        print("Va todo")
        exit(0)


    assert int(valor) <= int(expected_args[11]) and int(valor) >= int(expected_args[9]), "Valor fuera de rango"

    nuevo_estao = int(valor) > (int(expected_args[9]) + int(expected_args[11]) - int(expected_args[9]))
    
    kaxarroSwitch.operar(str(nuevo_estao))

    

    assert kaxarroSwitch.enxufao == nuevo_estao, "No se ha cambiado el estado"

sensorClient.on_message = on_message

sensorClient.subscribe(f'redes2/GGGG/PP/sensors/{expected_args[15]}')

print("Comprobando que se enxufa el switch...")


def movida():
    # KaxarroSwitch.connect(host=expected_args_switch[3], port=int(expected_args_switch[5]))
    
    kaxarroSwitch.enxufarse(expected_args_switch[3], int(expected_args_switch[5]))

    assert kaxarroSwitch.client != None, "No se ha enxufado"

_thread.start_new_thread(movida, ())

print("Enxufado")
sensorClient.loop_forever()