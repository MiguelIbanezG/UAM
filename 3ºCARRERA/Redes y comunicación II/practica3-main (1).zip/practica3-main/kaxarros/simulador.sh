python3 ../django_projects/kliente/manage.py runserver  &
python3 dummy_clock.py --host localhost 1 &
python3 dummy_sensor.py --host localhost 1 &
python3 dummy_switch.py --host localhost  1 &
echo "Comprueba el funcionamiento en http://localhost:8000/"