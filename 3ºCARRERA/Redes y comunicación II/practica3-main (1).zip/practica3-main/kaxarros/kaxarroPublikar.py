import paho.mqtt.client as mqtt 

broker_address = "localhost" # broker_address="localhost"  # use local broker

client = mqtt.Client("P1") #create new instance

client.connect(broker_address) #connect to broker

client.publish("redes2/GGGG/PP/switches/bulb1", "OFF") #publish