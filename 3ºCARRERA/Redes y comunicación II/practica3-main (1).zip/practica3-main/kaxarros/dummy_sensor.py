import argparse
import paho.mqtt.client as mqtt
import time
import _thread

class KaxarroSensor:

    # FUNCIÓN: __init__(self, id, min, max, increment, interval, last_value)
    # ARGS_IN: d: Identificador del sensor.
    # min: Valor mínimo que puede tomar el sensor.
    # max: Valor máximo que puede tomar el sensor.
    # increment: Valor que se le suma al último valor cada vez que se publique un nuevo valor.
    # interval: Intervalo de tiempo entre publicaciones de nuevos valores.
    # last_value: Último valor publicado por el sensor.
    # DESCRIPCIÓN: Constructor para la clase KaxarroSensor
    def __init__(self, id, min, max, increment, interval, last_value):
        self.id = id
        self.min = min
        self.max = max
        self.increment = increment
        self.interval = interval
        self.last_value = last_value
        self.client = None

    # FUNCIÓN: enxufarse(self, host, port)
    # ARGS_IN:host: Dirección IP del intermediario MQTT, port: Puerto del intermediario MQTT.
    # DESCRIPCIÓN: Conecta el Kaxarro al intermediario MQTT.
    def enxufarse(self, host, port):
        # Krear moskito kliente
        self.client = mqtt.Client(client_id=f'kaxarroSensorPublikar_{self.id}')

        # Enxufar el kaxarro a la cosa
        self.client.connect(host=host, port=port)

    # FUNCIÓN: stop(self)
    # DESCRIPCIÓN: Termina la ejecución de la función que publica nuevos valores.
    def stop(self):
        _thread.exit()

    # FUNCIÓN: operar(self)
    # DESCRIPCIÓN: Publica nuevos valores en el tema MQTT correspondiente al sensor
    def operar(self):
        # Subir kosas a los kaxarros
        while True:
            self.last_value += self.increment
            if self.last_value > self.max:
                self.last_value = self.min

            print(f"Current value is:1 {self.last_value}")
            
            self.client.publish(f'redes2/GGGG/PP/sensors/{self.id}', f'{self.last_value}')
        
            time.sleep(self.interval)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--host', type=str, default='redes2.ii.uam.es', help='Host al que enxufarse')
    parser.add_argument('-p', '--port', type=int, default=1883, help='Puerto al que enxufarse')
    parser.add_argument('-i', '--interval', type=int, default=1, help='Tiempo en segundos tras los que simula un cambio de estado')
    parser.add_argument('-m', '--min', type=int, default=20, help='Valor mínimo Valor mínimo a enviar ')
    parser.add_argument('-M', '--max', type=int, default=30, help='Valor máximo a enviar')
    parser.add_argument('--increment', type=int, default=1, help='Incremento entre min y max')
    parser.add_argument('--test-args', action='store_true', help='Solo se han probado los argumentos')
    parser.add_argument('id', type=int, help='ID del kaxarro (cliente del broker)')
    args = parser.parse_args()

    # Mostramos los valores de los argumentos
    print(f'Host: {args.host}')
    print(f'Port: {args.port}')
    print(f'Tiempo entre envíos: {args.interval} segundos')
    print(f'Valor mínimo: {args.min}')
    print(f'Valor máximo: {args.max}')
    print(f'Incremento: {args.increment}')
    print(f'ID del sensor: {args.id}')

    if args.test_args:
        print('Solo se han probado los argumentos')
        exit(0)

    notificaciones = mqtt.Client(client_id=f'sistema_notificaciones')

    notificaciones.connect(host=args.host, port=args.port)

    notificaciones.publish(f'redes2/GGGG/PP/notificaciones', f'kaxarroSensor|{args.id}')

    kaxarro = KaxarroSensor(args.id, args.min, args.max, args.increment, args.interval, args.min)
    kaxarro.enxufarse(args.host, args.port)
    kaxarro.operar()