import argparse
import datetime
import paho.mqtt.client as mqtt
import _thread
import time



class KaxarroClock:

    # FUNCIÓN: __init__(self, time, increment, rate, id)
    # ARGS_IN: time: string en formato HH:MM:SS que representa el tiempo de inicio del reloj. 
    # increment: entero que representa la cantidad de segundos que se deben incrementar el tiempo del reloj en cada operación.
    # rate: entero que representa la cantidad de segundos entre cada publicación del tiempo del reloj.
    # id: entero que representa el identificador del reloj.
    # DESCRIPCIÓN: Constructor de la clase KaxarroClock
    def __init__(self, time, increment, rate, id):
        self.time = datetime.datetime.strptime(time, '%H:%M:%S')
        self.increment = increment
        self.rate = rate
        self.id = id
        self.client = None
        self.mutex = _thread.allocate_lock()  # inicializar mutex


    # FUNCIÓN: enxufarse(self, host, port)
    # ARGS_IN: host: string que representa la dirección IP o el nombre de dominio del broker MQTT.
    # port: entero que representa el puerto del broker MQT.
    # DESCRIPCIÓN: Establece la conexión del cliente MQTT del reloj con el broker MQTT.
    def enxufarse(self, host, port):
        # Krear moskito kliente
        self.client = mqtt.Client(client_id=f'kaxarroClockPublikar_{args.id}')

        # Enxufar el kaxarro a la cosa
        self.client.connect(host=host, port=port)


    # FUNCIÓN: hacerThreadYOperar(self)
    # DESCRIPCIÓN: Crea un hilo y ejecuta el método mandar en el hilo recién creado. 
    # Luego ejecuta el método operar en el hilo principal.
    def hacerThreadYOperar(self):
        _thread.start_new_thread(self.mandar, ())
        self.operar()

    # FUNCIÓN: mandar(self)
    # DESCRIPCIÓN: Publica el tiempo actual del reloj en el topic correspondiente cada rate segundos.
    def mandar(self):
        while True:
            
            with self.mutex:  # protege self.time
                taim = str(self.time).split(" ")[1]
                self.client.publish(f'redes2/GGGG/PP/clocks/{self.id}', f'{taim}')
                print(f"Current time is: {taim}")
            time.sleep(self.rate)


    # FUNCIÓN: operar(self)
    # DESCRIPCIÓN: Incrementa el tiempo del reloj en increment segundos cada vez 
    # que se ejecuta la función y espera increment segundos antes de volver a ejecutarla.
    def operar(self):
        # Subir kosas a los kaxarros
        while True:
            
            with self.mutex:  # protege self.time
                self.time += datetime.timedelta(seconds=self.increment)

            time.sleep(self.increment)



if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='dummy-clock.py')
    parser.add_argument('--host', type=str, default='redes2.ii.uam.es', help='Host al que enxufarse')
    parser.add_argument('-p', '--port', type=int, default=1883, help='Puerto al que enxufarse')
    parser.add_argument('--time', type=str, default=datetime.datetime.now().strftime('%H:%M:%S'), help='Hora de inicio en formato HH:MM:SS (default: hora actual)')
    parser.add_argument('--increment', type=int, default=1, help='Incremento en segundos entre envíos (default: 1)')
    parser.add_argument('--rate', type=int, default=1, help='Frecuencia de envío en segundos (default: 1)')
    parser.add_argument('id', type=int, help='ID del kaxarro (cliente del broker)')
    args = parser.parse_args()

    # Imprimir los argumentos parseados
    print(f'Hora de inicio: {args.time}')
    print(f'Incremento: {args.increment}')
    print(f'Frecuencia de envío: {args.rate}')
    print(f'ID del clock: {args.id}')
    
    notificaciones = mqtt.Client(client_id=f'sistema_notificaciones')

    notificaciones.connect(host=args.host, port=args.port)

    notificaciones.publish(f'redes2/GGGG/PP/notificaciones', f'kaxarroClock|{args.id}')

    # Crear el kaxarro
    kaxarro = KaxarroClock(args.time, args.increment, args.rate, args.id)
    kaxarro.enxufarse(args.host, args.port)
    kaxarro.hacerThreadYOperar()