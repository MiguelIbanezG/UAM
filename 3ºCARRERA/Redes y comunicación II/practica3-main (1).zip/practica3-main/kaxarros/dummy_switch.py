import argparse
import paho.mqtt.client as mqtt
import random
import _thread

class KaxarroSwitch:
	# FUNCIÓN: __init__(self, id, probability, enxufao)
    # ARGS_IN: id: identificador único del interruptor.
    # probability: probabilidad de que falle el interruptor.
    # enxufao: estado del interruptor.
    # DESCRIPCIÓN: Constructor de la clase KaxarroSwitch
	def __init__(self, id, probability, enxufao):
		self.id = id
		self.probability = 1 - probability
		self.enxufao = enxufao

	# FUNCIÓN: enxufarse(self, host, port)
    # ARGS_IN: host: la dirección IP del intermediario MQTT.
    # port: el número de puerto del intermediario MQTT.
    # DESCRIPCIÓN: este método crea un cliente MQTT, lo conecta al intermediario 
	# y se suscribe al tema de los interruptores corrspondiente al id.
	def enxufarse(self, host, port):
		# Krear moskito kliente
		client = mqtt.Client(client_id=f'kaxarroSwitchSakar_{self.id}')

		# Conectar el kaxarro a la cosa
		client.connect(host=host, port=port)

		# Apuntarse a los kaxarros
		client.subscribe(f'redes2/GGGG/PP/switches/{self.id}')

		# K hacer kuando able 1 kaxarro

		client.on_message=self.on_message

		# Eskuxar kaxarros
		client.loop_forever()

	# FUNCIÓN: on_message(self, client, userdata, message)
    # ARGS_IN: message: objeto que contiene información sobre el mensaje recibido..
    # DESCRIPCIÓN: La función de callback on_message se llama cuando se recibe un mensaje 
	# en el tema al que se suscribió el cliente.Luego, se llama al método operar, que recibe 
	# el nuevo estado del interruptor en el mensaje. 
	def on_message(self, client, userdata, message):
		print("message received ", str(message.payload.decode("utf-8")))
		
		self.operar(str(message.payload.decode("utf-8")))

	# FUNCIÓN: stop(self)
    # DESCRIPCIÓN: Termina la ejecución de la función que publica nuevos valores.
	def stop(self):
		_thread.exit()

	# FUNCIÓN: operar(self)
    # DESCRIPCIÓN: Publica nuevos valores en el tema MQTT correspondiente al sensor
	def operar(self, nuevo_estado):
		if nuevo_estado == "stop":
			self.stop()

		nuevo_estado = nuevo_estado.lower() in ['true', '1', 't', 'y', 'yes', 'yeah', 'yup', 'certainly', 'uh-huh', 'on', 'enxufao']

		
		if random.random() < self.probability:
			self.enxufao = nuevo_estado
		else:
			print('Fallo en el kaxarro')
		
		print(f'Estado del switch: {self.enxufao}')

if __name__ == '__main__':
	parser = argparse.ArgumentParser()
	parser.add_argument('--host', type=str, default='redes2.ii.uam.es', help='Host al k enxufarse')
	parser.add_argument('-p', '--port', type=int, default=1883, help='Puerto al k enxufarse')
	parser.add_argument('-P', '--probability', type=float, default=0.3, help='Probabilidad error')
	parser.add_argument('--test-args', action='store_true', help='probar solo los argumentos')
	parser.add_argument('id', type=int, help='ID del kaxarro (cliente del broker)')
	args = parser.parse_args()

	# Mostramos los valores de los argumentos
	print(f'Host: {args.host}')
	print(f'Port: {args.port}')
	print(f'Probabilidad de fallo: {args.probability}')
	print(f'ID del dispositivo: {args.id}')

	if args.test_args:
		print('Solo se han probado los argumentos')
		exit(0)

	notificaciones = mqtt.Client(client_id=f'sistema_notificaciones')
	
	notificaciones.connect(host=args.host, port=args.port)

	notificaciones.publish(f'redes2/GGGG/PP/notificaciones', f'kaxarroSwitch|{args.id}')

	kaxarro = KaxarroSwitch(args.id, args.probability, False)
	kaxarro.enxufarse()