import argparse
import paho.mqtt.client as mqtt
import requests 
import _thread
import time
import json

switchName = "kaxarroSwitch"
sensorName = "kaxarroSensor"
clockName = "kaxarroClock"
ruleSensorName = "ruleSensor"
ruleClockName = "ruleClock"

urlApi = "http://127.0.0.1:8000/api/"
sensorTopic = "redes2/GGGG/PP/sensors/"
clockTopic = "redes2/GGGG/PP/clocks/"

notificationTopic = "redes2/GGGG/PP/notificaciones"

# FUNCIÓN: __init__(self, host, port)
# ARGS_IN: host: la dirección IP del intermediario MQTT, puerto: el número de puerto del intermediario MQTT
# DESCRIPCIÓN: Constructor para la clase Kontrolador
# ARGS_OUT: Ninguno
class kontrolador:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.client = None
        self.notificaciones = None
        self.last_update = None
        self.switches = []
        self.switchesApi = []
        self.sensors = []
        self.sensorsApi = []
        self.clocks = []
        self.clocksApi = []
        self.clockRules = []
        self.sensorRules = []
        self.ruleMutex = _thread.allocate_lock()  # inicializar mutex
        _thread.start_new_thread(self.apiListen, ())
    
    # FUNCIÓN: enxufarse(self)
    # DESCRIPCIÓN:Esta función conecta al cliente con el corredor MQTT y se suscribe al tema de notificaciones
    # También configura la función de devolución de llamada on_message.
    def enxufarse(self):
        self.client = mqtt.Client(client_id=f'sistema')
        self.client.connect(host=self.host, port=self.port)
        self.client.subscribe(notificationTopic)
        self.client.on_message = self.gestionar
        self.client.loop_forever()
    
    # FUNCIÓN: gestionar(self, client, userdata, message)
    # DESCRIPCIÓN: Si el tema del mensaje es igual a notificationTopic, entonces se llama a la función registrarKaxarro con el mensaje decodificado como argumento. 
    # De lo contrario, se llama a la función gestionarSensor con el mensaje como argumento.
    def gestionar(self, client, userdata, message):
        if message.topic == notificationTopic:
            self.registrarKaxarro(str(message.payload.decode("utf-8")))
        else:
            self.gestionarSensor(message)

    # def gestionarSwitch(self, rulas, comprobador, topic, message)
    # ARGS_IN: El argumento rulas es una lista de reglas, comprobador es una cadena que indica si se está comprobando una regla del sensor o del reloj, 
    # topic es la cadena que representa el tema del mensaje y message es el mensaje a verificar.
    # DESCRIPCIÓN: Esta función es responsable de verificar si una regla específica se aplica a un mensaje específico.
    def gestionarSwitch(self, rulas, comprobador, topic, message):
        with self.ruleMutex:
            for rule in rulas:
                
                if str(rule["switch"]) not in self.switches:
                    continue
                
                if topic + str(rule[comprobador]) == message.topic:
                    changed = False

                    if rule["operator"] == ">":
                        if str(message.payload.decode("utf-8")) > str(rule["valor"]):
                            self.client.publish('redes2/GGGG/PP/switches/' + str(rule["switch"]), rule["encendido"])
                            changed = True
                    elif rule["operator"] == "<":
                        if str(message.payload.decode("utf-8")) < str(rule["valor"]):
                            self.client.publish('redes2/GGGG/PP/switches/' + str(rule["switch"]), rule["encendido"])
                            changed = True
                    elif rule["operator"] == "=":
                        if str(message.payload.decode("utf-8")) == str(rule["valor"]):
                            self.client.publish('redes2/GGGG/PP/switches/' + str(rule["switch"]), rule["encendido"])
                            changed = True
                    
                    if changed:
                        url = urlApi + switchName + '/' + str(rule["switch"]) + '/'
                        new_state = {"enxufao": rule["encendido"]}

                        requests.patch(url, json=new_state)


    # FUNCIÓN: gestionarSensor(self, message)
    # ARGS_IN: message: objeto MQTT recibido
    # DESCRIPCIÓN: Método que se encarga de procesar los mensajes MQTT recibidos relacionados con los sensores y los relojes.
    def gestionarSensor(self, message):
        print("message received ", str(message.payload.decode("utf-8")))

        if message.topic.split('/')[-2] == "sensors":
            url = urlApi + sensorName + '/' + message.topic.split('/')[-1]  + '/'
            new_state = {"last_value": int(message.payload.decode("utf-8"))}
        else:
            url = urlApi + clockName + '/' + message.topic.split('/')[-1]  + '/'
            new_state = {"time": message.payload.decode("utf-8")}

        requests.patch(url, json=new_state)

        self.gestionarSwitch(self.sensorRules, "sensor", sensorTopic, message)
        self.gestionarSwitch(self.clockRules, "clock", clockTopic,message)

    # FUNCIÓN: sacarDatosApi(self, nombreCosaApi)
    # ARGS_IN: nombreCosaApi: una cadena de caracteres que representa el nombre de la cosa de la cual se quiere obtener los datos.
    # DESCRIPCIÓN: Esta función se encarga de hacer una petición GET a una API para obtener datos.
    # ARGS_OUT: Una cadena de caracteres que representa los datos obtenidos en la petición.
    def sacarDatosApi(self, nombreCosaApi):
        url = urlApi + nombreCosaApi

        response = requests.get(url)

        if response.status_code == 200:
            return response.text
        
    # FUNCIÓN: registrarKaxarro(self, message)
    # ARGS_IN: message: una cadena de caracteres que representa el kaxarro a registrar en formato "kaxarroTipo|kaxarroID".
    # DESCRIPCIÓN: Esta función registra un "kaxarro" que es un objeto que puede ser un sensor, switch o reloj. Agrega el kaxarro a 
    # la lista correspondiente (sensors, switches, clocks) y se suscribe a su respectivo tópico.
    def registrarKaxarro(self, message):
        kaxarro = message

        print(f"registrando {kaxarro}...")

        kaxarro = kaxarro.split("|")

        if kaxarro[0] == "kaxarroSensor":
            self.client.subscribe(sensorTopic + kaxarro[1])
            self.sensors.append(kaxarro[1])
        elif kaxarro[0] == "kaxarroSwitch":
            self.switches.append(kaxarro[1])
        elif kaxarro[0] == "kaxarroClock":
            self.client.subscribe(clockTopic + kaxarro[1])
            self.clocks.append(kaxarro[1])

    # FUNCIÓN: eliminarKaxarro(self, kaxarro)
    # ARGS_IN: kaxarro: una cadena de caracteres que representa el kaxarro a eliminar.
    # DESCRIPCIÓN: Esta función elimina un "kaxarro" de la lista correspondiente 
    # (sensors, switches, clocks) y cancela su suscripción al tópico respectivo.
    def eliminarKaxarro(self, kaxarro):
        pass

    # FUNCIÓN: apiListen(self)
    # DESCRIPCIÓN: Esta función se encarga de escuchar constantemente por nuevos kaxarros en la API, comparando las listas locales 
    # con las listas de la API, y de actualizar las reglas de los sensores y relojes.  
    def apiListen(self):
        while True:
           
                
            switchesApi = self.sacarDatosApi(switchName)
            switchesApi = json.loads(switchesApi)

            if self.switchesApi != switchesApi:
                self.switchesApi = switchesApi

                for switch in self.switchesApi:
                    if (str(switch["id"]) not in self.switches):
                        self.registrarKaxarro(switchName + "|" + str(switch["id"]))


            sensorsApi = self.sacarDatosApi(sensorName)
            sensorsApi = json.loads(sensorsApi)

            if sensorsApi != self.sensorsApi:
                self.sensorsApi = sensorsApi

                for sensor in self.sensorsApi:
                    if (str(sensor["id"]) not in self.sensors):
                        self.registrarKaxarro(sensorName + "|" + str(sensor["id"]))
            
            clocksApi = self.sacarDatosApi(clockName)
            clocksApi = json.loads(clocksApi)

            if clocksApi != self.clocksApi:
                self.clocksApi = clocksApi

                for clock in self.clocksApi:
                    if (str(clock["id"]) not in self.clocks):
                        self.registrarKaxarro(clockName + "|" + str(clock["id"]))

            sensorRules = self.sacarDatosApi(ruleSensorName)

            sensorRules = json.loads(sensorRules)
            if sensorRules != self.sensorRules:
                with self.ruleMutex:
                    self.sensorRules = sensorRules
                    print(self.sensorRules)

            clockRules = self.sacarDatosApi(ruleClockName)

            clockRules = json.loads(clockRules)
            if clockRules != self.clockRules:
                with self.ruleMutex:
                    self.clockRules = clockRules
                    print(self.clockRules)
            
            time.sleep(1)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Aplicación que conecta con el broker y controla los dispositivos')

    parser.add_argument('--host', default='redes2.ii.uam.es', help='Host del broker')
    parser.add_argument('-p', '--port', default=1883, type=int, help='Puerto del broker')
    args = parser.parse_args()

    # Imprimir los argumentos parseados
    print('Argumentos del controlador d kaxarros:')
    print(f'Host: {args.host}')
    print(f'Puerto: {args.port}')
    
    
    # Crear el controlador
    controlador = kontrolador(args.host, args.port)
    controlador.enxufarse()
    # controlador.operar()
    # controlador.apiListen()
