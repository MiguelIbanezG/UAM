import paho.mqtt.client as mqtt

def on_message(client, userdata, message):
    print("message received ", str(message.payload.decode("utf-8")))
    print("message topic=", message.topic)

broker_address="localhost"
client = mqtt.Client("bulb_switch") #create new instance

client.on_message=on_message#attach function to callback

client.connect(broker_address) #connect to broker

# client.loop_start() #start the loop

client.subscribe("redes2/GGGG/PP/switches/bulb1")

client.loop_forever()