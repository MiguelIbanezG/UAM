# PRACTICA 2 REDES II
### Grupo: 2323
### Autores: Javier y Miguel Ibáñez González

## Indice
1. [Introduccion](#introduccion)
2. [Requisitos](#requisitos)
3. [Decisiones](#decisiones)
4. [Implementacion](#implementacion)
5. [Casos de uso ](#casos)
6. [Limitaciones](#limitaciones)
7. [Clases](#clases)
8. [Comunicacion](#comunicacion)
9. [Conclusiones](#conclusiones)


## Introduccion

En esta práctica vamos a crear un sistema de domótica para el hogar en el que se van a utilizar dispositivos IoT, estos dispositivos incluyen interruptores, sensores y motores, que permiten realizar acciones cotidianas como encender luces, medir temperaturas o subir persianas. 

Existen muchos protocolos para la comunicación IoT, pero en esta practica nos centramos en MQTT, uno de los más utilizados. Para interactuar con el sistema, hemos elegido la opcion de una aplicación web basada en Django. Esta opción nos perimite la gestión de dispositivos, reglas y eventos generados.

El sistema está formado por varios componentes, que incluyen dispositivos IoT como sensores, interruptores y relojes, un broker MQTT llamado Mosquitto, un controlador que gestiona el sistema en general, un motor de reglas que verifica las reglas y lanza acciones, y un componente de persistencia que almacena la información de los dispositivos registrados y las reglas.

## Requisitos
Los requisitos principales para el funcionamiento de la practica es la instalación de: 

paho-mqtt: paho-MQTT es una biblioteca de cliente MQTT de código abierto que se utiliza para implementar aplicaciones que se conectan y comunican con un broker MQTT. Paho-MQTT nos proporciona una interfaz de programación de aplicaciones (API) para poder integrar el protocolo MQTT. Con Paho-MQTT, se puede crear aplicaciones que se conecten a un broker MQTT para publicar y suscribirse a mensajes. 

django-cors-headers: es una biblioteca de Django que permite a una aplicación web comunicarse con otras aplicaciones web de diferentes dominios a través de peticiones HTTP. Dispone de un mecanismo de seguridad que se utiliza para restringir las solicitudes HTTP entre diferentes dominios. Cuando una aplicación web recibe una solicitud de un navegador web, el navegador incluye automáticamente ciertas cabeceras de solicitud HTTP, como el origen del dominio, que indican desde dónde se originó la solicitud. Si la aplicación web que está recibiendo la solicitud no tiene permiso para acceder al recurso solicitado, el navegador bloqueará la solicitud por razones de seguridad.

djangorestframework: es un framework de Django que permite crear fácilmente API RESTful (APIs basadas en HTTP que siguen el estilo arquitectónico REST) con Django, proporciona un conjunto de herramientas para construir API web, incluyendo la serialización de datos, vistas basadas en clases, autenticación, permisos, enrutamiento y documentación. Con DRF, los desarrolladores pueden crear API RESTful más rápidamente y con menos código que utilizando solamente Django.

djangorestframework-simplejwt: es una biblioteca que proporciona autenticación JSON Web Tokens (JWT) simple para aplicaciones Django REST Framework. Los tokens JWT son una forma de autenticación y autorización de usuarios en aplicaciones web y API RESTful. En lugar de almacenar tokens de sesión en el servidor, los tokens JWT son firmados digitalmente y se almacenan en el cliente.

## Decisiones
¿Controller y Rule engine han de ser aplicaciones separadas?, ¿por qué?, ¿qué ventajas tiene una y otra opción?

Controller y Rule engine no tienen porque ser aplicaciones separadas, ya que Controller se encarga de recibir solicitudes de la red y enviar comandos a los dispositivos, y Rule engine se encarga de procesar reglas y condiciones para tomar decisiones en función de los datos de los dispositivos.

La ventaja que tendría haberlo hecho en aplicaciones separadas es que permite una tendría una modularidad y flexibilidad en el desarrollo y mantenimiento del sistema. Cada componente puede ser desarrollado y actualizado de forma independiente, lo que facilita la escalabilidad y evolución del sistema. Sin embargo es menos complejo hacer los dos en una misma aplicacion.

¿Cómo se comunican Controller y Rule engine en la opción escogida?

En la opción escogida, si Controller y Rule engine están en la misma aplicación, se comunican directamente mediante llamadas de función o de método. El Controller llama al Rule engine cuando necesite ejecutar una regla, y el Rule engine devuelve un resultado al Controller después de ejecutar la regla.

¿Tiene sentido que alguno de estos componentes compartan funcionalidad?, ¿qué relación hay entre ellos?

 Compartir funcionalidad entre Controller y Rule engine puede ser beneficioso en términos de eficiencia y coherencia del sistema. Ambos componentes trabajan juntos para lograr los objetivos de la aplicación, por lo que puede haber una gran cantidad de funcionalidad que sea común a ambos. Por ejemplo, la validación de datos y la manipulación de entradas son responsabilidades compartidas.

 En cuanto a la relación entre Controller y Rule engine, ambos componentes trabajan juntos para lograr los objetivos de la aplicación. El Controller es responsable de manejar la interacción con el usuario y llamar al Rule engine para ejecutar las reglas correspondientes. El Rule engine es responsable de evaluar las reglas y devolver los resultados al Controller. 

¿Cuántas instancias hay de cada componente?

Respecto a la cantidad de instancias de cada componente, eso dependerá de la cantidad de dispositivos y usuarios que se quieran manejar en el sistema. Se puede tener varias instancias de cada componente para manejar diferentes grupos de dispositivos o usuarios.


## Implementacion

Para la implementación, hemos generado una interfaz mediante django en la cual se pueden añadir cacharros mediante un id para ser monitorizados en la págima, así como distintas normas para definir el comportamiento de los mismos. Los cacharros se arrancarán ejecutando los distintos dummys con un id especifico. Estos notificarán su existencia al controlador mediante un topic especifico para notificaciones y los registrará. El controlador leerá de la api rest que es instanciada por la página de django y registrará o desregistrará los aparatos según estén o dejen de estar en la api. De la api también se leerán una serie de reglas las cuales servirán para gestionar las acciones que realizarán los aparatos.

## Casos de uso 

Control de acceso a una oficina: se pueden instalar sensores en la entrada y salida de la oficina para detectar cuando un empleado entra o sale. El sistema puede enviar una notificación a través de la aplicación móvil cuando un empleado llega o se va.

Control de la temperatura en una casa: el sistema puede estar conectado a un termostato y a sensores de temperatura en las diferentes habitaciones. Los usuarios pueden establecer la temperatura deseada en cada habitación desde la aplicación móvil, y el sistema ajustará automáticamente la temperatura según los ajustes establecidos.

Gestión de la iluminación en un edificio de oficinas: el sistema puede estar conectado a sensores de movimiento y luminosidad para ajustar automáticamente la iluminación en función de las condiciones ambientales. Los usuarios pueden controlar la iluminación desde la aplicación móvil y programar horarios para encender o apagar las luces.

## Limitaciones 

Algunas limitaciones de nuestro codigo son:

No existe una funcionalidad de autenticación y autorización, no se implementa ningún mecanismo de autenticación o autorización en el código, lo que significa que cualquier persona que tenga acceso a la aplicación podría modificar las reglas de negocio y afectar la integridad del sistema.

El sistema solo admite reglas de negocio sencillas, solo puede procesar reglas de negocio simples y no es capaz de manejar reglas más complejas o múltiples condiciones.

## Comunicacion

Especificación de comunicación con cada tipo de sensor el sensor y el reloj mandan su valor numérico el switch recibe si debe encenderse o apagarse y opera acorde a lo que le llegue.

## Persistencia

Los datos de la aplicación se guardarán en la base de datos de sqlite de django

## Conclusiones

La implementación de un sistema domótico para el hogar con dispositivos IoT puede puede parecer de primeras algo complicado pero gracias a la gran cantidad de herramientas y tecnologías disponibles no es una tarea tan dificil. La idea de poder controlar los dispositivos desde cualquier lugar y en cualquier es bastante muy util y cada vez se esta aplicansdo en mas casos de la vida real. 

La opción de usar MQTT como protocolo de comunicación IoT y Mosquitto como broker es interesante debido a la facilidad de uso y la gran cantidad de documentación y soporte disponible.
El uso de Django como opción para la interfaz de usuario nos permite una fácil gestión de los dispositivos, reglas y eventos generados, y la integración con su capa de persistencia facilita el almacenamiento de la información.

En resumen, la implementación de un sistema domótico para el hogar con dispositivos IoT es una tarea muy intersante que nos a permitido aprender a desarrollar metodos para la mejora de la eficiencia del hogar.
