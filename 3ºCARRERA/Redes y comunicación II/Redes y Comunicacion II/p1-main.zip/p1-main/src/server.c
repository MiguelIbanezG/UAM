#include <stdio.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h> // read(), write(), close()
#include<signal.h>
#include<unistd.h>
#include<stdlib.h>
#include <string.h>

#include "../include/serverutils.h"

#define MAX 80
#define PORT 8087
#define BUFMAX 8087

int e = 0;

static volatile int quietese = 0;

int _is_dir(const char *path);

int _is_dir(const char *path) {
    struct stat path_stat;
    stat(path, &path_stat);
    return S_ISDIR(path_stat.st_mode);
}


void handler() {
    quietese = 1;
}

/*********
* FUNCIÓN: void func(server *s)
* ARGS_IN: server *s
* DESCRIPCIÓN: Función diseñada para chatear entre cliente y servidor.
* ARGS_OUT: 
*********/
void func(server *s)
{
    char buffer2[BUFMAX];
    char buff[MAX];
    int connfd;
    e++;
    // bucle infinito
    for (;;) {
        bzero(buff, MAX);
            //evitamos 1 coredumped raro


        sem_wait(&s->paloshilos);
        connfd = server_connect_client(s);
        sem_post(&s->paloshilos);

        http_request *req = parse_http(s, connfd);

        sprintf(buffer2, "%s/%.*s",s->conf.root, (int)(req->pathLen), req->path);
        if (_is_dir(buffer2) == 1 || strcmp(req->path, "/") == 0) {
            strcpy(req->path, DEFAULTFILE);
            req->pathLen = strlen(DEFAULTFILE);
        }

        http_response(s, req); 
   
        // si el mensaje contiene "Salir", entonces la salida del servidor y el chat terminaron.
        close(connfd);

        if (quietese == 1) {
            printf("Server Exit...\n");
            break;
        }
    }
    pthread_exit(NULL);
}
   
int main()
{
    server *s;
    s_conf conf;

    struct sigaction act;
    sigset_t apagar, oapagar;

    act.sa_handler = handler;
    sigemptyset(&(act.sa_mask));
    act.sa_flags = 0;

        
    sigemptyset (&apagar);
    sigaddset (&apagar, SIGINT);

    if (sigprocmask(SIG_BLOCK, &apagar, &oapagar) < 0) {
        perror("sigprocmask");
        exit(EXIT_FAILURE);
    }

    if (sigaction(SIGINT, &act, NULL) < 0) {
        perror("sigaction");
        exit(EXIT_FAILURE);
    }


    //server config
    conf = server_config("server.conf");
    conf.family = AF_INET;
    conf.type = SOCK_STREAM;
    conf.protocol = 0 ;
    conf.addr = INADDR_ANY;
    conf.f = func;
    // conf.port = PORT;ma
    // strcpy(conf.root, ".");
    // conf.max_connections = 5;

    s = create_server(conf);

    sigsuspend(&oapagar);

    free_server(s);
}