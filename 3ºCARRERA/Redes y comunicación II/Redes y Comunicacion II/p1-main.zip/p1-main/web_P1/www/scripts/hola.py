import sys
import re
# es esto: Reciba un petición GET con un  argumento que guarde 
# el nombre de un usuario, y responda con la cadena "Hola <<nombre>>!"

values = re.findall(r'=([\w]+)', sys.argv[1])

print("Hola " + values[0] + "!")
