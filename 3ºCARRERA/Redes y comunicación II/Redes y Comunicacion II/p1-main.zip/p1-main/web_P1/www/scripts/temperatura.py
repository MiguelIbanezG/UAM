import sys
import re
# Reciba un petición POST con un argumento que guarde una temperatura en grados Celsius, y
# devuelva la temperatura correspondiente en Farenheit

print((int(sys.argv[1]) * 9 / 5) + 32)