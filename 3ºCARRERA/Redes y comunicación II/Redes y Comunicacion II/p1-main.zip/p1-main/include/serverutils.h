#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <sys/stat.h>
#include "../include/picohttpparser.h"

#define SA struct sockaddr
#define MAXPATH 512
#define MAXTYPE 512
#define MAXEXT 512

#define MAXERR 512

#define FORMATS "text/plain#txt|text/html#html|text/html#htm|image/jpeg#jpeg|image/jpg#jpg|script/py#py|script/php#php|video/mpeg#mpeg|video/mpeg#mpg|application/msword#doc|application/msword#docx|application/pdf#pdf"

#define DEFAULTFILE "default.html"

#define ERROR400MSG "HTTP/1.0 400 Bad Request\r\n"
#define ERROR404MSG "HTTP/1.0 404 Not Found\r\n"
#define ERROR200MSG "HTTP/1.0 200 OK\r\n"

typedef struct _server server;

typedef struct s_conf {
    uint16_t port;
    int family;
    int type;
    int protocol;
    uint32_t addr;
    int max_connections;
    char root[MAXPATH];
    char signature[MAXPATH];
    void (*f)(server*); //function to be executed by thread 
} s_conf;

struct _server {
    s_conf conf;
    int sockfd;
    pthread_t *thread_pool;
    sem_t paloshilos;
    sem_t writeserver;
};


typedef struct http_request {
    char *method;
    size_t methodLen;
    char *path;
    size_t pathLen;
    int minor_version;
    struct phr_header *headers;
    size_t num_headers;
    int connfd;
    char* body;
} http_request;

typedef struct http_file {
    FILE *f;
    char type[MAXTYPE];
    char path[MAXPATH];
    char *extension;
    char err[MAXERR];
    char *args;
    struct stat st;
} http_file;

s_conf server_config(char *confPath);

// if listen is -1 this function is skipped
server *create_server(s_conf conf);

int server_listen(server *s);

int server_connect_client(server *s);

void free_server(server *s);

/**
 * @brief En esta función tú le metes una extensión y te devuelve el tipo buscándolo en la macro FORMATS
 * (programé esto fumao por eso es así esto)
 * 
 * @param ext 
 * @return char* 
 */
char* getTypeByExtension(char *ext);

/**
 * @brief Create a http file object
 * 
 * @param path 
 * @param type 
 * @param filePerms para no abrir el archivo meter null en aquí
 * @return http_file* 
 */
http_file *create_http_file(char *path, char *filePerms);

void free_http_file(http_file *f);

http_file * getFile(server *s, http_request *req);

char * create_http_headers(server *s,http_request *req, http_file *f, int send);

void http_response(server *s, http_request *req);

http_request * create_http_request();

void options(server *s, http_request *req);

void free_http_request(http_request *r);

/**
 * @brief Codigo adaptado del README de https://github.com/h2o/picohttpparser 👌 
 * 
 * @param s 
 * @return http_request* 
 */
http_request * parse_http(server *s, int connfd);



