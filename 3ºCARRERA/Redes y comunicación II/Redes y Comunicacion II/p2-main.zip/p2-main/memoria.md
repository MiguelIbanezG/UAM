# PRACTICA 2 REDES II
### Grupo: 2323
### Autores: Javier y Miguel Ibáñez González

## Indice
1. [Introduccion](#introduccion)
2. [Funcionamiento](#funcionamiento)
3. [Uso](#uso)
4. [Conclusiones](#conclusiones)


## Introduccion

El código entregado es un ejemplo de cómo utilizar la librería pikade Python para conectar a una cola de mensajes en RabbitMQ. El objetivo del código es simular un pedido de un cliente, de tal manera que el cliente pone los productos del pedido que quiere hacer, luego un robot busca los productos en una tienda y los almacena en una cola de mensajes. Despues si el robot encuentra los productos notifica si los ha encontrado o no mediante una segunda cola de mensajes. En caso de que el pedido se entrega.

## Funcionamiento

### Funcionamiento del cliente

Explicacion extendida de como funciona la clase cliente:

La clase Client se usa para definir un cliente que se conecta a un servicio y puede realizar pedidos. Esta clase tiene un constructor que toma como argumentos el nombre, contraseña y una bandera register. Si el valor de la bandera register es True, se crea una nueva instancia de Client con un nuevo id, nombre y contraseña, y se llama al método saveClient para guardar el cliente en una base de datos. En caso contrario, si el valor de la bandera register es False, se llama al método login para autenticar al cliente en la base de datos.

La clase también tiene los siguientes métodos:

saveClient(name, password): Este método se utiliza para guardar los detalles del cliente en la base de datos. Si el cliente ya existe en la base de datos, se emite una excepción ValueError para indicar que ya existe un usuario con ese nombre. En caso contrario, se inserta el cliente en la base de datos y se devuelve True.

login(name, password): Este método se utiliza para autenticar al cliente en la base de datos. Si el nombre de usuario y la contraseña coinciden, se devuelven el id del cliente y una lista de sus pedidos previos. Si no se encuentra un cliente con el nombre de usuario y contraseña proporcionados, se devuelve False junto con valores None.

realizarPedido(products): Este método se utiliza para realizar un pedido. El método crea una nueva instancia de Pedido con los productos proporcionados y llama al método getPedido para obtener la representación en cadena del pedido. Luego, el método inserta el pedido en la base de datos y envía el pedido a una cola de mensajes para que sea procesado por el servicio.

gestionar(e): Este método se utiliza para gestionar los mensajes que llegan a la cola de confirmación después de que se ha enviado un pedido. El método utiliza la biblioteca pika para recibir mensajes de la cola de confirmación y llamar al método actualizarPedido para actualizar el estado del pedido correspondiente.

actualizarEstadoPedido(id, estado): Este método se utiliza para actualizar el estado de un pedido. El método busca el pedido correspondiente en la lista de pedidos del cliente y actualiza su estado. Luego, devuelve el pedido actualizado.

cancelarPedido(i): Este método se utiliza para cancelar un pedido. El método llama al método actualizarEstadoPedido para actualizar el estado del pedido correspondiente a "CANCELADO". Luego, el método actualiza el pedido en la base de datos y envía un mensaje a la cola de mensajes para que el servicio cancele el pedido

### Funcionamiento del robot

Explicacion extendida de como funciona la clase robot:

El código consta de una clase Robotque se encarga de conectar a las colas de mensajes y buscar productos. La clase tiene los siguientes métodos:


connectToQueue(self, host, name): Este método se encarga de conectar a una cola de mensajes utilizando la librería pika. El método devuelve el canal y la conexión para que puedan ser utilizados posteriormente.

startFetchingMessages(self): Este método se encarga de empezar a recibir mensajes de la cola mensajes de utilizar el método basic_consumede pika. Este método llama a findProductcada vez que se recibe un mensaje.

searchProduct(self, ch, method, properties, body): Este método simula la búsqueda de un producto. El método utiliza time.sleeppara simular un tiempo de búsqueda y random.uniformpara generar un tiempo de búsqueda aleatorio dentro de un rango.

sendToQueue(self, message, channel, name): Este método se encarga de enviar un mensaje a una cola de mensajes utilizando channel.basic_publish.

findProduct(self, ch, method, properties, body): Este método se encarga de buscar el producto en la tienda utilizando el método searchProduct. Una vez se ha encontrado el producto o no, el método envía un mensaje a la segunda cola de mensajes utilizando sendToQueue. El método devuelve si se ha encontrado el producto o no.

### Funcionamiento del controlador

Explicacion extendida de como funciona la clase controlador:

Esta clase llamada Controlador es un componente del sistema de gestión de pedidos de una tienda o almacén. El propósito principal de esta clase es coordinar las diferentes partes del sistema que están involucradas en el proceso de recepción, almacenamiento y entrega de los pedidos.

El constructor de esta clase inicializa varias variables y conexiones necesarias para el funcionamiento del sistema, como listas de pedidos en el almacén y en la cinta transportadora, conexiones a colas de mensajes, entre otras. También inicia un hilo de ejecución llamado gestionar que es responsable de procesar los mensajes que llegan a las diferentes colas.

La función initQueue se utiliza para inicializar una conexión a una cola de mensajes. El parámetro host especifica la dirección del servidor de cola, queue es el nombre de la cola y exxaanje indica si la cola es de tipo exchange o no. Esta función devuelve un canal y una conexión a la cola.

La función gestionar es la que se ejecuta en un hilo y es responsable de recibir y procesar los mensajes que llegan a las diferentes colas. Específicamente, se encarga de procesar mensajes de confirmación de entrega del robot, de confirmación de entrega al cliente y de nuevos pedidos.

La función encintar es llamada cuando se recibe un mensaje de confirmación de entrega del robot. Esta función busca el pedido correspondiente en la lista de pedidos del almacén y lo marca como entregado si el robot lo entregó correctamente. Si hubo algún error, el pedido se marca como error en la entrega. En ambos casos, se notifica al cliente mediante el canal clientConfirmChannel que se ha entregado su pedido.

La función endDelivery es llamada cuando se recibe un mensaje de confirmación de entrega al cliente. Esta función busca el pedido correspondiente en la lista de pedidos de la cinta transportadora y lo marca como entregado o como error en la entrega según corresponda. También notifica al cliente mediante el canal clientConfirmChannel que se ha entregado su pedido o que ha habido un error en la entrega.

La función registrarPedido es llamada cuando se recibe un mensaje de un nuevo pedido. Esta función crea un nuevo objeto de la clase Pedido con la información del pedido recibida y lo agrega a la lista de pedidos del almacén.

### Funcionamiento del delivery

Explicacion extendida de como funciona la clase delivery:

Esta clase se utiliza para manejar la entrega de mensajes en una cola de mensajes mediante el protocolo AMQP (Advanced Message Queuing Protocol).

La clase Delivery define varios métodos para conectarse a la cola de mensajes, enviar y recibir mensajes de la cola y confirmar la recepción de los mensajes.

El método __init__ se encarga de establecer una conexión con la cola de mensajes a través de la función connectToQueue y asignar los canales y conexiones correspondientes para la entrega y confirmación de mensajes.

El método connectToQueue establece una conexión con la cola de mensajes especificada en los parámetros host y name utilizando la biblioteca pika y declara la cola para asegurar que exista en la cola de mensajes.

El método startFetchingMessages comienza a consumir mensajes de la cola de mensajes y los pasa al método deliver para su entrega.

El método deliver maneja la entrega de los mensajes recibidos de la cola de mensajes. Decodifica el mensaje, realiza una búsqueda aleatoria en el rango especificado por los parámetros serachMin y serachMax de la configuración de entrega para simular la búsqueda de un paquete y decide si el paquete se entregó o no. Luego, confirma la entrega del mensaje y envía una confirmación de la entrega a través del canal de confirmación.

El método sendToQueue se utiliza para enviar un mensaje a través del canal especificado en la cola de mensajes y garantizar que el mensaje sea persistente en la cola de mensajes mediante la definición de delivery_mode=pika.spec.PERSISTENT_DELIVERY_MODE.

En general, esta clase se utiliza para manejar la entrega de mensajes a través de una cola de mensajes y confirmar la recepción de mensajes entregados.

## Uso

Para utilizar el código, es necesario tener RabbitMQ instalado y ejecutarse en el host indicado en el archivo de configuración config.py. Además, es necesario tener instalada la librería pika.
Una vez realizado estos se debe abrir postgres
``` sh
sudo su - postgres
psql
```
Una vez ejecutados estos comandos te encontraras en la base de datos postgres, 
se debe cambiar la contraseña de esta base de datos por alumnodb:
``` sh
\password
alumnodb
```
Después creamos nuestra base de datos:
``` sh
CREATE DATABASE redes2
   WITH OWNER alumnodb;
\c redes2 alumnodb;

CREATE TABLE usuarios (
    id text NOT NULL,
    name text,
    password text
);

CREATE TABLE pedidos (
    id text NOT NULL,
    products text,
    estado text,
    productosEncintados text,
    clientId text
);
```

Ya podemos pasar ha ejecutar nustro codigo, ejemplo de uso:

Primero ejecutamos el launch_client y nos registramos:

``` sh
Hola buenas 
Bienvenido a Saimazoom 

Por favor elige una opción
1. Registrarse
2. Loguearse

Selección : 1
Introduce un nombre: miguel3

Introduce tu contraseña : 
Confirma tu contraseña : 
```

Una vez registrados podemos realizar un pedido:

``` sh
Bienvenido a Saimazoom 'miguel3' 

Por favor escoge lo que quieres hacer 

1: Hacer pedido
2: Ver tus pedidos 
3: Cancelar pedido 
4: Salir
```
Seleccionamos la opcion 1 para realizar el pedido:

``` sh
Has elegido hacer un pedido 
Para introducir un objeto escribelo y presiona enter 
Para terminar el pedido presiona enter 
Producto 0:limon
Producto 1:agua
Producto 2:puerros
Producto 3:lapiz
Producto 4:

Lista de la compra: 
['limon', 'agua', 'puerros', 'lapiz']
¿Confirmar selección? (s/n)

Bienvenido a Saimazoom 'miguel3' 

Pedido confirmado 👍

```

Ahora si seleccionamos ver pedidos:

``` sh
Tus pedidos: 
1: id: dd3f5c40-d7c0-11ed-a270-c5c5491cb352 | productos: ['limon', 'agua', 'puerros', 'lapiz'] | estado: Estados.ENALMACEN
```
Ahora podemos pasar a ejecutar el launch_controller.py,  el launch_robot y el launch_delivery.py:

``` sh
miguel@miguel-System-Product-Name:~/p2$ python3 launch_controller.py 
Starting controler 👌
Preparando pedido: dd3f5c40-d7c0-11ed-a270-c5c5491cb352
['limon', 'agua', 'puerros', 'lapiz'] ['']
Controler started 🤑
Encintando
Encintados 'True|dd3f5c40-d7c0-11ed-a270-c5c5491cb352|agua' 
Productos en cinta: ['agua'], total: ['limon', 'agua', 'puerros', 'lapiz']
Encintando
Encintados 'True|dd3f5c40-d7c0-11ed-a270-c5c5491cb352|puerros' 
Productos en cinta: ['agua', 'puerros'], total: ['limon', 'agua', 'puerros', 'lapiz']
dd3f5c40-d7c0-11ed-a270-c5c5491cb352|69c8217a-d7c0-11ed-a270-c5c5491cb352|Estados.ENALMACEN|limon|agua|puerros|lapiz ['limon', 'agua', 'puerros', 'lapiz']
Preparando pedido: dd3f5c40-d7c0-11ed-a270-c5c5491cb352
['limon', 'agua', 'puerros', 'lapiz'] []
Encintando
Encintados 'True|dd3f5c40-d7c0-11ed-a270-c5c5491cb352|limon' 
Productos en cinta: ['agua', 'puerros', 'limon'], total: ['limon', 'agua', 'puerros', 'lapiz']
Encintados 'True|dd3f5c40-d7c0-11ed-a270-c5c5491cb352|limon' 
Productos en cinta: ['limon'], total: ['limon', 'agua', 'puerros', 'lapiz']
Encintando
Encintados 'True|dd3f5c40-d7c0-11ed-a270-c5c5491cb352|lapiz' 
Productos en cinta: ['agua', 'puerros', 'limon', 'lapiz'], total: ['limon', 'agua', 'puerros', 'lapiz']
Productos en cinta <built-in function id>  Estados.ENCINTA
Encintando
Encintados 'True|dd3f5c40-d7c0-11ed-a270-c5c5491cb352|limon' 
Productos en cinta: ['limon', 'limon'], total: ['limon', 'agua', 'puerros', 'lapiz']
Encintando
Encintados 'True|dd3f5c40-d7c0-11ed-a270-c5c5491cb352|agua' 
Productos en cinta: ['limon', 'limon', 'agua'], total: ['limon', 'agua', 'puerros', 'lapiz']
Entregado 'dd3f5c40-d7c0-11ed-a270-c5c5491cb352' 
Encintando
Encintados 'True|dd3f5c40-d7c0-11ed-a270-c5c5491cb352|puerros' 
Productos en cinta: ['limon', 'limon', 'agua', 'puerros'], total: ['limon', 'agua', 'puerros', 'lapiz']
Encintando
Encintados 'True|dd3f5c40-d7c0-11ed-a270-c5c5491cb352|lapiz' 
Productos en cinta: ['limon', 'limon', 'agua', 'puerros', 'lapiz'], total: ['limon', 'agua', 'puerros', 'lapiz']
```

``` sh
miguel@miguel-System-Product-Name:~/p2$ python3 launch_robot.py 
Starting Robot 👌
Robot started 🤑
Searching for 'dd3f5c40-d7c0-11ed-a270-c5c5491cb352|limon'
Product found
Searching for 'dd3f5c40-d7c0-11ed-a270-c5c5491cb352|agua'
Product found
Searching for 'dd3f5c40-d7c0-11ed-a270-c5c5491cb352|puerros'
Product found
Searching for 'dd3f5c40-d7c0-11ed-a270-c5c5491cb352|lapiz'
Product found
Searching for 'dd3f5c40-d7c0-11ed-a270-c5c5491cb352|limon'
Product found
Searching for 'dd3f5c40-d7c0-11ed-a270-c5c5491cb352|agua'
Product found
Searching for 'dd3f5c40-d7c0-11ed-a270-c5c5491cb352|puerros'
Product found
Searching for 'dd3f5c40-d7c0-11ed-a270-c5c5491cb352|lapiz'
Product found

```
``` sh
miguel@miguel-System-Product-Name:~/p2$ python3 launch_delivery.py 
Starting delivery system 👌
Delivery system started 🤑
Delivering 'dd3f5c40-d7c0-11ed-a270-c5c5491cb352|DELIVER'
Delivered
```
Por ultimo si nos volvemos a loguear con nustra cuenta, podemos ver el nuevo estado del pedido:

``` sh
Tus pedidos: 
1: id: dd3f5c40-d7c0-11ed-a270-c5c5491cb352 | productos: ['limon', 'agua', 'puerros', 'lapiz'] | estado: Estados.ENTREGADO
```

## Conclusiones

### Conclusiones Técnicas
El código entregado es un ejemplo de cómo utilizar la librería pikade Python para conectar a una cola de mensajes en RabbitMQ. La librería pikaes una librería muy completa y flexible que permite trabajar con RabbitMQ de una manera sencilla.

El código entregado es un ejemplo de cómo se puede utilizar pikapara implementar un servicio de mensajería en Python. El código es sencillo y fácil de entender, pero se podría mejorar utilizando patrones de diseño más avanzados.

### Conclusiones Personales
La realización de esta memoria me ha permitido aprender sobre RabbitMQ y la librería pika. El código entregado es sencillo y fácil de entender, pero me ha permitido comprender los conceptos básicos de cómo funcionan las colas



