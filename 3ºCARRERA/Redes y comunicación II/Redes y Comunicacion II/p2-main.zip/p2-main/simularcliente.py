import _thread
import client
import time
import config
import pedido

def ejecutarCliente(name, password, productos, cancelar):
    c = None

    print("%r: Creando usuario" % name)
    try:
        c = client.Client(name, password, True)
    except:
        print("%r: Logueando usuario" % name)
        c = client.Client(name, password, False)
    
    print("%r: Creando pedido" % name)

    c.realizarPedido(productos)

    print("%r: Esperando a que el sistema opere" % name)

    if cancelar:
        print("%r: Cancelando pedido" % name)
        c.cancelarPedido(len(c.pedidos) - 1)
    else:
        while (c.pedidos[len(c.pedidos) - 1].estado == pedido.Estados.ENALMACEN):
            pass

    print("%r: El sistema ha operado y tenemos estos pedidos" % name)

    i = 0
    for p in c.pedidos:
        i+=1
        p.printPedido(i)


if __name__ == '__main__':
    print("Ola bienvenido al sistema de cliente")

    try:
        _thread.start_new_thread(ejecutarCliente, ("nonvre", "cotraxeña", {'e', 'e', 'e', 'e', 'e', 'e', 'e'}, False))
        _thread.start_new_thread(ejecutarCliente, ("Juan", "JuanitoAlpargata84", {'Patata', 'Limon', 'Lexuga'}, True))
    except Exception as e:
        print("Error: unable to start thread")
        print(e)
    
    while True:
        pass