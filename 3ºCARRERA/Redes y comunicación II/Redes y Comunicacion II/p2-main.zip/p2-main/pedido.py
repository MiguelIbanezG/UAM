import uuid
import psycopg2
from enum import Enum

class Estados(Enum):
    ENALMACEN = 1
    ENCINTA = 2
    ENREAPARTO = 3
    ENTREGADO = 4
    ERRORALMACEN = 5
    ERRORENTREGA = 6
    CANCELADO = 7

class Pedido:
    Estados = Enum('Estados', ['En almacen', 'En cinta', 'En reparto', 'Entregado', "Error almacen", "Error entrega", "Cancelado"])

    def __init__(self, products, clientId):
        self.id = uuid.uuid1()
        self.products = list(products)
        self.estado = Estados.ENALMACEN
        self.productosEncintados = list()
        self.idCliente = clientId

    # FUNCIÓN: cambiarEstado(self, estado)
    # ARGS_IN: estado del pedido
    # DESCRIPCIÓN: cambia el estado del pedido
    # ARGS_OUT: 
    def cambiarEstado(self, estado):
        self.estado = estado

        self.aktualizarEnBaseDeDatos()

    # FUNCIÓN: encintar(self, prod)
    # ARGS_IN: prod
    # DESCRIPCIÓN: encinta un producto especificado 
    # ARGS_OUT: ret
    def encintar(self, prod):
        ret = False

        if prod in self.products:
            self.productosEncintados.append(prod)
            ret = True

        print(f"Productos en cinta: {self.productosEncintados}, total: {self.products}")
        if sorted(self.productosEncintados) == sorted(self.products):
            self.estado = Estados.ENCINTA
            print("Productos en cinta %r " % id, self.estado)

        self.aktualizarEnBaseDeDatos()
        return ret

    # FUNCIÓN: parseRobotString(self, robotString
    # ARGS_IN: robotString: cadena dada que contiene información sobre un robot
    # DESCRIPCIÓN: analiza una cadena dada para obtener información sobre un robot que ha manejado el pedido
    # ARGS_OUT: 
    def parseRobotString(self, robotString):
        exito, id, prod = robotString.split("|")
        return exito, id, prod

    # FUNCIÓN: compararId(self, robotString)
    # ARGS_IN: robotString: cadena dada que contiene información sobre un robot
    # DESCRIPCIÓN: compara el ID del pedido con el ID en una cadena dada.
    # ARGS_OUT:     
    def compararId(self, robotString):
        exito, id, prod = self.parseRobotString(robotString)
        
        return id == str(self.id)


    # FUNCIÓN: checkearYEncintar(self, robotString)
    # ARGS_IN: robotString: cadena dada que contiene información sobre un robot
    # DESCRIPCIÓN: : verifica si el robot ha encintado el producto especificado y actualiza el estado del pedido
    # ARGS_OUT: 
    def checkearYEncintar(self, robotString):
        ret = False
        exito, id, prod = self.parseRobotString(robotString)

        if exito == "True" and self.compararId(robotString):
            print("Encintados %r " % robotString)
            ret = self.encintar(prod) 

        return ret

    # FUNCIÓN: getProduct(self, product)
    # ARGS_IN: product
    # DESCRIPCIÓN: devuelve el producto solicitado
    # ARGS_OUT: id del producto y el producto
    def getProduct(self, product):
        if product in self.products or product == "DELIVER":
            return str(self.id) + '|' + product

    # FUNCIÓN: getProductosString(self)
    # ARGS_IN: 
    # DESCRIPCIÓN: devuelve la lista de productos solicitada
    # ARGS_OUT: devuelve una cadena que contiene todos los productos que se han pedido
    def getProductosString(self):
        return self.getProductoStringFromList(self.products)

    # FUNCIÓN: getProductoStringFromList(self, cosas)
    # ARGS_IN: cosas: lista de productos
    # DESCRIPCIÓN: crea una cadena a partir de una lista de productos
    # ARGS_OUT: ret:lista de los productos en el formato correcto
    def getProductoStringFromList(self, cosas):
        ret = ""
        for prod in cosas:
            ret+="|" + prod 
        
        return ret[1:]

    # FUNCIÓN: getProductosNoEncintados(self)
    # ARGS_IN: 
    # DESCRIPCIÓN: devuelve una lista de los productos que aún no se han encintado
    # ARGS_OUT: noEncintados: lista de los productos que aún no se han encintado
    def getProductosNoEncintados(self):
        noEncintados = list(self.products)
      
        print(noEncintados, self.productosEncintados)

        if '' in self.productosEncintados:
            self.productosEncintados.remove('')
            
        for prod in self.productosEncintados:
            noEncintados.remove(prod)

        return noEncintados

    # FUNCIÓN: printPedido(self, i)
    # ARGS_IN: i: id del pedido
    # DESCRIPCIÓN: imprime el pedido y su informacion
    # ARGS_OUT: 
    def printPedido(self, i):
        print(f"{i}: id: {self.id} | productos: {self.products} | estado: {self.estado}")

    # FUNCIÓN: getPedido(self)
    # ARGS_IN: 
    # DESCRIPCIÓN: devuelve el pedido solicitado
    # ARGS_OUT: ret: cadena de caracteres con el id del pedido, el id del cliente y el estado del pedido, asi como el propio producto
    def getPedido(self):
        ret = ""
        ret+=str(self.id) + "|"
        ret+=str(self.idCliente) + "|"
        ret+=str(self.estado) + "|"
        
        ret += self.getProductosString()

        return ret
    
    # FUNCIÓN: aktualizarEnBaseDeDatos(self):
    # ARGS_IN: 
    # DESCRIPCIÓN: actualiza la base de datos
    # ARGS_OUT: 
    def aktualizarEnBaseDeDatos(self):
        conn = psycopg2.connect(database = "redes2", user = "postgres", password = "alumnodb", host = "localhost", port = "5432")
        cur = conn.cursor()
        cur.execute(
            "UPDATE pedidos SET estado = %r, productosEncintados = %r WHERE id = %r" % (str(self.estado), self.getProductoStringFromList(self.productosEncintados) , str(self.id))
        )

        conn.commit()
        
        conn.close()
