import random
import time
import config
import pika

class Robot:


    def __init__(self):
        q = self.connectToQueue(config.robotQueue["host"], config.robotQueue["Name"])
        
        self.channel = q[0] 
        self.connection = q[1] 

        confirmQ = self.connectToQueue(config.robotQueue["host"], config.robotQueue["confirmName"])

        self.confirmChannel = confirmQ[0] 
        self.confirmConnection = confirmQ[1] 

    # FUNCIÓN: startFetchingMessages(self)
    # ARGS_IN: 
    # DESCRIPCIÓN: conectar a una cola de mensajes utilizando la librería pika
    # ARGS_OUT: channel: canal de conexión, connection: conexion
    def connectToQueue(self, host, name):
        connection = pika.BlockingConnection(
            pika.ConnectionParameters(host=host)
        )
        channel = connection.channel()
    
        channel.queue_declare(queue=name, durable=True)

        return channel, connection

    # FUNCIÓN: startFetchingMessages(self)
    # ARGS_IN: 
    # DESCRIPCIÓN: Recibir mensajes de la cola mensajes
    # ARGS_OUT: 
    def startFetchingMessages(self):
        self.channel.basic_qos(prefetch_count=1)
        self.channel.basic_consume(queue=config.robotQueue["Name"], on_message_callback=self.findProduct)

        self.channel.start_consuming()

    # FUNCIÓN: searchProduct(self, ch, method, properties, body)
    # ARGS_IN: ch, method, properties, body
    # DESCRIPCIÓN: Busca el producto solicitado por el pedido del cliente
    # ARGS_OUT: 
    def searchProduct(self, ch, method, properties, body):
        print("Searching for %r" % body)
        searchTime = random.uniform(config.robot["serachMin"], config.robot["serachMax"])
        time.sleep(searchTime)

    # FUNCIÓN: sendToQueue(self, message, channel, name)
    # ARGS_IN: message, channel, name
    # DESCRIPCIÓN: Envia un mensaje a una cola de mensajes
    # ARGS_OUT: 
    def sendToQueue(self, message, channel, name):
        channel.basic_publish(
            exchange='',
            routing_key=name,
            body=message,
            properties=pika.BasicProperties(
                delivery_mode=pika.spec.PERSISTENT_DELIVERY_MODE
            )
        )

    # FUNCIÓN: findProduct(self, ch, method, properties, body)
    # ARGS_IN: ch, method, properties, body
    # DESCRIPCIÓN: confirma si se ha encontrado el producto
    # ARGS_OUT: found: dice si el producto a sido o no encontrado
    def findProduct(self, ch, method, properties, body):
        body = body.decode("utf-8")
        self.searchProduct(ch, method, properties, body)
        
        found = random.random() <= config.robot["p_almacen"]
        
        if found:
            print("Product found")
        else:
            print("Product not found 😞")
        
        ch.basic_ack(delivery_tag=method.delivery_tag)
        
        message = str(found) + "|" + body

        self.sendToQueue(message, self.confirmChannel, config.robotQueue["confirmName"])

        return found