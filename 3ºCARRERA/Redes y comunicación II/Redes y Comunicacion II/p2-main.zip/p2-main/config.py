robotQueue = dict({
    "host": "127.0.0.1",
    "Name": "robotQueueee",
    "confirmName": "robotConfirmmm"
})

deliveryQueue = dict({
    "host": "127.0.0.1",
    "Name": "deliveryQueueee",
    "confirmName": "deliveryConfirmmm"
})

clientQueue = dict({
    "host": "127.0.0.1",
    "Name": "clientQueueee",
    "confirmName": "clientConfirmmm"
})

robot = dict({
    "serachMin": 5,
    "serachMax": 10,
    "p_almacen": .9
})

delivery = dict({
    "serachMin": 10,
    "serachMax": 20,
    "p_almacen": .9
})