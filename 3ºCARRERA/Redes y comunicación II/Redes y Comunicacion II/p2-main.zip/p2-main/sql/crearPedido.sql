INSERT INTO pedidos (id, products, estado, productosEncintados, clientId)
VALUES ('123456789-123456789-123456789', 'asdf|asdf|asdf|asdf|asdf', 'Estados.CANCELADO', 'asdf|asdf', '123456789-123456789-123456789');

INSERT INTO pedidos (id, products, estado, productosEncintados, clientId)
VALUES ('123456789-123456789-123456788', 'asdf|asdf|asdf|asdf|asdf', 'Estados.CANCELADO', 'asdf|asdf', '123456789-123456789-123456789');