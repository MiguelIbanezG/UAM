/**
 * Para hacer funcionar esto primero crear usuario de postgres
 * alumnodb alumnodb
 * de esta forma
 * 
 * sudo -u postgres createuser -e alumnodb
 * 
 * despues hacemos
 * sudo su - postgres
 * psql
 * \i <path>/crearDatabase.sql
 * en caso de que el script de errores
 * ejecutar:
 * 
 * sudo su - postgres
 * psql
 * CREATE DATABASE redes2;
 * \c redes2 alumnodb;
**/

DROP DATABASE redes2;

DROP TABLE usuarios;

DROP TABLE pedidos;

CREATE DATABASE redes2
   WITH OWNER alumnodb;

CREATE TABLE usuarios (
    id text NOT NULL,
    name text,
    password text
);

CREATE TABLE pedidos (
    id text NOT NULL,
    products text,
    estado text,
    productosEncintados text,
    clientId text
);