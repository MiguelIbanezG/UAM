UPDATE pedidos
SET estado = 'asdfkjasdfksadfhaskdff', productosEncintados = 'ee'
WHERE id = '123456789-123456789-123456789';