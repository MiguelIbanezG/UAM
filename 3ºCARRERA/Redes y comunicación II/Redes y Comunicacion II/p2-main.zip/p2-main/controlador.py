import pedido
import config
import pika
import _thread
import psycopg2

class Controlador:

    def __init__(self):
        self.pedidosAlmacen = list()
        self.pedidosCinta = list()

        robotQueue = self.initQueue(config.robotQueue["host"], config.robotQueue['Name'])

        self.robotQueueChannel = robotQueue[0]
        self.robotQueueConnection = robotQueue[1]

        robotConfirm = self.initQueue(config.robotQueue["host"], config.robotQueue["confirmName"])

        self.robotConfirmChannel = robotConfirm[0]
        self.robotConfirmConnection = robotConfirm[1]
        
        deliveryQueue = self.initQueue(config.deliveryQueue["host"], config.deliveryQueue['Name'])

        self.deliveryQueueChannel = deliveryQueue[0]
        self.deliveryQueueConnection = deliveryQueue[1]

        deliveryConfirm = self.initQueue(config.deliveryQueue["host"], config.deliveryQueue["confirmName"])

        self.deliveryConfirmChannel = deliveryConfirm[0]
        self.deliveryConfirmConnection = deliveryConfirm[1]

        clientQueue = self.initQueue(config.clientQueue["host"], config.clientQueue['Name'])

        self.clientQueueChannel = clientQueue[0]
        self.clientQueueConnection = clientQueue[1]

        clientConfirm = self.initQueue(config.clientQueue["host"], config.clientQueue["confirmName"], True)
        
        self.clientConfirmChannel = clientConfirm[0] 
        self.clientConfirmConnection = clientConfirm[1] 

        self.sakarPedidosDBase()

        self.prepararFullPedidos()

        try:
            _thread.start_new_thread(self.gestionar, ("e",))
        except Exception as e:
            print("Error: unable to start thread")
            print(e)

    # FUNCIÓN: initQueue(self, host, queue, exxaanje=False)
    # ARGS_IN: host: especifica la dirección del servidor de cola, queue: cola, exxaanje: tipo exchange o no
    # DESCRIPCIÓN: Inicializa una conexión a una cola de mensajes
    # ARGS_OUT: channel: canal de conexion, connection: conexion
    def initQueue(self, host, queue, exxaanje=False):
        connection = pika.BlockingConnection(
            pika.ConnectionParameters(host=host)
        )

        channel = connection.channel()

        if (exxaanje == True):
            channel.exchange_declare(exchange='logs', exchange_type='fanout')

        channel.queue_declare(queue=queue, durable=True)


        return channel, connection 

   # FUNCIÓN: gestionar(self, e)
    # ARGS_IN: e
    # DESCRIPCIÓN: Procesamensajes de confirmación de entrega del robot
    # ARGS_OUT: 
    def gestionar(self, e):
        self.robotConfirmChannel.basic_qos(prefetch_count=1)
        self.robotConfirmChannel.basic_consume(queue=config.robotQueue["confirmName"], on_message_callback=self.encintar)

        self.deliveryConfirmChannel.basic_qos(prefetch_count=1)
        self.deliveryConfirmChannel.basic_consume(queue=config.deliveryQueue["confirmName"], on_message_callback=self.endDelivery)

        self.clientQueueChannel.basic_qos(prefetch_count=1)
        self.clientQueueChannel.basic_consume(queue=config.clientQueue["Name"], on_message_callback=self.registrarPedido)
        # self.robotConfirmChannel.start_consuming()
        while self.robotConfirmChannel._consumer_infos:
            self.clientQueueChannel.connection.process_data_events(time_limit=1) 
            self.robotConfirmChannel.connection.process_data_events(time_limit=1) 
            self.deliveryConfirmChannel.connection.process_data_events(time_limit=1) 
    
    # FUNCIÓN: endDelivery(self, ch, method, properties, body)
    # ARGS_IN: ch, method, properties, body
    # DESCRIPCIÓN: se comprueba si se ha entregado el pedido o ha falldo
    # ARGS_OUT: 
    def endDelivery(self, ch, method, properties, body):
        body = body.decode("utf-8")

        for p in self.pedidosCinta: 
            if p.compararId(body):
                parsedBody = p.parseRobotString(body)
                if parsedBody[0] == "False":
                    print("Ha fallado la entrega de %r" % parsedBody[1])

                    p.estado = pedido.Estados.ERRORENTREGA
                else: 
                    p.estado = pedido.Estados.ENTREGADO
           
                p.aktualizarEnBaseDeDatos()
                self.pedidosCinta.remove(p)
                print("Entregado %r " % parsedBody[1])
    
                self.notificarEntrega(p)
                    
        ch.basic_ack(delivery_tag=method.delivery_tag)

    # FUNCIÓN: notificarEntrega(self, p)
    # ARGS_IN: p: pedido
    # DESCRIPCIÓN: notifica la entrega del pedido
    # ARGS_OUT: 
    def notificarEntrega(self, p):
        message = p.getPedido()
        self.clientConfirmChannel.basic_publish(exchange='logs', routing_key='', body=message)

    # FUNCIÓN: encintar(self, ch, method, properties, body)
    # ARGS_IN: ch, method, properties, body
    # DESCRIPCIÓN:Busca el pedido correspondiente y lo marca como entregado o no 
    # ARGS_OUT: 
    def encintar(self, ch, method, properties, body):
        body = body.decode("utf-8")
        
        print("Encintando")  
        for p in self.pedidosAlmacen: 
            if p.compararId(body) and p.estado != pedido.Estados.CANCELADO:

                if p.checkearYEncintar(body) == False:
                    parsedBody = p.parseRobotString(body)

                    print("Ha fallado el robot cogiendo %r" % parsedBody[2])
                    p.estado = pedido.Estados.ERRORALMACEN

                    self.notificarEntrega(p)

                p.aktualizarEnBaseDeDatos()

                if p.estado == pedido.Estados.ENCINTA:
                    self.pedidosAlmacen.remove(p)
                    self.pedidosCinta.append(p)
                    self.sendToQueue(p.getProduct("DELIVER"), self.deliveryConfirmChannel, config.deliveryQueue['Name'])

        ch.basic_ack(delivery_tag=method.delivery_tag)

    # FUNCIÓN: closequeue(self, connection)
    # ARGS_IN: connection
    # DESCRIPCIÓN: cierra la conexión de la cola
    # ARGS_OUT: 
    def closequeue(self, connection):
        connection.close()

    # FUNCIÓN: registrarPedido(self, ch, method, properties, body)
    # ARGS_IN: products: ch, method, properties, body
    # DESCRIPCIÓN: registra el pedido que ha solicitdo el cliente
    # ARGS_OUT: 
    def registrarPedido(self, ch, method, properties, body):
        body = body.decode("utf-8")
        ch.basic_ack(delivery_tag=method.delivery_tag)

        pedidoSpliteao = body.split("|")

        id = pedidoSpliteao[0]
        idCliente = pedidoSpliteao[1]
        estado = pedidoSpliteao[2]
        productos = list()

        i = 0
        for prod in pedidoSpliteao:
            i+=1

            if i <= 3:
                continue
            productos.append(prod)
        
        print(body, productos)
        p = pedido.Pedido(productos, idCliente)


        p.id = id
        p.estado = estado

        if estado == str(pedido.Estados.CANCELADO):
            # for ped in self.pedidosCinta:
            #     if str(ped.id) == p.id:
            #         print("cancelao")
            #         ped.aktualizarEnBaseDeDatos()
            #         self.pedidosCinta.remove(p)
            #         return
            for ped in self.pedidosAlmacen:
                if str(ped.id) == p.id:
                    ped.estado = pedido.Estados.CANCELADO
                    ped.aktualizarEnBaseDeDatos()
                    self.pedidosAlmacen.remove(ped)
                    return

        self.pedidosAlmacen.append(p)
        p.aktualizarEnBaseDeDatos()
        self.prepararPedido(p)

    # FUNCIÓN: prepararFullPedidos(self)
    # ARGS_IN: 
    # DESCRIPCIÓN: prepara todos los pedidos
    # ARGS_OUT: 
    def prepararFullPedidos(self):
        almacen = list(self.pedidosAlmacen)
        for p in almacen:
            self.prepararPedido(p)
        
        cinta = list(self.pedidosCinta)
        for p in cinta:
            self.sendToQueue(p.getProduct("DELIVER"), self.deliveryConfirmChannel, config.deliveryQueue['Name'])

    # FUNCIÓN: prepararPedido(self, pedido
    # ARGS_IN: pedido del cliente
    # DESCRIPCIÓN: prepara el pedido que ha solicitado el cliente
    # ARGS_OUT: 
    def prepararPedido(self, pedido):
        print(f"Preparando pedido: {pedido.id}")
        
        for prod in pedido.getProductosNoEncintados():
            self.sendToQueue(pedido.getProduct(prod), self.robotQueueChannel, config.robotQueue['Name'])

    # FUNCIÓN: sendToQueue(self, message, channel, name)
    # ARGS_IN: message, channel, name
    # DESCRIPCIÓN: 
    # ARGS_OUT: 
    def sendToQueue(self, message, channel, name):
        channel.basic_publish(
            exchange='',
            routing_key=name,
            body=message,
            properties=pika.BasicProperties(
                delivery_mode=pika.spec.PERSISTENT_DELIVERY_MODE
            )
        )

    # FUNCIÓN: sakarPedidosDBase(self)
    # ARGS_IN: 
    # DESCRIPCIÓN: saca los pedidos del almacen para enviarlos
    # ARGS_OUT: 
    def sakarPedidosDBase(self):
        conn = psycopg2.connect(database = "redes2", user = "postgres", password = "alumnodb", host = "localhost", port = "5432")
        cur = conn.cursor()
        cur.execute(
            "select * from pedidos WHERE estado='Estados.ENALMACEN'"

        )

        rows = cur.fetchall()
        

        for row in rows:
            products = list(row[1].split("|"))
            
            id = row[4]

            p = pedido.Pedido(products, id)

            p.id = row[0]
            p.estado = row[2]
            p.productosEncintados = list(row[3].split("|"))

            self.pedidosAlmacen.append(p)

        conn.close()

        conn = psycopg2.connect(database = "redes2", user = "postgres", password = "alumnodb", host = "localhost", port = "5432")
        cur = conn.cursor()
        cur.execute(
            "select * from pedidos WHERE estado='Estados.ENCINTA'"
        )

        rows = cur.fetchall()
        

        for row in rows:
            products = list(row[1].split("|"))
            
            id = row[4]

            p = pedido.Pedido(products, id)

            p.id = row[0]
            p.estado = row[2]
            p.productosEncintados = list(row[3].split("|"))
            self.pedidosCinta.append(p)

        conn.close()
