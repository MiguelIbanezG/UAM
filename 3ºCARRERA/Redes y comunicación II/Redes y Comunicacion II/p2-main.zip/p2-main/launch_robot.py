import robot

if __name__ == '__main__':
    print("Starting Robot 👌")

    r = robot.Robot()
    
    print("Robot started 🤑")
    
    r.startFetchingMessages()
    
    print("Fetching messages 🤓")