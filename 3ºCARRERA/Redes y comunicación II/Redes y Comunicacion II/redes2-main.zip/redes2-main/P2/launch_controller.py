import controlador
import pedido

if __name__ == '__main__':
    print("Starting controler 👌")

    c = controlador.Controlador()

    print("Controler started 🤑")
    

    while True:
        pass