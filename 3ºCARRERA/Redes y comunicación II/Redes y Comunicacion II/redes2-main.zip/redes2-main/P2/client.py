import uuid
import pika
import pedido
import config
import _thread
import psycopg2

class Client:
    def __init__(self, name, password, resgister):
        if resgister:
            self.id = uuid.uuid1()
            self.name = name
            self.password = password
            
            if self.saveClient(name, password) == None:
                raise ValueError('Usuario existe')
            
            self.pedidos = list()

        else:
            correcto, self.id, self.pedidos, self.name, self.password = self.login(name, password)
            
            if correcto == False:
                raise ValueError('Usuario o contraseña incorrectos')
        
        q = self.connectToQueue(config.clientQueue["host"], config.clientQueue["Name"])
        
        self.channel = q[0] 
        self.connection = q[1] 

        confirmQ = self.connectToQueue(config.clientQueue["host"], config.clientQueue["confirmName"], True)
        
        self.confrimChannel = confirmQ[0] 
        self.confrimConnection = confirmQ[1] 
        self.confrimResult = confirmQ[2] 

        try:
            _thread.start_new_thread(self.gestionar, ("e",))
        except Exception as e:
            print("Error: unable to start thread")
            print(e)
    
    # FUNCIÓN: saveClient(self, name, password)
    # ARGS_IN: name: nombre del cliente, password: contraseña del cliente
    # DESCRIPCIÓN: Comprueba si el usuario registrado ya existe y si no lo guarda
    # ARGS_OUT: True
    def saveClient(self, name, password):
        if self.login(name, password)[0] == True:
            print("Usuario existente")
            return None
        
        conn = psycopg2.connect(database = "redes2", user = "postgres", password = "alumnodb", host = "localhost", port = "5432")
        cur = conn.cursor()
        cur.execute("SELECT id FROM usuarios WHERE usuarios.name=%r" % name)
        rows = cur.fetchall()

        if cur.rowcount != 0:
            print("Usuario existente")
            conn.close()
            return None

        conn.close()


        conn = psycopg2.connect(database = "redes2", user = "postgres", password = "alumnodb", host = "localhost", port = "5432")
        cur = conn.cursor()

        cur.execute(
            "INSERT INTO usuarios (id, name, password) VALUES (%r, %r, %r);" % (str(self.id), name, password)
        )

        conn.commit()
        conn.close()

        return True

    # FUNCIÓN: login(self, name, password)
    # ARGS_IN: name: nombre del cliente, password: contraseña del cliente
    # DESCRIPCIÓN: Loguea un cliente
    # ARGS_OUT: correcto: boolean para saber si se ha logueado, id del cliente, pedidos del cliente, name del cliente y password del cliente
    def login(self, name, password):
        pedidos = list()
        correcto = False
        id = "e"

        conn = psycopg2.connect(database = "redes2", user = "postgres", password = "alumnodb", host = "localhost", port = "5432")
        cur = conn.cursor()
        cur.execute("SELECT id FROM usuarios WHERE usuarios.name=%r AND usuarios.password=%r" % (name, password))
        rows = cur.fetchall()

        if cur.rowcount == 0:
            return False, None, None, None, None
        
        for row in rows:
            correcto = True
            id = row[0]

        conn.close()

        conn = psycopg2.connect(database = "redes2", user = "postgres", password = "alumnodb", host = "localhost", port = "5432")
        cur = conn.cursor()
        cur.execute(
            "WITH login as (SELECT id FROM usuarios WHERE usuarios.name=%r AND usuarios.password=%r) SELECT pedidos.id, pedidos.products, pedidos.estado, pedidos.productosEncintados, pedidos.clientId FROM pedidos INNER JOIN login ON login.id = pedidos.clientId" % (name, password)
        )
        rows = cur.fetchall()
        
         
        for row in rows:
            products = list(row[1].split("|"))

            p = pedido.Pedido(products, id)

            p.id = row[0]
            p.estado = row[2]
            p.productosEncintados = list(row[3].split("|"))

            pedidos.append(p)

        conn.close()
        return correcto, id, pedidos, name, password


    # FUNCIÓN: realizarPedido(self, products)
    # ARGS_IN: products: lista de productosa del pedido
    # DESCRIPCIÓN: realiza el pedido, ingresa los preductos en el pedido
    # ARGS_OUT: 
    def realizarPedido(self, products):
        p = pedido.Pedido(products, self.id)

        self.pedidos.append(p)

        message = p.getPedido()


        conn = psycopg2.connect(database = "redes2", user = "postgres", password = "alumnodb", host = "localhost", port = "5432")
        cur = conn.cursor()
        cur.execute(
            " INSERT INTO pedidos (id, products, estado, productosEncintados, clientId) VALUES (%r, %r, %r, %r, %r);" % (str(p.id), p.getProductosString(), str(p.estado), "", str(p.idCliente))
        )

        conn.commit()
        
        conn.close()

        self.sendToQueue(message, self.channel, config.clientQueue["Name"])

    # FUNCIÓN: gestionar(self, e)
    # ARGS_IN: e
    # DESCRIPCIÓN: 
    # ARGS_OUT: 
    def gestionar(self, e):
        queue_name = self.confrimResult.method.queue

        self.confrimChannel.queue_bind(exchange='logs', queue=queue_name)
        
        self.confrimChannel.basic_consume(
            queue=queue_name, on_message_callback=self.actualizarPedido, auto_ack=True)

        self.confrimChannel.start_consuming()
        
    # FUNCIÓN: actualizarEstadoPedido(self, id, estado)
    # ARGS_IN: id del pedido y estado del pedido
    # DESCRIPCIÓN: actualiza el pedido con nnuevo estado y un nuevo id
    # ARGS_OUT: p: pedido
    def actualizarEstadoPedido(self, id, estado):
        for p in self.pedidos:
            if str(p.id) == id:
                p.estado = estado

                return p

    # FUNCIÓN: cancelarPedido(self, products)
    # ARGS_IN: i
    # DESCRIPCIÓN: 
    # ARGS_OUT: 
    def cancelarPedido(self, i):
        p = self.actualizarEstadoPedido(str(self.pedidos[i].id), pedido.Estados.CANCELADO)

        message = p.getPedido()
        p.aktualizarEnBaseDeDatos()

        self.sendToQueue(message, self.channel, config.clientQueue["Name"])

    # FUNCIÓN: actualizarPedido(self, ch, method, properties, body)
    # ARGS_IN: ch, method, properties, body
    # DESCRIPCIÓN: 
    # ARGS_OUT: 
    def actualizarPedido(self, ch, method, properties, body):
        body = body.decode("utf-8") 


        pedidoSpliteao = body.split("|")
        
        if pedidoSpliteao[1] != str(self.id):
            return

        self.actualizarEstadoPedido(pedidoSpliteao[0], pedidoSpliteao[2])

    # FUNCIÓN: connectToQueue(self, host, name, exxaanje)
    # ARGS_IN: host, name, exxaanje=False
    # DESCRIPCIÓN: 
    # ARGS_OUT: 
    def connectToQueue(self, host, name, exxaanje=False):
        connection = pika.BlockingConnection(
            pika.ConnectionParameters(host=host)
        )
        channel = connection.channel()
    
        if (exxaanje == True):
            channel.exchange_declare(exchange='logs', exchange_type='fanout')

        result = channel.queue_declare(queue=name, durable=True)


        return channel, connection, result

    # FUNCIÓN: sendToQueue(self, message, channel, name)
    # ARGS_IN: message, channel, name
    # DESCRIPCIÓN: 
    # ARGS_OUT: 
    def sendToQueue(self, message, channel, name):
        channel.basic_publish(
            exchange='',
            routing_key=name,
            body=message,
            properties=pika.BasicProperties(
                delivery_mode=pika.spec.PERSISTENT_DELIVERY_MODE
            )
        )
