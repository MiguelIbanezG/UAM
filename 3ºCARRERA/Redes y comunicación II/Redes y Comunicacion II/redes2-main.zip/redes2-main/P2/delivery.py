import pika
import config
import random
import time

class Delivery:
    def __init__(self):
        q = self.connectToQueue(config.deliveryQueue["host"], config.deliveryQueue["Name"])
        
        self.channel = q[0] 
        self.connection = q[1] 

        confirmQ = self.connectToQueue(config.deliveryQueue["host"], config.deliveryQueue["confirmName"])

        self.confirmChannel = confirmQ[0] 
        self.confirmConnection = confirmQ[1] 

    # FUNCIÓN: connectToQueue(self, host, name)
    # ARGS_IN: host, name
    # DESCRIPCIÓN: 
    # ARGS_OUT: 
    def connectToQueue(self, host, name):
        connection = pika.BlockingConnection(
            pika.ConnectionParameters(host=host)
        )
        channel = connection.channel()
    
        channel.queue_declare(queue=name, durable=True)

        return channel, connection

    # FUNCIÓN: startFetchingMessages(self)
    # ARGS_IN: 
    # DESCRIPCIÓN: 
    # ARGS_OUT:    
    def startFetchingMessages(self):
        self.channel.basic_qos(prefetch_count=1)
        self.channel.basic_consume(queue=config.deliveryQueue["Name"], on_message_callback=self.deliver)

        self.channel.start_consuming()

    # FUNCIÓN: deliver(self, ch, method, properties, body)
    # ARGS_IN: ch, method, properties, body
    # DESCRIPCIÓN: 
    # ARGS_OUT: 
    def deliver(self, ch, method, properties, body):
        body = body.decode("utf-8")

        print("Delivering %r" % body)
        searchTime = random.uniform(config.delivery["serachMin"], config.delivery["serachMax"])
        time.sleep(searchTime)

        found = random.random() <= config.delivery["p_almacen"]
        
        if found:
            print("Delivered")
        else:
            print("Not delivered 😞")
        
        ch.basic_ack(delivery_tag=method.delivery_tag)
        
        message = str(found) + "|" + body

        self.sendToQueue(message, self.confirmChannel, config.deliveryQueue["confirmName"])

        return found
        
    # FUNCIÓN: sendToQueue(self, message, channel, name)
    # ARGS_IN: message, channel, name
    # DESCRIPCIÓN: 
    # ARGS_OUT: 
    def sendToQueue(self, message, channel, name):
        channel.basic_publish(
            exchange='',
            routing_key=name,
            body=message,
            properties=pika.BasicProperties(
                delivery_mode=pika.spec.PERSISTENT_DELIVERY_MODE
            )
        )