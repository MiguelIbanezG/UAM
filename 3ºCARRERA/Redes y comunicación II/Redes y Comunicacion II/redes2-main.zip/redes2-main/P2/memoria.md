# PRACTICA 1 REDES II
### Grupo: 2323
### Autores: Javier y Miguel Ibáñez González

## Indice
1. [Introduccion](#introduccion)
2. [Diseño](#diseño)
3. [Uso](#uso)
4. [Scripts](#scripts)
5. [Conclusiones](#conclusiones)


## Introduccion

El código entregado es un ejemplo de cómo utilizar la librería pikade Python para conectar a una cola de mensajes en RabbitMQ. El objetivo del código es simular un robot que busca productos en una tienda y los almacena en una cola de mensajes. Además, el robot notifica si ha encontrado el producto o no mediante una segunda cola de mensajes

## Diseño

El código consta de una clase Robotque se encarga de conectar a las colas de mensajes y buscar productos. La clase tiene los siguientes métodos:


connectToQueue(self, host, name): Este método se encarga de conectar a una cola de mensajes utilizando la librería pika. El método devuelve el canal y la conexión para que puedan ser utilizados posteriormente.

startFetchingMessages(self): Este método se encarga de empezar a recibir mensajes de la cola mensajes de utilizar el método basic_consumede pika. Este método llama a findProductcada vez que se recibe un mensaje.

searchProduct(self, ch, method, properties, body): Este método simula la búsqueda de un producto. El método utiliza time.sleeppara simular un tiempo de búsqueda y random.uniformpara generar un tiempo de búsqueda aleatorio dentro de un rango.

sendToQueue(self, message, channel, name): Este método se encarga de enviar un mensaje a una cola de mensajes utilizando channel.basic_publish.

findProduct(self, ch, method, properties, body): Este método se encarga de buscar el producto en la tienda utilizando el método searchProduct. Una vez se ha encontrado el producto o no, el método envía un mensaje a la segunda cola de mensajes utilizando sendToQueue. El método devuelve si se ha encontrado el producto o no.


## Uso

Para utilizar el código, es necesario tener RabbitMQ instalado y ejecutarse en el host indicado en el archivo de configuración config.py. Además, es necesario tener instalada la librería pika.


## Scripts


## Conclusiones

### Conclusiones Técnicas
El código entregado es un ejemplo de cómo utilizar la librería pikade Python para conectar a una cola de mensajes en RabbitMQ. La librería pikaes una librería muy completa y flexible que permite trabajar con RabbitMQ de una manera sencilla.

El código entregado es un ejemplo de cómo se puede utilizar pikapara implementar un servicio de mensajería en Python. El código es sencillo y fácil de entender, pero se podría mejorar utilizando patrones de diseño más avanzados.

### Conclusiones Personales
La realización de esta memoria me ha permitido aprender sobre RabbitMQ y la librería pika. El código entregado es sencillo y fácil de entender, pero me ha permitido comprender los conceptos básicos de cómo funcionan las colas



