WITH login as (
    SELECT id 
    FROM usuarios
    WHERE usuarios.name='alumnodb' AND usuarios.password='alumnodb'
) 
SELECT pedidos.id, pedidos.products, pedidos.estado, pedidos.productosEncintados, pedidos.clientId 
FROM pedidos
INNER JOIN login 
ON login.id = pedidos.clientId