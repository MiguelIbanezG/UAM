INSERT INTO usuarios (id, name, password)
VALUES ('123456789-123456789-123456789', 'alumnodb', 'alumnodb');
