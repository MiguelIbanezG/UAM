from getpass import getpass
import client
import time
import os
import random

def hacerPedido(c):
    os.system('clear')

    products = list()
    product = str(random.uniform(0, 2122934812340123)) + "sadlfasdf"
 
    print("Has elegido hacer un pedido ")
    print("Para introducir un objeto escribelo y presiona enter ")
    print("Para terminar el pedido presiona enter ")

    while product:
        product = input("Producto %r:" % len(products))

        if product:
            products.append(product)

    decision = str(random.uniform(0, 2122934812340123)) + "sdfñlahskjdf"

    while decision != "s" and decision != "n" and decision != "S" and decision != 'N':
        os.system('clear')
        print("Lista de la compra: ")
        print(products)
        decision = input("¿Confirmar selección? (s/n)")

    if decision == 's' or decision == 'S':
        c.realizarPedido(products)
        return "Pedido confirmado 👍"
    else:
        return "Pedido cancelado 👎"

def verPedidos(c):
    os.system('clear')

    print("Tus pedidos: ")

    i = 0
    for p in c.pedidos:
        i+=1
        p.printPedido(i)

    input()

    return ""

def cancelarPedido(c):
    print("Elige el pedido que quieras cancelar: ")

    i = 0
    for p in c.pedidos:
        i+=1
        p.printPedido(i)

    cancelar = input("¿Qué pedido quieres cancelar?:")

    if int(cancelar) <= i and int(cancelar) >= 0:
        c.cancelarPedido(int(cancelar) - 1)
        return "Pedido cancelado "

    return "Error cancelando pedido "

def registrar():
    c = None
    name = input("Introduce un nombre: ")

    password = str(random.uniform(0, 2122934812340123)) + "cadena" + "aleatoria"
    passwordConf = str(random.uniform(0, 2122934812340123)) + "aleatoria" + "cadena"

    while passwordConf != password:
        password = getpass("\nIntroduce tu contraseña : ")
        passwordConf = getpass("Confirma tu contraseña : ")

        if passwordConf != password:
            print("Las contraseñas no coinciden ")
            print("Vamos a volver a intentarlo ")

    try:
        c = client.Client(name, password, True)
    except:
        print("Usuario existe")
        c = None

    if c == None:
        c = registrar()
        
    return c


def login():
    c = None

    name = str(random.uniform(0, 2122934812340123)) + "cadena" + "aleatoria"
    password = str(random.uniform(0, 2122934812340123)) + "aleatoria" + "cadena"

    while c == None:
        name = input("\nIntroduce tu usuario : ")
        password = getpass("Introduce tu contraseña : ")

        if name and password:
            try:
                c = client.Client(name, password, False)
            except:
                c = None
    
        if c == None or not(name) or not(password):
            print("Mal")
    
    return c

if __name__ == '__main__':
    os.system('clear')
    c = 1

    print("Hola buenas ")
    print("Bienvenido a Saimazoom ")

    select = "0"

    while select != "1" and select != "2":
        print("\nPor favor elige una opción")
        print("1. Registrarse")
        print("2. Loguearse")

        select = input("\nSelección : ")

        if select == "1":
            c = registrar()
        elif select == "2":
            c = login()
        else:
            print("Tienes que meter 1 o 2")


    select = "0"

    mensajeDevolver = ""

    while select != "4":
        os.system('clear')

        print("Bienvenido a Saimazoom %r " % c.name)

        print("\n" + mensajeDevolver)

        print("\nPor favor escoge lo que quieres hacer \n")
        print("1: Hacer pedido")
        print("2: Ver tus pedidos ")
        print("3: Cancelar pedido ")
        print("4: Salir")

        select = input("\nSelección : ")


        if select == "1":
            mensajeDevolver = hacerPedido(c)
        elif select == "2":
            mensajeDevolver = verPedidos(c)
        elif select == "3":
            mensajeDevolver = cancelarPedido(c)
        elif select == "4":
            print("Adioos 👋")
        else:
            mensajeDevolver = "\nEl número debe estar entre 1 y 4"
