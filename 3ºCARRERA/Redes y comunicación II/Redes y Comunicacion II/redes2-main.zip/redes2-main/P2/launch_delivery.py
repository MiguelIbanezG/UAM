import delivery

if __name__ == '__main__':
    print("Starting delivery system 👌")

    s = delivery.Delivery()
    
    print("Delivery system started 🤑")
    
    s.startFetchingMessages()
    
    print("Fetching messages 🤓")