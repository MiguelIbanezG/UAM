#include <stdio.h>
#include <stdlib.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <confuse.h>

#include "../include/serverutils.h"

#define BUFMAX 16384
#define MAXMODE 10
#define MAXBUFFERTOCHO 16384


void * _tarea(void *input);
void _create_thread_pool(server *s);
void _parse_http_error(http_request *req, char * buffer, char*msg);

void * _tarea(void *input) {
    server *s = NULL;

    s = (server*) input;
    
    s->conf.f(s);

    return NULL;
}

/*********
* FUNCIÓN: void _create_thread_pool(server *s) 
* ARGS_IN: server *s 
* DESCRIPCIÓN: Crea los hilos tenienddo en cuenta el maximo de peticiones
* ARGS_OUT: 
*********/
void _create_thread_pool(server *s) {
    int i, status;

    sem_init(&s->paloshilos, 0, 1);
    
    if (s == NULL) {
        return;
    }

    s->thread_pool = (pthread_t*) malloc(s->conf.max_connections * sizeof(pthread_t));

    if (s->thread_pool == NULL) {
        return;
    }

    for (i = 0; i < s->conf.max_connections; i++) {
        status = pthread_create(&s->thread_pool[i], NULL, &_tarea, s);

        if (status != 0) {
            free_server(s);
        }
    }
}

/*********
* FUNCIÓN: s_conf server_config(char *confPath)
* ARGS_IN: char *confPath
* DESCRIPCIÓN: Inicializa la configuración del sevidor (puerto, maximo de coneciones...)
* ARGS_OUT: s_conf config;
*********/
s_conf server_config(char *confPath) {
    s_conf config;
    static char *root;
    static char *signature;
    static long int port = 8080;
    static long int max_connections = 5;
    
    cfg_opt_t opts[] = {
        CFG_SIMPLE_STR("server_root", &root),
        CFG_SIMPLE_INT("port", &port),
        CFG_SIMPLE_INT("max_connections", &max_connections),
        CFG_SIMPLE_STR("server_signature", &signature),
        CFG_END()
    };
    cfg_t *cfg;

    cfg = cfg_init(opts, 0);
    cfg_parse(cfg, confPath);

    strcpy(config.root, root);
    strcpy(config.signature, signature);
    config.port = (uint16_t) port;
    config.max_connections = max_connections;

    return config;
}


/*********
* FUNCIÓN: *create_server(s_conf conf) 
* ARGS_IN: s_conf conf
* DESCRIPCIÓN: Se crea y se verifica el socket y de esta manera el servidor
* ARGS_OUT: server *s 
*********/
server *create_server(s_conf conf) {
    server *s;
    struct sockaddr_in servaddr;
    int opt = 1;

    s = (server*)malloc(sizeof(server));

    if (s == NULL) {
        perror("error");
        return NULL;
    }

    s->conf = conf;

    s->sockfd = socket(conf.family, conf.type, conf.protocol);

    if (s->sockfd == -1) {
        printf("socket creation failed...\n");
        exit(0);
    }
    else
        printf("Socket successfully created..\n");
    bzero(&servaddr, sizeof(servaddr));
   
    // se le asigna un puerto y una IP
    servaddr.sin_family = conf.family;
    servaddr.sin_addr.s_addr = htonl(conf.addr);
    servaddr.sin_port = htons(conf.port);
   
    // Vinculamos el socket recién creado a la IP dada y lo verificamos
    if ((bind(s->sockfd, (SA*)&servaddr, sizeof(servaddr))) != 0) {
        printf("socket bind failed...\n");
        exit(0);
    }
    else
        printf("Socket successfully binded..\n");
    
    if (s->conf.max_connections > 0) {
        if (server_listen(s) != 0) {
            free_server(s);
            fprintf(stderr, "server creation failed");
        }
    }

    setsockopt(s->sockfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    _create_thread_pool(s);

    return s;
}


/*********
* FUNCIÓN: int server_listen(server *s) 
* ARGS_IN: server *s 
* DESCRIPCIÓN: Permite que el servidor este listo para escuchar y verificar
* ARGS_OUT: int ret flag de error
*********/
int server_listen(server *s) {
    int ret = -1;
    if ((ret = listen(s->sockfd, s->conf.max_connections)) != 0) {
        printf("Listen failed...\n");
        exit(0);
    }
    else
        printf("Server listening..\n");

    return ret; 
}

/*********
* FUNCIÓN: int server_connect_client(server *s) 
* ARGS_IN: server *s 
* DESCRIPCIÓN: Conecta el servidor con el cliente, acepta el paquete de datos del cliente
* ARGS_OUT: int connfd, su valor es para saber si el server ha sido o no aceptado.
*********/
int server_connect_client(server *s) {
    int len, connfd;
    struct sockaddr_in /*servaddr,*/ cli;
    
    len = sizeof(cli);
   
    connfd = accept(s->sockfd, (SA*)&cli, (socklen_t *) &len);

    if (connfd < 0) {
        printf("server accept failed...\n");
        exit(0);
    }
    else
        printf("server accept the client...\n");
    return connfd;
}

/*********
* FUNCIÓN: free_server(server *s)
* ARGS_IN: server *s 
* DESCRIPCIÓN: Libera el servidor
* ARGS_OUT: 
*********/
void free_server(server *s) {
    int i = 0; 
    
    for (i = 0; i < s->conf.max_connections; i++) {
        pthread_cancel(s->thread_pool[i]);
    }

    sem_close(&s->paloshilos);
    free(s->thread_pool);
    close(s->sockfd);
    free(s);
}

void _parse_http_error(http_request *req, char * buffer, char*msg) {
    fflush(stdout);
    free(req);
    //free(buffer);

    /**
     * Esto es para que se pueda hacer free sin error 👌
     */
    if ( msg != NULL) {
        
        perror(msg);
        pthread_exit(NULL);
    }
}

/*********
* FUNCIÓN: char *getTypeByExtension(char *ext)
* ARGS_IN: char *ext, extension
* DESCRIPCIÓN: Obtiene si el script es de tipo php o py
* ARGS_OUT: char *type , tipo de extension
*********/
char *getTypeByExtension(char *ext) {
    char *type = NULL;
    char types[BUFMAX];
    char *token = NULL;
    char *save_ptr1 = NULL, *save_ptr2 = NULL;
    
    if (ext == NULL) {
        return NULL;
    }

    type = calloc(BUFMAX, sizeof(char));

    if (type == NULL) {
        return NULL;
    }

    if (strncmp(ext, "py", 2) == 0) {
        strcpy(type, "script/py");
        return type;
    }

    if (strncmp(ext, "php", 3) == 0) {
        strcpy(type, "script/php");
        return type;
    }

    strcpy(types, FORMATS);
    token = strtok_r(types, "|", &save_ptr2);

    while( token != NULL ) {
        char formatparsero[BUFMAX], *taip, *extension;

        strcpy(formatparsero, token);

        taip = strtok_r(formatparsero, "#", &save_ptr1); 

        extension = strtok_r(NULL, "#", &save_ptr1);
        
        if (strcmp(ext, extension) == 0) {
            strcpy(type, taip);
            return type;
        }

        token = strtok_r(NULL, "|", &save_ptr2);
   }

   free(type);
   type = NULL;

    return type;
}

/*********
* FUNCIÓN: http_file *create_http_file(char *path, char *filePerms) 
* ARGS_IN: har *path, char *filePerms
* DESCRIPCIÓN: crea un archivo HTTP
* ARGS_OUT: http_file *f, devuelve el archivo HTTP
*********/
http_file *create_http_file(char *path, char *filePerms) {
    http_file *f = NULL;
    char *type = NULL;
    
    f = malloc(sizeof(http_file));

    if (f == NULL) {
        perror("Error creando file");
        pthread_exit(NULL);
        return NULL;
    }


    if (filePerms != NULL) {
        f->f = fopen(path, filePerms);
        if (f->f == NULL) {
            free_http_file(f);
            perror("Error creando file");
            pthread_exit(NULL);
            return NULL;
        }
    } else {
        f->f = NULL;
    }

    
    if (path != NULL) {
        strcpy(f->path, path); 
        f->extension = strrchr(path, '.');

        if (f->extension != NULL) {
            f->extension+=sizeof(char);
            type = getTypeByExtension(f->extension);
        }
        
        if (type != NULL) {
            strcpy(f->type, type); 
            free(type);
        }
    }
    else {
        f->extension = NULL;
    }

    f->args = calloc(BUFMAX, sizeof(char));

    if (f->args == NULL) {
        perror("Noargs");
        pthread_exit(NULL);
        return NULL;
    }

    return f;    
}

/*********
* FUNCIÓN: void free_http_file(http_file *f)
* ARGS_IN: http_file *f
* DESCRIPCIÓN: Libera el archivo HTTP
* ARGS_OUT: 
*********/
void free_http_file(http_file *f) {
    if (f->f != NULL) {
        fclose(f->f);
    } 
    if (f->args != NULL) {
        free(f->args);
    }
    free(f);
}

/*********
* FUNCIÓN: http_file * getFile(server *s, http_request *req) 
* ARGS_IN: server *s, http_request *req
* DESCRIPCIÓN: obtiene el archivo HTTP
* ARGS_OUT: http_file *f, devuelve el archivo.
*********/
http_file * getFile(server *s, http_request *req) {
    http_file *f = NULL;
    char openMode[MAXMODE];
    char buffer[BUFMAX];
    char *cmd;
    char *buffer2 = NULL;
    char *buffer3 = NULL;

    if (req == NULL) {
        perror("ERROR para el http_request en getFile");
        pthread_exit(NULL);
    }

    f = create_http_file(req->path, NULL);
    
    if (f == NULL) {
        perror("Error en getFile");
        pthread_exit(NULL);
    }

    if (f->type == NULL) {
        strcpy(f->err, ERROR400MSG);
        return f;
    }

    if (strcmp("text/html", f->type) == 0 || strcmp("text/plain", f->type) == 0 || strcmp("script/py", f->type) == 0 || strcmp("script/php", f->type) == 0) {
        strcpy(openMode, "r");
    } else {
        strcpy(openMode, "rb");
    }

    if ((strcmp("script/py", f->type) == 0 || strcmp("script/php", f->type) == 0)) {
        buffer2 = calloc(BUFMAX, sizeof(char));

        if (buffer2 == NULL) {
            perror("calloc");
        }

        sprintf(buffer2, "%s%.*s",s->conf.root, (int)(req->pathLen), req->path);


        if (strchr(buffer2, '?') != NULL) {
            buffer2 = strtok(buffer2, "?");

            strcpy(buffer, buffer2);

            buffer2 = strtok(NULL, "?");
            strcpy(f->args, buffer2);

            if ((buffer2 = strtok(buffer2, "=")) != NULL) {
                if ((buffer2 = strtok(NULL, "&")) != NULL) {
                    strcat(f->args, buffer2);
                    strcat(f->args, " ");
                }
            }
            while ((buffer2 = strtok(buffer2, "=")) != NULL) {
                if ((buffer2 = strtok(NULL, "&")) != NULL) {
                    strcat(f->args, buffer2);
                    strcat(f->args, " ");
                }
            }
        } else {
            sprintf(buffer, "%s/%.*s",s->conf.root, (int)(req->pathLen), req->path);
        }

        if (strcmp(req->method, "POST") == 0) {
            buffer3 = calloc(sizeof(char), BUFMAX);
            strcpy(buffer3, req->body);

            if ((buffer3 = strtok(buffer3, "=")) != NULL) {
                if ((buffer3 = strtok(NULL, "&")) != NULL) {
                    strcat(f->args, buffer3);
                    strcat(f->args, " ");
                }
            }
            while ((buffer3 = strtok(buffer3, "=")) != NULL) {
                if ((buffer3 = strtok(NULL, "&")) != NULL) {
                    strcat(f->args, buffer3);
                    strcat(f->args, " ");
                }
            }
        }
        
        cmd = calloc(BUFMAX, sizeof(char));

        if (strcmp("script/py", f->type) == 0) {
            strcat(cmd, "python ");
        }
        if (strcmp("script/php", f->type) == 0) {
            strcat(cmd, "php ");
        }
        strcat(cmd, buffer);
        strcat(cmd, " ");
        strcat(cmd, f->args);
        
        f->f = popen(cmd, "r");

        free(cmd);
        strcpy(f->type, "text/plain");
    } else {
        sprintf(buffer, "%s/%.*s",s->conf.root, (int)(req->pathLen), req->path);
        f->f = fopen(buffer, openMode);
    }
    

    if (f->f == NULL) {
        strcpy(f->err, ERROR404MSG);
    } else {
        stat(buffer, &(f->st));
    }
    
    return f;
}

/*********
* FUNCIÓN: char * create_http_headers(server *s,http_request *req, http_file *f, int send)
* ARGS_IN: server *s,http_request *req, http_file *f, int send
* DESCRIPCIÓN: Crea la cabecera del HTTP
* ARGS_OUT: char * http_header, devuelve la cabecera
*********/
char * create_http_headers(server *s,http_request *req, http_file *f, int send) {
    char * http_header = NULL;
    char buffer[BUFMAX];
    char *buffer2 = NULL;
    int size = 0;
    int rret = -1;
    
    http_header = calloc(MAXBUFFERTOCHO + BUFMAX, sizeof(char));

    if (http_header == NULL) {
        perror("sarayao");
    }
    
    if (f->f == NULL) {
        strcpy(http_header, f->err);
    } else {
        strcpy(http_header, ERROR200MSG);
    }


    strcat(http_header, "Server: ");
    strcat(http_header, s->conf.signature);
    
    strcat(http_header, "\r\nContent-Length: ");
    if (f->f != NULL && strcmp(req->method, "OPTIONS") != 0) {
        buffer2 = calloc(MAXBUFFERTOCHO, sizeof(char));

        if (buffer2 == NULL) {
            perror("no calloc?");
            pthread_exit(NULL);
        } 

        rret = fread(buffer2, 1, MAXBUFFERTOCHO, f->f);
        if (rret < 0) {
            perror("Na tronco que no he leido na pork se ha liao k flipas");
            pthread_exit(NULL);
        }

        size = f->st.st_size; 
       
        sprintf(buffer, "%d", size);
        strcat(http_header, buffer);
    }
    else {
        strcat(http_header, "0");
    }

    strcat(http_header, "\r\nContent-Type: ");
    if (f->f == NULL) {
        strcat(http_header, "No file requested");
    }
    else {
        strcat(http_header, f->type);
    }

    if (strcmp(req->method, "OPTIONS") == 0)  {
        strcat(http_header, "\r\nAllow: ");
        
        if (strcmp(f->type, "script/py") == 0 || strcmp(f->type, "script/php") == 0) {
            strcat(http_header, "GET POST OPTIONS");
        } else {
            strcat(http_header, "GET OPTIONS");
        }
    }

    strcat(http_header, "\r\n\r\n");

    
    if (send == 1) {
        write(req->connfd, http_header, strlen(http_header));

        if (buffer2 != NULL && strcmp(req->method, "OPTIONS") != 0) {
            write(req->connfd, buffer2, rret);

            while (size >= MAXBUFFERTOCHO) {

                memset(buffer2, 0, MAXBUFFERTOCHO);
                rret = fread(buffer2, 1, MAXBUFFERTOCHO, f->f);
                
                size = rret;
             
                write(req->connfd, buffer2, rret);
            }
        }
    } 

    free(buffer2);
    return http_header;
}

/*********
* FUNCIÓN: void http_response(server *s, http_request *req)
* ARGS_IN: server *s, http_request *req
* DESCRIPCIÓN: Se genera la respuesta a partir de la obtencion del archivo y la creacion de la cabecera
* ARGS_OUT: 
*********/
void http_response(server *s, http_request *req) {
    char *msg = NULL;
    char *http_header = NULL;
    http_file *f = NULL;

    msg = calloc(BUFMAX, sizeof(char));
    if (msg == NULL) {
        perror("ERROR fuera de memoria");
        pthread_exit(NULL);
    }
  
    f = getFile(s, req);
    
    if (f == NULL) {
        perror("Error getFile");
        pthread_exit(NULL);
    }

    http_header = create_http_headers(s, req, f, 1);
   
    free(http_header);
    free_http_file(f);
}

/*********
* FUNCIÓN: http_request * create_http_request()
* ARGS_IN: 
* DESCRIPCIÓN: se crea la peticion HTTP
* ARGS_OUT: 
*********/
http_request * create_http_request() {
    #define __JDERLEN__ 100
    #define __PATHLEN__ 1024
    #define __METHODLEN__ 1024
    #define __BODYLEN__ 1024

    http_request *req = NULL;

    req = (http_request*) malloc(sizeof(http_request));

    if (req == NULL) {
        _parse_http_error(NULL, NULL, "Alloc error :(");
    }

    req->method = malloc(sizeof(char) * __METHODLEN__);
    req-> methodLen = __METHODLEN__;
    req->path = malloc(sizeof(char) * __PATHLEN__);
    req->pathLen = __PATHLEN__;
    req->minor_version = 0;
    req->headers = (struct phr_header*) malloc(sizeof(struct phr_header) * __JDERLEN__);
    req->num_headers = __JDERLEN__;
    req->body = malloc(sizeof(char) * BUFMAX);

    return req;
}

void options(server *s, http_request *req) {
    
}

/*********
* FUNCIÓN: free_http_request(http_request *r) 
* ARGS_IN: http_request *r
* DESCRIPCIÓN: se l ibera la peticion
* ARGS_OUT: 
*********/
void free_http_request(http_request *r) {
    free(r->method);
    free(r->path);
    free(r->headers);
    free(r);
}

/*********
* FUNCIÓN: http_request * parse_http(server *s, int connfd)
* ARGS_IN: server *s, int connfd
* DESCRIPCIÓN: parsea la solicitud HTTP
* ARGS_OUT:  http_request *req, peticion HTTP
*********/
http_request * parse_http(server *s, int connfd) {
    http_request *req = NULL;
    char buffer[BUFMAX];
    int pret;
    size_t buflen = 0, prevbuflen = 0;
    ssize_t rret;

    //req = (http_request*) malloc(sizeof(http_request));
    req = create_http_request();
    if (req == NULL) {
        _parse_http_error(NULL, NULL, "Alloc error :(");
    }

    //buffer = (char*) calloc(BUFMAX, sizeof(char));

    if (buffer == NULL) {
        _parse_http_error(req, NULL, "Alloc error :(");
    }

    while (1) {
        while ((rret = read(connfd, buffer + buflen, sizeof(buffer) - buflen)) == -1 && errno == EINTR);
        
        prevbuflen = buflen;
        buflen += rret;
        /* parsea la solicitud*/
      
        if (rret <= 0) {
            _parse_http_error(req, buffer, "reading error");
        } 
     
        if ((pret = phr_parse_request(buffer, buflen, (const char**) &(req->method), &req->methodLen, (const char**) &(req->path), &req->pathLen, &(req->minor_version), req->headers, &(req->num_headers), prevbuflen)) < 0) {
            _parse_http_error(req, buffer, "Error reading");
        }


        if (pret > 0)
            break; /* parsea con éxito la solicitud */
        else if (pret == -1) _parse_http_error(req, buffer, "Error parsero");
        /* solicitud incompleta, continua el bucle*/
        if (pret == -2) continue;
        if (buflen == sizeof(buffer)) {
            _parse_http_error(req, buffer, "Na tronco esto esta muy grande");
        }
    }

    strcpy(req->body, buffer + pret);
    printf("\nelbody: %s\n", buffer + pret);
    printf("request is %d bytes long\n", pret);
    printf("method is %.*s\n", (int)(req->methodLen), req->method);
    printf("path is %.*s\n", (int)(req->pathLen), req->path);
    printf("HTTP version is 1.%d\n", req->minor_version);
    printf("headers:\n");
    
    
    sprintf(req->method, "%.*s", (int)(req->methodLen), req->method);
    sprintf(req->path, "%.*s", (int)(req->pathLen), req->path);
    for (int i = 0; i != req->num_headers; ++i) {
    printf("%.*s: %.*s\n", (int)req->headers[i].name_len, req->headers[i].name,
           (int)req->headers[i].value_len, req->headers[i].value);
    }

    req->connfd = connfd;

    return req;
}