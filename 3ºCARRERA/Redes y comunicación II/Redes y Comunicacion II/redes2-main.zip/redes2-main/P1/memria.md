# PRACTICA 1 REDES II
### Grupo: 2323
### Autores: Javier y Miguel Ibáñez González

## Indice
1. [Introduccion](#introduccion)
2. [Diseño del Servidor](#diseño)
3. [Uso](#uso)
4. [Scripts](#scripts)
5. [Conclusiones](#conclusiones)


## Introduccion

 El objetivo principal de esta practica es aprender a diseñar e implementar en lenguaje C un servidor Web, en este caso va a ser un servidor con muchas limitaciones , pero el servidor sera completamente funcional. Dado que para crear un servidor existen diversos diseños, en función de muchas cosas como lo pueden su simplicidad, rendimiento y grado de concurrencia, en esta practica se deberá diseñar el más oportuno.

## Diseño

### Modelo del servidor
Hemos diseñado un servidor que es capaz de atender a las distintas peticiones haciendo uso de hilos. 
Para crear nuestro servidor hemos elegido hilos en lugar de procesos ya que así podemos 
atender varias peticiones a la vez, y son mucho mas ligeros que los procesos.
De esta manera cuando llega una peticion se genera un nuevo hilo que es el encargado 
de atenderla y mandar la respuesta al socket. El hilo despues de realizar estas acciones se destruye. 

Para que el sistema no se sature hemos añadido un parametro en el fichero de 
configuracion del servidor que limita el numero de hilos que se puedan generar 
en el sistema. 
max_clients, en nuestro caso -> max_connections = 5

### Fichero de configuracion del servidor
Nuestro fichero de configuracion del servidor (server.conf) tiene los siguientes campos: 

- server_root: ruta al directorio que contiene los ficheros y recursos del servidor Web. Es un ruta   relativa respecto al directorio donde se encuentra el fichero de configuración. Es la carpeta en la que se encuentran los recursos estaticos del servidor. server_root = ./web_P1/www

- max_connections: número máximo de clientes que el servidor podrá atender simultáneamente. Llegado este número, el servidor simplemente no aceptará más conexiones En nuestro caso es el numero maximo de hilos al servidor, max_connections = 5.

- port: puerto en el que el servidor debe recibir las conexiones entrantes. port = 8080

- server_signature: cadena que será devuelta en cada cabecera ServerName posterior. 
server_signature = miservidorwapo


### Atender peticiones picohttpparser
Para atender a las distintas peticiones hemos usado tal y como nos recomienda la practica,
la librería *picohttpparser*, lo que hace esta librería es que dada una peticion http, parsea 
todos los campos de la petición a cadenas de caracteres. Si se produce algun error, se crea la respuesta con el HTML de error correspondiente y se manda al cliente.

En el servidor que hemos creado se pueden usar peticiones de tipo GET, POST. Si se hace 
alguna peticion que nse distinta entonces se lanza el mensaje de error *not_implemented* junto con 
el correspondiente HTML al cliente. Este servidor también puede soportar ejecucion de codigo, los parametros vienen dados en el cuerpo y la respuesta devuelta por el script es enviada al cliente como cuerpo del mensaje http.

### Ejecución de Scripts

En la ejecución de los scrpts que se nos proporcionan(test.php, test.py) 
cuando se llama a una peticion tipo GET y POST y como recurso solicitado 
es de tipo PHP Y PYTHON, el codigo se ejecuta en el lado del servidor y 
se manda la respuesta al cliente. En cambio si el tipo de script que necesita 
ejecutarse no es PHP o PYTHON entonces se manda la respuesta de error not_implemented.

## Uso

Para ejecutar el servidor es necesario compilarlo haciendo uso del Makefile y basta
con ejecutar ./server. El fichero de configuracion puede editarse, respetando la
sintaxis, y se corresponde con server.conf.

Cuando hayamos lanzado el servidor podremos acceder a la página 127.0.0.1:*puerto*/index.html (en el resto del documento el puerto será el 8080) y veremos una página donde nos deberían aparecer una serie de imagenes y una serie de enlaces que deberían devolvernos recursos.

También podemos probar el servidor mediante curl de la siguiente forma:
``` sh
curl -i --request-target "index.html" -X OPTIONS 127.0.0.1:8080
HTTP/1.0 200 OK
Server: miservidorwapo
Content-Length: 0
Content-Type: text/html
Allow: GET OPTIONS
```
Una vez estemos dentro del servidor y nos econtremos en index.html veremos que que los enlaces de las 4 opciones funcionan: No existente, Nota importante, Vídeo largo de 2GB y Texto .txt.
Si quiere probar las peticiones GET y POST basta con pulsar los boones de abajo y
se ejecutarn el test.py o el test.phy.

## Scripts

Hemos incluido 2 scripts adicionales para probar la funcionalidad de la práctica los cuales realizan una petición GET y una POST.
Al abrir *127.0.0.1:8080* (fuera del index.html) nos aprecerá una página por defecto mostrando default.
html que nos permite probar dichos scripts y contiene un enlace a index.html.
Tambien se puede acceder a la pagina con *127.0.0.1:8080/scrpts*

### hola.py GET
Uno de los scripts es hola.py, para probarlo solo poner un nombre y le das a probar hola.py

### temperatura.py POST
El otro es temperatura.py, que guarda una temperatura en grados Celsius, y devuelve la temperatura correspondiente en Farenheit, para probarlo mueve la flechita y le das a probar temperatura.py

## Conclusiones

### Conclusiones Técnicas
Con esta practica nos hemos dado cuenta que estas conexiones entre cliente y servidor 
no son realmente complejas, lo compicado de esta práctica es que son muchas cosas y hay que
cuenta a todas ellas para poder manejar el servidor de forma que funcione correctamente. 

### Conclusiones Personales
Este servidor aunque sea pequeño nos ayuda a entender todas los sucesos que ocurren 
detras de una web, así como las distintas funcionalidades que tiene HTTP y como se realizan 
las conexiones con sockets entre los clientes y los servidores.





