export J2EE_HOME=/opt/glassfish4/glassfish
export PATH=/opt/jdk1.8.0_111/bin:${PATH}
export AS_JAVA=/usr/lib/jvm/java-8-openjdk-amd64
export JAVA_HOME=/opt/jdk1.8.0_111

