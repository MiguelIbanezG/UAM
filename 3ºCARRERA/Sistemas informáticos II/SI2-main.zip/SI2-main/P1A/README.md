# SI2
Sistemas Informáticos 2

ssh -o HostKeyAlgorithms=ssh-rsa si2@10.6.4.2

si2
2023sid0s

asadmin start-domain domain1


