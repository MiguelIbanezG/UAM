sudo sh si2fixMAC.sh 2323 4 2
sudo sh virtualip.sh wlo1
sudo chmod 777 *
