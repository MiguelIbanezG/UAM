wsimport -d ./build/client/WEB-INF/classes -p ssii2.visa http://10.6.4.2:8080/P1-ws-ws/VisaDAOWSService?wsdl
