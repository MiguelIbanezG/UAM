
/apuntes -> apuntes de todos los temas y preguntas de test resueltas (x ulises)

/ejs -> los ejercios más importantes de cada tema (falta ejercicios de cipher q preguntaron x ello en el final y utilizar la sentencia $lookup en mongo)

/ex -> examenes  (solo encontré 1 parcial) 
 
/pprueba -> el entorno de desarrollo sobre el q he hexo los ejercicios (no creo q sirva)


