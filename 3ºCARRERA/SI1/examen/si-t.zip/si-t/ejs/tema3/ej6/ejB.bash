bash query1.bash | tail -n +29 | head -n -2 > query1.txt
bash query2.bash | tail -n +29 | head -n -2 > query2.txt
bash query3.bash | tail -n +29 | head -n -2 > query3.txt