from numpy import sqrt
import argparse
from sacaclave import sakaklave

def kasiski(message, ngrama):
    
    cont=0
    posis=[]
    coincidence = 0

    frecuencias=list()
    frecaux=list()
    pos_first=-1
    for x in range(len(message)//10):
    #for x in range(int(sqrt(len(message)))):

        coincidence = 0
        busca = message[cont:ngrama+cont] 
        for i in range(len(message)):
            if busca == message[i:i+ngrama]:
                #print("##",busca,"",message[i:i+ngrama])  
                coincidence+=1
                if pos_first ==-1:
                    pos_first=i
                else:
                    posis.append(i-pos_first)
        #print("para",busca,"hay",coincidence," coincidencia en ",posis)

        if coincidence>=5:
            stayugly=multiple_mcd(posis)
            #if stayugly>=2:
            #print("posinble longitud de clave= ",stayugly,"con clave",busca,"==>",posis)
            if stayugly in frecuencias:
                frecaux[frecuencias.index(stayugly)]+=1
            else:
                frecaux.append(1)
                frecuencias.append(stayugly)
        cont+=1
        posis.clear()
        pos_first=-1
    #print(frecuencias)
    #print(frecaux)
    max_numero = max(frecaux,default=0)
    xosen = frecaux.index(max_numero)
    long = frecuencias[xosen]
    #print(max_numero,xosen,long)
    return long

def multiple_mcd(numeros):
    mcd_resultado = euclid_mcd(numeros[0], numeros[1])
    for i in range(2, len(numeros)):
        mcd_resultado = euclid_mcd(mcd_resultado, numeros[i])

    return mcd_resultado

def euclid_mcd(a, b):
    while b != 0:
        a, b = b, a % b
    return a

def main():
    parser = argparse.ArgumentParser(description='Kasiski')
    parser.add_argument('-l', '--ngrama', type=int, help='longitud de n-grama buscado')
    parser.add_argument('-i', '--input', default=None, help='Archivo de entrada')
    parser.add_argument('-o', '--output', default=None, help='Archivo de salida')

    args = parser.parse_args()

   
    if args.input is None:
        message = input("Ingrese el mensaje a analizar: ")
    else:
        with open(args.input, 'r') as f:
            message = f.read()
    keylong= kasiski(message,args.ngrama)
    if args.output is None:
        print("Longitud de la clave:", keylong)
    else:
        with open(args.output, 'w') as f:
            f.write(keylong)

    clave = sakaklave(message,keylong)
    print("CLAVE=>",clave)


if __name__ == "__main__":
    main()