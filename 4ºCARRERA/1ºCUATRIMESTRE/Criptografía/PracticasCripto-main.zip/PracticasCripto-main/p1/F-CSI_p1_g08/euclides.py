
#ESTO ES BASUR
import numpy as np
#Funcion calculate_mcd para calcular el maximo comun divisor de dos numeros mediante el algoritmo de Euclides:


def mcd(a, b):
    while b:
        a, b = b, a % b

   # print("IMPORTX", a)
    return a

# Funcion get_inverso_mult para calcular el inverso multiplicativo de m en n utilizando aritmetica modular:
def get_inverso_mult(m, n):
    g, x, y = extended_mcd(m, n)
    if g != 1:
        return 0  # No existe inverso multiplicativo
    else:
        return x % n
    
# Funcion get_intverso_mult para calcular el inverso multiplicativo de m en n como un numero entero (retorna 0 en caso de que no exista):
def extended_mcd(a, b):
    if a == 0:
        return (b, 0, 1)
    else:
        g, x, y = extended_mcd(b % a, a)
        return (g, y - (b // a) * x, x)
    

def get_intverso_mult(m, n):
    g, x, y = extended_mcd(m, n)
    if g != 1:
        return 0  # No existe inverso multiplicativo
    else:
        return x % n

def extended_mcd(a, b):
    if a == 0:
        return (b, 0, 1)
    else:
        g, x, y = extended_mcd(b % a, a)
        return (g, y - (b // a) * x, x)

# Ten en cuenta que estas implementaciones utilizan el algoritmo extendido de Euclides para calcular el inverso multiplicativo en aritmetica modular. 
# Asegurate de tener las bibliotecas adecuadas (como math o gmpy2 para manejar enteros grandes) si trabajas con numeros grandes.


def intverso(a,m):
    print("NOTIMPLEMNETADO",a,m)






def cofactor_matrix(matrix):
    # Calcula la matriz de cofactores
    cofactors = np.zeros(matrix.shape)
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            minor = np.delete(np.delete(matrix, i, axis=0), j, axis=1)
            cofactors[i, j] = ((-1) ** (i + j)) * np.linalg.det(minor)
    return cofactors