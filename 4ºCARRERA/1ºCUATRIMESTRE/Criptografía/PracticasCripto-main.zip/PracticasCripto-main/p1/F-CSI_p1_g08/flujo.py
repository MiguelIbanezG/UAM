import random
import constants
import argparse

class Flujo:
    def __init__(self, key, m, input=None, output=None):
        self.key = key
        self.module = m
        self.counter = 0
        self.seed = 0

        # Calcular la semilla basada en la clave
        for caracter in self.key:
            self.seed += ord(caracter)

        self.rand = random
        self.rand.seed(self.seed)

    def generate(self, length):
        return ''.join(str(self.rand.randint(0, 1)) for _ in range(length))


    def encrypt(self, message):
        zifer = ""
        for l in message.upper():
            if l not in constants.notadapt:
                koded =chr((ord(l)-65+self.rand.randint(0,1000))%self.module+65)
                zifer+=koded

        return zifer


    def decrypt(self,ciphertext):
        luzifer = ""
        for l in ciphertext.upper():
            koded =chr((ord(l)-65-self.rand.randint(0,1000))%self.module+65)
            luzifer+=koded

        return luzifer
    
    def encrypt_bit(self, message):
        stream_key = self.generate(len(message))

        ciphertext = ''.join(chr(ord(message[i]) ^ int(stream_key[i])) for i in range(len(message)))
        return ciphertext

    def decrypt_bit(self, ciphertext):
        stream_key = self.generate(len(ciphertext))

        # Realiza la operación XOR bit a bit para descifrar
        decrypted_plaintext = ''.join(chr(ord(ciphertext[i]) ^ int(stream_key[i])) for i in range(len(ciphertext)))
        return decrypted_plaintext



def main():
    parser = argparse.ArgumentParser(description='Flujo')
    parser.add_argument('-C', dest='operation', action='store_const', const='-C', help='Operacion a realizar: -C para cifrar')
    parser.add_argument('-D', dest='operation', action='store_const', const='-D', help='Operacion a realizar: -D para descifrar')
    parser.add_argument('-k', '--key', type=str, help='clave para el cifrado/descifrado (k)')
    parser.add_argument('-m', '--module', type=int,default=26, help='zm, el modulo por default 26')
    parser.add_argument('-i', '--input', default=None, help='Archivo de entrada')
    parser.add_argument('-o', '--output', default=None, help='Archivo de salida')

    args = parser.parse_args()

    # Verificar la operacion seleccionada
    if args.operation is None:
        parser.error('Se debe especificar una operacion: -C para cifrar, -D para descifrar')

    # Aqui puedes usar args.operation para determinar si es cifrado o descifrado
    if args.operation == '-C':
        print('Operacion de cifrado seleccionada')
    elif args.operation == '-D':
        print('Operacion de descifrado seleccionada')

    flux = Flujo(args.key,args.module, args.input, args.output)


    #cifrar
    if args.operation == "-C":
   
        if args.input is None:
            message = input("Ingrese el mensaje a cifrar: ")
        else:
            with open(args.input, 'r') as f:
                message = f.read()

        ciphertext = flux.encrypt(message)
        if args.output is None:
            print("Texto cifrado:", ciphertext)

        else:
            with open(args.output, 'w') as f:
                f.write(ciphertext)


#descifrar
    elif args.operation == "-D":
        if args.input is None:
            ciphertext = input("Ingrese el mensaje a descifrar: ")
        else:
            with open(args.input, 'r') as f:
                ciphertext = f.read()

        plaintext = flux.decrypt(ciphertext)
        if args.output is None:
            print("Texto descifrado:", plaintext)
            
        else:
            with open(args.output, 'w') as f:
                f.write(plaintext)

    else:
        print("Operacion no valida. Use -C para cifrar o -D para descifrar.")
        return -1




if __name__ == "__main__":
    main()