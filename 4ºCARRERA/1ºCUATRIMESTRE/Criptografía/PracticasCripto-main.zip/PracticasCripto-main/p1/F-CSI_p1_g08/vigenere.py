
import constants
class Vigenere:
    def __init__(self,key,input=None,output=None) -> None:
        self.alfabeto = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        self.key = key
        
        
        count=0
        for caracter in self.key:
            if caracter.isalpha():
                count += 1
        self.tamkey=count


    def encrypt(self, message):
        cont = 0 
        saddie_pinn=''
        for l in message.upper():
            if l not in constants.notadapt:
                c = ((ord(l)-65)+(ord(self.key[cont%self.tamkey])-65))%26
                saddie_pinn+=chr(c+65)
                cont+=1
        return saddie_pinn

    def decrypt(self,ciphertext):
        cont = 0 
        saddie_pinn=''
        for l in ciphertext:
            c = ((ord(l)-65)-(ord(self.key[cont%self.tamkey])-65))%26
            saddie_pinn+=chr(c+65)
            cont+=1
        return saddie_pinn
        

import argparse


def main():
    parser = argparse.ArgumentParser(description='Afin')
    parser.add_argument('-C', dest='operation', action='store_const', const='-C', help='Operacion a realizar: -C para cifrar')
    parser.add_argument('-D', dest='operation', action='store_const', const='-D', help='Operacion a realizar: -D para descifrar')
    parser.add_argument('-k', '--key', type=str, help='clave para el cifrado/descifrado (k)')
    parser.add_argument('-i', '--input', default=None, help='Archivo de entrada')
    parser.add_argument('-o', '--output', default=None, help='Archivo de salida')

    args = parser.parse_args()

    # Verificar la operacion seleccionada
    if args.operation is None:
        parser.error('Se debe especificar una operacion: -C para cifrar, -D para descifrar')

    # Aqui puedes usar args.operation para determinar si es cifrado o descifrado
    if args.operation == '-C':
        print('Operacion de cifrado seleccionada')
    elif args.operation == '-D':
        print('Operacion de descifrado seleccionada')

    vixiner = Vigenere(args.key, args.input, args.output)


    #cifrar
    if args.operation == "-C":
   
        if args.input is None:
            message = input("Ingrese el mensaje a cifrar: ")
        else:
            with open(args.input, 'r') as f:
                message = f.read()

        ciphertext = vixiner.encrypt(message)
        if args.input is None:
            print("Texto cifrado:", ciphertext)

        else:
            with open(args.output, 'w') as f:
                f.write(ciphertext)


#descifrar
    elif args.operation == "-D":
        if args.input is None:
            ciphertext = input("Ingrese el mensaje a descifrar: ")
        else:
            with open(args.input, 'r') as f:
                ciphertext = f.read()

        plaintext = vixiner.decrypt(ciphertext)
        if args.input is None:
            print("Texto descifrado:", plaintext)
            
        else:
            with open(args.output, 'w') as f:
                f.write(plaintext)

    else:
        print("Operacion no valida. Use -C para cifrar o -D para descifrar.")
        return -1




if __name__ == "__main__":
    main()