import sys
import argparse

class Afin:

    def __init__(self, m, a, b, input_filename=None, output_filename=None):
        self.a = a
        self.m = m
        self.b = b
        self.input_filename = input_filename
        self.output_filename = output_filename

    def mod_tomessage(self, lista):
        message = ''.join([chr(l + 65) for l in lista])
        return message

    def message_tomod(self, message):
        ascii_xein = []
        for l in message:
            ascii_xein.append((ord(l)-65))
        return ascii_xein
    
    def euclides_extendido(self, a, b):

        if a == 0:
            return (b, 0, 1)
        else:
            gcd, x, y = self.euclides_extendido(b % a, a)
            return (gcd, y - (b // a) * x, x)

    def inversa_modular(self, a, m):
        gcd, x, y = self.euclides_extendido(a, m)
        if gcd != 1:
            raise ValueError("La inversa modular no existe")
        else:
            return x % m

    def encrypt(self, message):
        lista_zm = self.message_tomod(message)
        message_zm = [(self.a * x + self.b) % self.m for x in lista_zm]
        ascii_xein = self.mod_tomessage(message_zm)
        return ascii_xein
    
    def decrypt(self, ciphertext):
        intverso_a = self.inversa_modular(self.a,self.m)
        lista_zm = self.message_tomod(ciphertext)
        message_zm = [(intverso_a * (x - self.b)) % self.m for x in lista_zm]
        ascii_xein = self.mod_tomessage(message_zm)
        return ascii_xein
    
    def check_injective(self, a, b, m):
        mcd, _, _ = self.euclides_extendido(a, b)
        if mcd != 1:
            print("Error: La funcion afin no es inyectiva (a y b no son coprimos)")
            sys.exit(1)


def main():
    parser = argparse.ArgumentParser(description='Afin')
    parser.add_argument('-C', dest='operation', action='store_const', const='-C', help='Operacion a realizar: -C para cifrar')
    parser.add_argument('-D', dest='operation', action='store_const', const='-D', help='Operacion a realizar: -D para descifrar')
    parser.add_argument('-m', '--module', type=int, help='Modulo para el calculo (Zm)')
    parser.add_argument('-a', '--akey', type=int, help='Clave A para la operacion')
    parser.add_argument('-b', '--bkey', type=int, help='Clave B para la operacion')
    parser.add_argument('-i', '--input', default=None, help='Archivo de entrada')
    parser.add_argument('-o', '--output', default=None, help='Archivo de salida')

    args = parser.parse_args()

    # Verificar la operacion seleccionada
    if args.operation is None:
        parser.error('Se debe especificar una operacion: -C para cifrar, -D para descifrar')

    # Aqui puedes usar args.operation para determinar si es cifrado o descifrado
    if args.operation == '-C':
        print('Operacion de cifrado seleccionada')
    elif args.operation == '-D':
        print('Operacion de descifrado seleccionada')


    afin = Afin(args.module, args.akey, args.bkey, args.input, args.output)


#cifrar
    if args.operation == "-C":
        afin.check_injective(args.akey, args.bkey, args.module)

        if args.input is None:
            message = input("Ingrese el mensaje a cifrar: ")
        else:
            with open(args.input, 'r') as f:
                message = f.read()

        ciphertext = afin.encrypt(message)
        if args.input is None:
            print("Texto cifrado:", ciphertext)

        else:
            with open(args.output, 'w') as f:
                f.write(ciphertext)


#descifrar
    elif args.operation == "-D":
        if args.input is None:
            ciphertext = input("Ingrese el mensaje a descifrar: ")
        else:
            with open(args.input, 'r') as f:
                ciphertext = f.read()

        plaintext = afin.decrypt(ciphertext)
        if args.input is None:
            print("Texto descifrado:", plaintext)
            
        else:
            with open(args.output, 'w') as f:
                f.write(plaintext)

    else:
        print("Operacion no valida. Use -C para cifrar o -D para descifrar.")
        return -1

if __name__ == "__main__":
    main()