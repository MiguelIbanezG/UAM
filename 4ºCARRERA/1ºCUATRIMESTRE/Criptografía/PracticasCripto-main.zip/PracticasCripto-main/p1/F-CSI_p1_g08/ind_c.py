import argparse
from sacaclave import sakaklave

def ic(message, ngrama):
    key =0
    aux =0
    for cont_act in range(1,ngrama):
    
        xeins = [[] for _ in range(cont_act)]  # Inicializa una lista de listas vacías
        contadores = {chr(i + 65): [0] * cont_act for i in range(26)}  # Inicializa un diccionario de listas de contadores
        ics = [0]*cont_act

        for i, l in enumerate(message):
            bloque = i % cont_act  # Determina a qué bloque pertenece la letra

            # Agrega la letra a la lista correspondiente en xeins
            xeins[bloque].append(l)

            # Incrementa el contador para la letra correspondiente al bloque
            contadores[l][bloque] += 1
        contadores_let=contadores.copy()
        freks=[[0] * cont_act for _ in range(26)]



        for r,s in contadores_let.items():
            for i in range(cont_act):
                msg_l = len(xeins[i])  # Longitud del mensaje

                #print(r,s)
                #if r == chr(i+65):
                #print("####",s[i])
                freq = (s[i]/msg_l)*((s[i]-1)/(msg_l-1))
                freks[ord(r) - 65][i] = freq
                ics[i] += freq

        avg_ic=0
        for f in ics:
            avg_ic += f

        avg_ic =avg_ic /len(ics)

        if avg_ic >aux:
            key = cont_act
            aux = avg_ic
        print(f"IC medio xa n={cont_act} => {avg_ic:.6f}")   #    print("Longitud de cada lista en xeins:", [len(sublista) for sublista in xeins])
            #freq de a:

    print("longitud de la clave mas probable:", key)
    return key
        




def main():
    parser = argparse.ArgumentParser(description='Kasiski')
    parser.add_argument('-l', '--ngrama', type=int, help='longitud de n-grama buscado inicial')
    parser.add_argument('-i', '--input', default=None, help='Archivo de entrada')
    parser.add_argument('-o', '--output', default=None, help='Archivo de salida')

    args = parser.parse_args()

   
    if args.input is None:
        message = input("Ingrese el mensaje a analizar: ")
    else:
        with open(args.input, 'r') as f:
            message = f.read()
    keylong= ic(message,args.ngrama)
    if args.output is None:
        print("Longitud de la clave:", keylong)
    else:
        with open(args.output, 'w') as f:
            f.write(keylong)

    clave = sakaklave(message,keylong)
    print("CLAVE=>",clave)


if __name__ == "__main__":
    main()