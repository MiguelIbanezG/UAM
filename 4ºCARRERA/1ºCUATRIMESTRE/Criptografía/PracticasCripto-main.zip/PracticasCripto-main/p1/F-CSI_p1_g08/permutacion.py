import sys
import argparse

class Permutacion:

    def __init__(self, m, n, input_filename=None, output_filename=None):
        self.matriz = None
        self.textlen = 0
        self.m = m
        self.n = n
        self.input_filename = input_filename
        self.output_filename = output_filename

    def construir_matriz(self, texto, indice):

        self.matriz = [[' ' for _ in range(self.n)] for _ in range(self.m)]
        i, j = 0, 0

        for i in range(self.n):
            for j in range(self.m):
                if indice < self.textlen:
                    self.matriz[j][i] = texto[indice]
                    indice += 1

    def permutar_matriz(self, k1, k2):
        copia = [['' for _ in range(self.n)] for _ in range(self.m)]

        for i in range(self.m):
            for j in range(self.n):
                copia[i][j] = self.matriz[i][j]

        for i in range(self.m):
            for j in range(self.n):
                self.matriz[i][j] = copia[k1[i] - 1][k2[j] - 1]

    def cifrar(self, p, k1, k2):
        indice = 0
        c = []

        while indice < len(p):
            self.construir_matriz(p, indice)
            indice += self.m * self.n
            self.permutar_matriz(k1, k2)

            for i in range(self.n):
                for j in range(self.m):
                    c.append(self.matriz[j][i])

        return ''.join(c)

    def descifrar(self, c, k1, k2):
        indice, i, j, cont = 0, 0, 0, 0
        aux = [k1[i] for i in range(self.m)]
        aux2 = [k2[i] for i in range(self.n)]

        for i in range(self.m):
            k1[aux[i] - 1] = i + 1

        for i in range(self.n):
            k2[aux2[i] - 1] = i + 1

        p = [''] * self.textlen

        while indice < self.textlen:
            self.construir_matriz(c, indice)
            indice += self.m * self.n
            self.permutar_matriz(k1, k2)

            for i in range(self.n):
                for j in range(self.m):
                    p[cont] = self.matriz[j][i]
                    cont += 1

        return ''.join(p)


def main():
    parser = argparse.ArgumentParser(description='Permutacion')
    parser.add_argument('-C', dest='operation', action='store_const', const='-C', help='Operación: -C para cifrado')
    parser.add_argument('-D', dest='operation', action='store_const', const='-D', help='Operación: -D para descifrado')
    parser.add_argument('-k1', '--k1', type=str, help='Clave k1 para la operación')
    parser.add_argument('-k2', '--k2', type=str, help='Clave k2 para la operación')
    parser.add_argument('-i', '--input', default=None, help='Archivo de entrada')
    parser.add_argument('-o', '--output', default=None, help='Archivo de salida')

    args = parser.parse_args()

    if args.operation is None:
        parser.error('Debes especificar una operación: -C para cifrado, -D para descifrado')

    m = len(args.k1)
    n = len(args.k2)

    permutacion = Permutacion(m, n, args.input, args.output)

    k1 = [int(char) for char in args.k1]
    k2 = [int(char) for char in args.k2]

    if args.operation == '-C':

        if args.input is None:
            message = input("Ingresa el mensaje a cifrar: ")
            permutacion.textlen = len(message)
        else:
            with open(args.input, 'r') as f:
                message = f.read()
            permutacion.textlen = len(message)

        ciphertext = permutacion.cifrar(message, k1, k2)

        if args.output is None:
            print("Mensaje encriptado:", ciphertext)
        else:
            with open(args.output, "w") as f:
                f.write(ciphertext)

    elif args.operation == '-D':
        if args.input is None:
            message = input("Ingresa el mensaje a descifrar: ")
            permutacion.textlen = len(message)
        else:
            with open(args.input, 'r') as f:
                message = f.read()
            permutacion.textlen = len(message)

        plaintext = permutacion.descifrar(message, k1, k2)

        if args.output is None:
            print("Mensaje desencriptado:", plaintext)
        else:
            with open(args.output, "w") as f:
                f.write(plaintext)

if __name__ == '__main__':
    main()
