import numpy as np
from euclides import cofactor_matrix,get_inverso_mult
import argparse
import numpy as np

class Hill:
    def __init__(self, module, nkey, kfile, input_filename=None, output_filename=None):
        self.module = module
        self.nkey = nkey
        self.kfile = kfile
        self.input_filename = input_filename
        self.output_filename = output_filename
        self.key_matrix = self.load_key_matrix(kfile)
        self.inv_key_matrix = self.calculate_inverse_key_matrix()

    def load_key_matrix(self, kfile):
        try:
            with open(kfile, 'r') as f:
                lines = f.readlines()
                key_matrix = []
                for line in lines:
                    row = [int(x) for x in line.strip().split()]
                    if len(row) != self.nkey:
                        raise ValueError("La matriz de transformación no tiene la dimensión correcta")
                    key_matrix.append(row)
                    #print(key_matrix)
                return np.array(key_matrix)
        except FileNotFoundError:
            raise FileNotFoundError(f"No se pudo encontrar el archivo {kfile}")
        except ValueError as e:
            raise ValueError(f"Error al cargar la matriz de transformación: {str(e)}")

    def calculate_inverse_key_matrix(self):
        det = int(np.round(np.linalg.det(self.key_matrix))) % self.module
        try:
            inv_key_matrix = np.linalg.inv(self.key_matrix)
        except np.linalg.LinAlgError:
            raise ValueError("La matriz de transformación no es invertible")
        
        # Realiza operaciones de matriz-elemento para calcular la matriz inversa
        inv_det = (inv_key_matrix * det) % self.module
    
        return inv_det

    def mod_to_message(self, lista_de_turno):
        message = ''.join([chr(int(l) + 65) for l in lista_de_turno])
        return message

    def message_to_mod(self, message):
        ascii_values = [ord(l) - 65 for l in message]
        return ascii_values

    def encrypt(self, message):
        # Convierte el mensaje a una lista de números según la codificación que estés utilizando
        message_ascii = self.message_to_mod(message)
        
        # Divide el mensaje en grupos de tamaño nkey
        divix = len(message_ascii) // self.nkey
        if len(message_ascii) % self.nkey != 0:
            divix += 1    
        
        message_split = [message_ascii[i * self.nkey: (i + 1) * self.nkey] for i in range(divix)]
        
        # Asegura que el último grupo tenga la misma longitud que los demás, rellenando con ceros si es necesario
        while len(message_split[-1]) < self.nkey:
            message_split[-1].append(0)
        
        # Cifra cada grupo y construye el mensaje cifrado
        encrypted_message = ""
        for matriz_trans in message_split:
            c = np.matmul(self.key_matrix, matriz_trans) % self.module
            encrypted_message += self.mod_to_message(c)
        
        return encrypted_message

    def decrypt(self, ciphertext):
        ciphertext_ascii = self.message_to_mod(ciphertext)
        plaintext = ""
        divix = len(ciphertext_ascii) // self.nkey
        if len(ciphertext_ascii) % self.nkey != 0:
            divix += 1

        cipher_split = [ciphertext_ascii[i * self.nkey: (i + 1) * self.nkey] for i in range(divix)]

        while len(cipher_split[-1]) < self.nkey:
            cipher_split[-1].append(0)
        for caxo_ciber in cipher_split:
            mat_trans = np.transpose(cofactor_matrix(self.key_matrix))
            det = get_inverso_mult(int(np.linalg.det(self.key_matrix)), self.module)
            # Realiza la multiplicación y luego el módulo
            mat_trans = (mat_trans * det) % self.module

            c = np.matmul(mat_trans, caxo_ciber) % self.module
            #vaina = c.tolist()
            nastya = [int(round(x)) for x in c]  # Redondea y convierte a enteros

            # Asegúrate de que el resultado esté en el rango [0, self.module)
            #c = c % self.module
            nastya = [x % self.module for x in nastya]
            plaintext += self.mod_to_message(nastya)
        return plaintext





def main():
    parser = argparse.ArgumentParser(description='Hill Cipher')
    parser.add_argument('-C', dest='operation', action='store_const', const='-C', help='Operación a realizar: -C para cifrar')
    parser.add_argument('-D', dest='operation', action='store_const', const='-D', help='Operación a realizar: -D para descifrar')
    parser.add_argument('-m', '--module', type=int, help='Módulo para el cálculo (Zm)')
    parser.add_argument('-n', '--nkey', type=int, help='Dimensión de la matriz de transformación (Nk)')
    parser.add_argument('-k', '--kfile', help='Archivo que contiene la matriz de transformación')
    parser.add_argument('-i', '--input', default=None, help='Archivo de entrada')
    parser.add_argument('-o', '--output', default=None, help='Archivo de salida')

    args = parser.parse_args()


    # Verificar la operación seleccionada
    if args.operation is None:
        parser.error('Se debe especificar una operación: -C para cifrar, -D para descifrar')

    if args.operation == '-C':
        print('Operación de cifrado seleccionada')
    elif args.operation == '-D':
        print('Operación de descifrado seleccionada')

    hill = Hill(args.module, args.nkey, args.kfile, args.input, args.output)

    # Cifrar
    if args.operation == "-C":

        if args.input is None:
            message = input("Ingrese el mensaje a cifrar: ")
        else:
            with open(args.input, 'r') as f:
                message = f.read()

        ciphertext = hill.encrypt(message)
        if args.output is None:
            print("Texto cifrado:", ciphertext)
        else:
            with open(args.output, 'w') as f:
                f.write(ciphertext)

    # Descifrar
    elif args.operation == "-D":
        if args.input is None:
            ciphertext = input("Ingrese el mensaje a descifrar: ")
        else:
            with open(args.input, 'r') as f:
                ciphertext = f.read()

        plaintext = hill.decrypt(ciphertext)
        if args.output is None:
            print("Texto descifrado:", plaintext)
        else:
            with open(args.output, 'w') as f:
                f.write(plaintext)

    else:
        print("Operación no válida. Use -C para cifrar o -D para descifrar.")
        return -1

if __name__ == "__main__":
    main()