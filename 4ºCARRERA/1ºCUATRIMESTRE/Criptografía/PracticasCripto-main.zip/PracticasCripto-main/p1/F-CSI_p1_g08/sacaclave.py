
from collections import Counter

def sakaklave(message, tamkey):
    masterdata = [[] for i in range(tamkey)]  # Inicializa una lista de listas vacilas

    listas = {chr(i + 65): [0] * tamkey for i in range(26)}  # Crea un diccionario con listas de tamaño tamkey inicializadas a 0
    respo =''
    i = 0
    for l in message:
        masterdata[i % tamkey].append(l)
        
        listas[l][i % tamkey] += 1
        i += 1


    for i in range(tamkey):
        contador = Counter({k: listas[k][i] for k in listas if listas[k][i] > 0})
        mas_frecuentes = contador.most_common(4)
        xosen_letters = [letra for letra, _ in mas_frecuentes]
        print(f"\nPosición {i}: Letras más frecuentes: {', '.join(xosen_letters)}")
        
        encontrado=0
        for j in range(4):
            for k in range(4):
                
                if encontrado==0:
                    if j != k:
                        difference = ord(xosen_letters[k]) - ord(xosen_letters[j])
                        if difference == 4:
                            if chr((((ord(xosen_letters[j])-65)+14)%26)+65) in xosen_letters:
                                respo +=xosen_letters[j]
                                encontrado=1

                        elif difference == 10:
                            respo+=chr((((ord(xosen_letters[j])-65)-4)%26)+65)
                            encontrado = 1
                        

    return respo
