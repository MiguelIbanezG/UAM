import argparse
import random
import os

class Transposicion:
    def __init__(self, permutation, num_elements=None, input=None, output=None):
        self.permutation = permutation
        self.num_elements = num_elements
        self.input = input
        self.output = output

    def permute(self, message):
        # Convierte la permutación en una lista de enteros
        permutation_list = [int(p) for p in self.permutation.split()]
        permuted_message = ''

        if self.num_elements is None:
            # Toma la longitud de la permutación
            self.num_elements = len(permutation_list)

        # Calcula cuántas veces se debe repetir el mensaje
        repeat_times = (len(message) + self.num_elements - 1) // self.num_elements

        # Repite el mensaje
        repeated_message = message.ljust(repeat_times * self.num_elements, ' ')

        for i in range(0, len(repeated_message), self.num_elements):
            # Divide el mensaje en bloques del tamaño especificado
            block = repeated_message[i:i + self.num_elements]
            # Realiza la permutación de cada bloque
            permuted_block = [block[p - 1] for p in permutation_list]
            permuted_message += ''.join(permuted_block)

        return permuted_message


    def unpermute(self, ciphertext):
        if self.num_elements is None:
            self.num_elements = len(self.permutation)

        unpermuted_message = ''
        permutation_list = [int(p) for p in self.permutation.split()]
        block_size = len(permutation_list)

        for i in range(0, len(ciphertext), block_size):
            # Divide el texto cifrado en bloques del tamaño de la permutacion
            block = ciphertext[i:i + block_size]
            # Inicializamos un bloque despermutado como una lista de espacios
            unpermuted_block = [' '] * block_size

            for j, p in enumerate(permutation_list):
                # Deshacemos la permutación de cada bloque.
                unpermuted_block[p - 1] = block[j]

            unpermuted_message += ''.join(unpermuted_block)

        return unpermuted_message

def generate_random_permutation(num_elements, output_filename):
    # Generamos una permutación de 1 a num_elements.
    permutation = list(range(1, num_elements + 1))
    # Mezclamos aleatoriamente la permutación.
    random.shuffle(permutation)
    with open(output_filename, 'w') as f:
        f.write(' '.join(map(str, permutation)))


def main():
    parser = argparse.ArgumentParser(description='Transposicion')
    parser.add_argument('-C', dest='operation', action='store_const', const='C', help='Operacion a realizar: -C para cifrar')
    parser.add_argument('-D', dest='operation', action='store_const', const='D', help='Operacion a realizar: -D para descifrar')
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('-p', '--permutation', type=str, help='Cadena conteniendo la permutacion')
    group.add_argument('-n', '--num_elements', type=int, help='Número de elementos que se permutan (solo con -C)')
    parser.add_argument('-i', '--input', default=None, help='Archivo de entrada')
    parser.add_argument('-o', '--output', default=None, help='Archivo de salida')

    args = parser.parse_args()

    if args.operation == 'C':
        if args.permutation is None and args.num_elements is None:
            parser.error('Se debe especificar una permutación con -p o el número de elementos con -n para cifrar')

        if args.permutation is None:
            if not os.path.exists('permutacion.dat'):
                generate_random_permutation(args.num_elements, 'permutacion.dat')
            with open('permutacion.dat', 'r') as f:
                args.permutation = f.read()

    if args.operation == 'D' and args.permutation is None:
        parser.error('Se debe especificar una permutación con -p para descifrar')

    transposer = Transposicion(args.permutation, args.num_elements, args.input, args.output)

    if args.input is None:
        message = input("Ingrese el mensaje a cifrar o descifrar: ")
    else:
        with open(args.input, 'r') as f:
            message = f.read()

    if args.operation == 'C':
        ciphertext = transposer.permute(message)
        if args.output is None:
            print("Texto cifrado:", ciphertext)
        else:
            with open(args.output, 'w') as f:
                f.write(ciphertext)

    elif args.operation == 'D':
        plaintext = transposer.unpermute(message)
        if args.output is None:
            print("Texto descifrado:", plaintext)
        else:
            with open(args.output, 'w') as f:
                f.write(plaintext)
    else:
        print("Operacion no valida. Use -C para cifrar o -D para descifrar.")

if __name__ == "__main__":
    main()
