import argparse

def powmod(saddiebass, snowexp, n):
    # Inicializa el acumulador a 1 y apow2 a 'a'
    accum = 1
    i = 0
    apow2 = saddiebass
    
    # Mientras el bit actual de 'snowexp' sea mayor que 0
    while ((snowexp >> i) > 0):
        # Si el bit actual de 'snowexp' es 1, actualiza el acumulador
        if ((snowexp >> i) & 1):
            accum = (accum * apow2) % n
        
        # Actualiza 'apow2' al cuadrado módulo 'n'
        apow2 = (apow2 * apow2) % n
        
        # Mueve al siguiente bit de 'snowexp'
        i += 1
    
    # Devuelve el resultado final
    return accum


def main():

    parser = argparse.ArgumentParser(description='Potencia')
    parser.add_argument('-b', '--base', type=int, help='Base')
    parser.add_argument('-e', '--exponente', type=int, help='Eksponente')
    parser.add_argument('-m', '--modulo', type=int, help='Modulo')

    args = parser.parse_args()
    res = powmod(args.base, args.exponente,args.modulo )
    print(res)


if __name__ == "__main__":
    main()