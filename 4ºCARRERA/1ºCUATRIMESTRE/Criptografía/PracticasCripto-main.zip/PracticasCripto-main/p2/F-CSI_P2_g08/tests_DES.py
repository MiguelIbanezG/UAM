#esto no es funcional. Hay q hacer una funcion DESDEMENTIRA àra observar lo que ocurre con la linealidad.
#IMPORTANTE => F(A) ^ F(B) != F(A ^ B), 


import random
from utils import s_boxs
import argparse



def funcionF(rnm,kn):

    expansion_e = [
    32,  1,  2,  3,  4,  5,
     4,  5,  6,  7,  8,  9,
     8,  9, 10, 11, 12, 13,
    12, 13, 14, 15, 16, 17,
    16, 17, 18, 19, 20, 21,
    20, 21, 22, 23, 24, 25,
    24, 25, 26, 27, 28, 29,
    28, 29, 30, 31, 32,  1
    ]
    permutation_p = [
                     16,  7, 20, 21,
                     29, 12, 28, 17,
                      1, 15, 23, 26,
                      5, 18, 31, 10,
                      2,  8, 24, 14,
                     32, 27,  3,  9,
                     19, 13, 30,  6,
                     22, 11,  4, 25
    ]
    eRnm = ''.join(rnm[i - 1] for i in expansion_e)
    #print(rnm)
    #print(eRnm)
    salida =''.join(str(int(a) ^ int(b)) for a, b in zip(eRnm,kn)) #xor entre eRnm y kn
    #print("SALIDA=>",salida)
    #apartir de aki tocan las cajas S
    blocks = [salida[i:i+6] for i in range(0, len(salida), 6)]
    vaina = ''
    for i, block in enumerate(blocks):
        row = int(block[0] + block[5], 2)
        col = int(block[1:5], 2)
        vaina += format(s_boxs[i][row][col], '04b')
    #print(vaina)
    stayugly = ''.join(vaina[i - 1] for i in permutation_p)
    
    return stayugly


def test1(tests):
    diferencias = 0

    for x in range(tests):
        #if x%10000 ==0:
        #    print(x)
        #clave = random.getrandbits(64)
        clave = bin(random.getrandbits(64))[2:].zfill(64)
        #se generan dos numeros aleatorios de 64b
        snowstr = bin(random.getrandbits(64))[2:].zfill(64)
        witchy = bin(random.getrandbits(64))[2:].zfill(64)
        snow2 = funcionF(snowstr,clave)
        witchy2 = funcionF(witchy,clave)
        c =''.join(str(int(a) ^ int(b)) for a, b in zip(snowstr,witchy)) #xor entre eRnm y kn
        #print(snow2)
        #print(witchy)
        saddiepinn1 =''.join(str(int(a) ^ int(b)) for a, b in zip(snow2,witchy2)) #xor entre eRnm y kn
        saddiepinn2 = funcionF(c,clave)
        if saddiepinn1 != saddiepinn2:
            diferencias+=1
    print("\n[*] TEST 1 :NO LINEALIDAD DEL DES \nComprobacion a realizar => F(A ^ B) != F(A) ^ F(B)")
    print("\tporcentaje de veces que se ha cumplido la desigualdad =",(diferencias/tests)*100,"%")

def test2(tests):
    nastya = [[0, 0] for _ in range(32)]

    for x in range(tests):
        clave = bin(random.getrandbits(64))[2:].zfill(64)
        snowstr = bin(random.getrandbits(64))[2:].zfill(64)
    
        snow2 = funcionF(snowstr,clave)
        ctr =0
        for i in snow2:
            #print(type(i))
            if i =='0' :
                nastya[ctr][0]+=1      
            elif i=='1':
                nastya[ctr][1]+=1      
            else:
                print("HA HABIDO UN ERROR")
                return -1
            ctr+=1
        
    print("\n[*] TEST 2 :EFECTO AVALANCHA DES \nComprobacion a realizar => P(1) == P(0) para una misma posicion\n")
    for k in range(len(nastya)):
        print("\tpos",k,"=> P(0)=",nastya[k][0]/tests,"P(1)=",nastya[k][1]/tests)
    


def main():
    parser = argparse.ArgumentParser(description='TestsDesSboxes')
    parser.add_argument('-t', '--tests', type=int,default=100000, help='numero de tests a realizar(100000 por defecto)')
    args = parser.parse_args()
    print("numero de tests :",args.tests)

    test1(args.tests)
    test2(args.tests)


if __name__ == "__main__":
    main()
