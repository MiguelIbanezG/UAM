import argparse

class SBOXAES:
    
    def __init__(self) -> None:
        self.sbox = [0] * 256
        

    def desplazar(self, x, bitc):
        return ((x << bitc) | (x >> (8 - bitc))) & 0xFF

    def bleng(self, bit):
        leng = 0
        while bit:
            bit >>= 1
            leng += 1
        return leng

    def inverso(self, bit):
        c, a0, v1, a1 = 0, 0x11b, 1, bit

        while a1 != 0:
            sel, sel1 = c, a0
            q = self.bleng(a0) - self.bleng(a1)

            if q >= 0:
                sel ^= v1 << q
                sel1 ^= a1 << q

            c, a0, v1, a1 = v1, a1, sel, sel1

        if c >= 0x100:
            c ^= 0x11b

        return c


    def sbox_directa(self):
        
        for i in range(1, 256):
            b = self.inverso(i)
            self.sbox[i] = b ^ self.desplazar(b, 1) ^ self.desplazar(b, 2) ^ self.desplazar(b, 3) ^ self.desplazar(b, 4) ^ 0x63

        self.sbox[0] = 0x63
        return self.sbox

    def sbox_inversa(self):
        

        for i in range(1, 256):
            b = self.desplazar(i, 1) ^ self.desplazar(i, 3) ^ self.desplazar(i, 6) ^ 0x05
            self.sbox[i] = self.inverso(b)

        self.sbox_i[0] = 0x05
        return self.sbox

    
def main():
    parser = argparse.ArgumentParser(description='Afin')
    parser.add_argument('-C', dest='operation', action='store_const', const='-C', help='-C se utiliza el método equiprobable')
    parser.add_argument('-D', dest='operation', action='store_const', const='-D', help='-D se utiliza el método no equiprobable')
    parser.add_argument('-o', '--output', default=None, help='Archivo de salida')

    args = parser.parse_args()

    if args.operation is None:
        parser.error('Se debe especificar una forma de probabilidad -P o -I')

    seryerson = SBOXAES()

    if args.operation == '-C':
        print('Metodo Directo')
        sbox_d = seryerson.sbox_directa()

        if args.output is None:
            for val in sbox_d:
                print(f"{val:x}\t", end="")
            print("\n")

        else:
            with open(args.output, 'w') as f:
                for val in sbox_d:
                    #print(, file=output, end="")
                    f.write(f"{val:x}\t")

    elif args.operation == '-D':
        print('Metodo Indirecto')
        sbox_i = seryerson.sbox_directa()

        if args.output is None:
            for val in sbox_i:
                print(f"{val:x}\t",end="")
            print("\n")

        else:
            with open(args.output, 'w') as f:
                for val in sbox_d:
                    #print(, file=output, end="")
                    f.write(f"{val:x}\t")

    else:
        print("Operacion no valida. Use -C o -D.")
        return -1

if __name__ == "__main__":
    main()