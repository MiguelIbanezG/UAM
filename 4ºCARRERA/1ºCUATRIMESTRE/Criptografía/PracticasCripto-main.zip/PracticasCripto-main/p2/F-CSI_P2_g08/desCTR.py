

import argparse
import binascii
from utils import hex_totext, hex_tobin,text_tohex,rota_binaria,s_boxs, ip_permutation,neg_ip_permu,str_tobin

class DesCtr:
    def __init__(self,key,ctr) -> None:
        #print(key)
        self.key = key
        self.ctr = ctr % 2**64


    
    def enkrypt(self, message):

    
        blokes = []
        blokespinn = []
        sks = self.subkeys()
        #message = bytes(message)
        
        for i in range(0, len(message), 16):
            bloke_ex = message[i:i+16].ljust(16, '0')
            blokes.append(bloke_ex)
            #print(bloke_ex)
        
        for bloke_ex in blokes:
            #print("\n")
            hexnastya = self.ctr.to_bytes(8, byteorder='big')
            #   print(hexnastya)
            # Convertir el valor entero a binario
            binario_bloke = bin(int.from_bytes(hexnastya, byteorder='big'))[2:]
            # Asegurarse de que tenga 64 bits (rellenar con ceros si es necesario)
            binario_bloke = binario_bloke.zfill(64)
            bin_saddie = str_tobin(bloke_ex)
            #print(binario_bloke,"ctr_bin")
            #print(bin_saddie,"PLAIN-bin")
            b_L = binario_bloke[:32]
            b_R = binario_bloke[32:]



            permu = ''.join(binario_bloke[i - 1] for i in ip_permutation) 
            b_L = permu[:32]
            b_R = permu[32:]
            for i in range(16):
                faux = self.funcionF(b_R,sks[i])
                newR =''.join(str(int(a) ^ int(b)) for a, b in zip(faux,b_L))
                b_L = b_R
                b_R = newR
            vainafinal =b_R+b_L
            saddiepinn = ''.join(vainafinal[i - 1] for i in neg_ip_permu) 
            #print(saddiepinn,"RESU")
            kreslina =''.join(str(int(a) ^ int(b)) for a, b in zip(saddiepinn,bin_saddie))
            #print("=")
            #print(kreslina,"ZIPHER-bin")
            hex_saddiepinn = hex(int(kreslina, 2))[2:].zfill(16)  # Asegura que tenga 16 caracteres

            #print(hex_saddiepinn,"ZIPHER")
            blokespinn.append(hex_saddiepinn)
            self.ctr+=1
            if self.ctr>=2**64:
                self.ctr = 0
        #print(blokespinn)

        salidapinn = ''
        for b in blokespinn:
            salidapinn+=b
        #print(salidapinn)

        return salidapinn
#
#    def dekrypt(self, ciphertxtx):
#        blokes = []
#        blokespinn = []
#        sks = self.subkeys()
#
#        for i in range(0, len(ciphertxtx), 16):
#            bloke_ex = ciphertxtx[i:i+16]
#            blokes.append(bloke_ex)
#            print(bloke_ex)
#        
#
#        for bloke_ex in blokes:
#            print("\n")
#            hexnastya = self.ctr.to_bytes(8, byteorder='big')
#            binario_bloke = bin(int.from_bytes(hexnastya, byteorder='big'))[2:].zfill(64)
#            bin_saddie = str_tobin(bloke_ex)
#
#            print(binario_bloke,"ctr_bin")
#            print(bin_saddie,"ZIPHER-bin")
#
#            b_L = binario_bloke[:32]
#            b_R = binario_bloke[32:]
#
#            for i in range(16):
#                faux = self.funcionF(b_R, sks[i])
#                newR = ''.join(str(int(a) ^ int(b)) for a, b in zip(faux, b_L))
#                b_L = b_R
#                b_R = newR
#
#            vainafinal = b_R + b_L
#            saddiepinn = ''.join(vainafinal[i - 1] for i in neg_ip_permu)
#            print(saddiepinn,"RESU")
#            kreslina = ''.join(str(int(a) ^ int(b)) for a, b in zip(saddiepinn, bin_saddie))  # XOR entre eRnm y kn
#            print("=")
#            print(kreslina,"PLAIN-bin")
#            hex_saddiepinn = hex(int(kreslina, 2))[2:].zfill(16)
#            blokespinn.append(hex_saddiepinn)
#
#            print(hex_saddiepinn,"ZIPHER")
#
#            self.ctr += 1
#            if self.ctr >= 2**64:
#                self.ctr = 0
#
#        salidapinn = ''.join(blokespinn)
#        return salidapinn

    def funcionF(self,rnm,kn):

        expansion_e = [
        32,  1,  2,  3,  4,  5,
         4,  5,  6,  7,  8,  9,
         8,  9, 10, 11, 12, 13,
        12, 13, 14, 15, 16, 17,
        16, 17, 18, 19, 20, 21,
        20, 21, 22, 23, 24, 25,
        24, 25, 26, 27, 28, 29,
        28, 29, 30, 31, 32,  1
        ]
        permutation_p = [
                         16,  7, 20, 21,
                         29, 12, 28, 17,
                          1, 15, 23, 26,
                          5, 18, 31, 10,
                          2,  8, 24, 14,
                         32, 27,  3,  9,
                         19, 13, 30,  6,
                         22, 11,  4, 25
        ]
        eRnm = ''.join(rnm[i - 1] for i in expansion_e)
        
        salida =''.join(str(int(a) ^ int(b)) for a, b in zip(eRnm,kn)) #xor entre eRnm y kn
        #print("SALIDA=>",salida)

        #apartir de aki tocan las cajas S
        blocks = [salida[i:i+6] for i in range(0, len(salida), 6)]
        vaina = ''
        for i, block in enumerate(blocks):
            row = int(block[0] + block[5], 2)
            col = int(block[1:5], 2)
            vaina += format(s_boxs[i][row][col], '04b')

        #print(vaina)
        stayugly = ''.join(vaina[i - 1] for i in permutation_p)
        #print("ST",stayugly)
        #aki

        return stayugly

    def subkeys(self):
        
        pc1_permutation = [
        57, 49, 41, 33, 25, 17, 9,
        1, 58, 50, 42, 34, 26, 18,
        10, 2, 59, 51, 43, 35, 27,
        19, 11, 3, 60, 52, 44, 36,
        63, 55, 47, 39, 31, 23, 15,
        7, 62, 54, 46, 38, 30, 22,
        14, 6, 61, 53, 45, 37, 29,
        21, 13, 5, 28, 20, 12, 4
        ]
        pc2_permutation = [
         14, 17, 11, 24,  1,  5,
          3, 28, 15,  6, 21, 10,
         23, 19, 12,  4, 26,  8,
         16,  7, 27, 20, 13,  2,
         41, 52, 31, 37, 47, 55,
         30, 40, 51, 45, 33, 48,
         44, 49, 39, 56, 34, 53,
         46, 42, 50, 36, 29, 32
        ]
        shifteo = [1, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1]
        permu = ''

        ks = []
        #print("\n\n\nSUBKEYUS\n")
        #print(self.key)
        binkey = hex_tobin(self.key)
        #print(binkey)


        permu = ''.join(binkey[i - 1] for i in pc1_permutation)
       # print("PERMU_56:",' '.join([permu[i:i+7] for i in range(0, len(permu), 7)]))
        c = permu[:28]
        d = permu[28:]
        #print(c)
        #print(d)
        for i in range(len(shifteo)):
            c = rota_binaria(c,shifteo[i])
            d = rota_binaria(d,shifteo[i])
            #print("C",i,"=>",c)
            #print("D",i,"=>",d)  
            vaina = c+d
            #print(vaina)
            permu = ''.join(vaina[i - 1] for i in pc2_permutation)  
            ks.append(permu)
            #print("\n") 
        return ks
        
def main():

    parser = argparse.ArgumentParser(description='Afin')
    parser.add_argument('-C', dest='operation', action='store_const', const='-C', help='-C cifra la entrada')
    parser.add_argument('-D', dest='operation', action='store_const', const='-D', help='-D descifra la entrada')
    parser.add_argument('-k', '--key', type=str, help='Clave para cifrar o descifrar en formato hexadecimal.')
    parser.add_argument('-ctr', '--counter', type=int, help='Contador inicial')

    parser.add_argument('-i', '--input', default=None, help='Archivo de entrada')
    parser.add_argument('-o', '--output', default=None, help='Archivo de salida')

    args = parser.parse_args()

    # Verificar la operacion seleccionada
    if args.operation is None:
        parser.error('Se debe especificar -D o -C')

    # Aqui puedes usar args.operation para determinar si es cifrado o descifrado
    if args.operation == '-C':
        print('Modo cifrado seleccionado')
    elif args.operation == '-D':
        print('Modo descifrado seleccionado')
    if args.key is not None:
        if  len(args.key) == 16:
            hexoklave = args.key
            try:
                clave = bytes.fromhex(hexoklave)
                print(f'La clave proporcionada en formato hexadecimal es: {hexoklave}')
            except ValueError:
                print('Error: La clave no es un valor hexadecimal válido.')
                return -1
        else:
            print('La clave que ha proporcionado no es de la longitud correcta. Ha de ser de 48 caracteres en hexadecimal')
            return -1

    else:
        print('Se requiere una clave. Utilice el argumento -k o --key para proporcionar una clave.')
        return -1


    seryerson = DesCtr(args.key, args.counter)


#ekiprobable
    if args.operation == "-C":

        if args.input is None:
            message = input("Ingrese el mensaje a cifrar: ")
        else:
            with open(args.input, 'rb') as f:
                message = f.read()
        if isinstance(message, str):
            
            message = bytes(message,encoding='utf-8')
           # print("MESAGE EN HEXA:",message)  
        
        jex = message.hex()

        ciphertext = seryerson.enkrypt(jex)
        #print(type(ciphertext))

        if args.output is None:
            print("Texto cifrado:", ciphertext)

        else:
            with open(args.output, 'wb') as f:
                f.write(bytes(ciphertext,encoding='utf8'))

                print("COMPLETADO CON EKSITO<3")
                return 0

#no ekiprobable
    elif args.operation == "-D":

        if args.input is None:
            cyphertxt = input("Ingrese el mensaje a descifrar: ")
        else:
            with open(args.input, 'r') as f:
                cyphertxt = f.read()
        #print(type(cyphertxt))
        cmessage = seryerson.enkrypt(cyphertxt)
        #print("AAAAAAAA",type(cmessage))
        if args.output is None:
            print("Texto descifrado:", hex_totext(cmessage))

        else:
            
            with open(args.output, 'w') as f:
                f.write(hex_totext(cmessage))
                print("COMPLETADO CON EKSITO<3")
                return 0

    else:
        print("Operacion no valida. Use -C o -D.")
        return -1

if __name__ == "__main__":
    main()