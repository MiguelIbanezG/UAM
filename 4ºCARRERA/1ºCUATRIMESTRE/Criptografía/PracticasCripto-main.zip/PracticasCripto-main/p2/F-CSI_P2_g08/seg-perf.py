import argparse
import random
import string


class SegPerf:
    
    def __init__(self) -> None:
        
        self.clave= []
        self.probabilidad_texto_plano= []
        self.notadapt=[' ', '.', ',','«','»','1','2','3','4','5','6','7','8','9','0','¡','!','¿','?','—',':',';','\n','(',')']
        self.listas = {chr(i + 65): [0]*2 for i in range(26)}  # Crea un diccionario con listas de tamaño tamkey inicializadas a 0
        self.ocurrencias_pares = {chr(i + 65): {chr(j + 65): 0 for j in range(26)} for i in range(26)}
        self.probabilidad_pares = {chr(i + 65): {chr(j + 65): 0 for j in range(26)} for i in range(26)}

    def encrypt(self,message,method):

        zipher = ''
        leng = len(message)

        

        if method== '-P':
            print("Equiprobable")
            for i in range(26):
                self.clave.append(i)

        elif method == '-I':
            print("No Equiprobable")
            for i in range(26):
                if (i%2==0):
                    self.clave.append(23)
                else:
                    self.clave.append(i)
        else:
            print("Debes poner como argumento -I o -P")
        
        for l in message.upper():
            if l not in self.notadapt:
                self.listas[l][0] += 1
                xar_kript=chr(((ord(l)-65+random.choice(self.clave))%26)+65)
                zipher+=xar_kript
                self.listas[xar_kript][1] += 1
        

        print("Clave =>",self.clave) 

    
        for char, counts in self.listas.items():
            print(f"{char}: Ocurrencias-plano: {counts[0]} - Ocurrencias-cif: {counts[1]}")
            counts[0] /= leng  # Calculando la frecuencia del texto plano
            counts[1] /= leng  # Calculando la frecuencia del texto cifrado
            print(f"{char}: Frec-plano: {counts[0]} - Frec-cif: {counts[1]} \n")

        zipher = zipher.upper()
        message = message.upper()
        for i in range(len(zipher) - 1):
            if message[i] not in self.notadapt:
                # Calcular las ocurrencias de los pares
                self.ocurrencias_pares[message[i]][zipher[i]] += 1

        # Imp las ocurrencias de los pares
        for char1, counts1 in self.ocurrencias_pares.items():
            for char2, count in counts1.items():
                print(f"Par: {char1}{char2} - Ocurrencias: {count}")

        for letra_x in range(26):
            for letra_y in range(26):
                # Calcular la probabilidad/frecuencia de cada par de letras
                self.probabilidad_pares[chr(letra_x + 65)][chr(letra_y + 65)] = self.ocurrencias_pares[chr(letra_x + 65)][chr(letra_y + 65)] / leng
                print(f"p({chr(letra_x + 65)} | {chr(letra_y + 65)}) = {self.probabilidad_pares[chr(letra_x + 65)][chr(letra_y + 65)]}\t")

        for letra_x in range(26):
            for letra_y in range(26):
                res = None
                for char, counts in self.listas.items():
                    if counts[1]!=0:
                        # Dividir por la probabilidad de la segunda letra para obtener p(x|y)
                        res = self.probabilidad_pares[chr(letra_x + 65)][chr(letra_y + 65)] / counts[1]
                        break

                if res is not None:
                    print(f"p({chr(letra_x + 65)} | {chr(letra_y + 65)}) = {res}\t")
               
        return None
        
def main():
    parser = argparse.ArgumentParser(description='Afin')
    parser.add_argument('-P', dest='operation', action='store_const', const='-P', help='-P se utiliza el método equiprobable')
    parser.add_argument('-I', dest='operation', action='store_const', const='-I', help='-I se utiliza el método no equiprobable')
    parser.add_argument('-i', '--input', default=None, help='Archivo de entrada')
    parser.add_argument('-o', '--output', default=None, help='Archivo de salida')

    args = parser.parse_args()

    if args.operation is None:
        parser.error('Se debe especificar una forma de probabilidad -P o -I')

    if args.operation == '-P':
        print('Metodo equiprobable seleccionado')
    elif args.operation == '-I':
        print('Metodo equiprobable seleccionado')
    
    seryerson = SegPerf()

#ekiprobable
    if args.operation == "-P":

        if args.input is None:
            message = input("Ingrese el mensaje a cifrar: ")
        else:
            with open(args.input, 'r') as f:
                message = f.read()

        seryerson.encrypt(message,args.operation)

#no ekiprobable
    elif args.operation == "-I":

        if args.input is None:
            message = input("Ingrese el mensaje a cifrar: ")
        else:
            with open(args.input, 'r') as f:
                message = f.read()

        seryerson.encrypt(message,args.operation)

    else:
        print("Operacion no valida. Use -P o -I.")
        return -1

if __name__ == "__main__":
    main()