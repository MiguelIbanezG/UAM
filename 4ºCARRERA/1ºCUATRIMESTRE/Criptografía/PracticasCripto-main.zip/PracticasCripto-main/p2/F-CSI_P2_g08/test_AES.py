#esto no es funcional. Hay q hacer una funcion DESDEMENTIRA àra observar lo que ocurre con la linealidad.
#IMPORTANTE => F(A) ^ F(B) != F(A ^ B), 


import random
from utils import sboxes_directa,sboxes_inversa
import argparse



def test1(tests, sbox):
    diferencias = 0
    for x in range(tests):
        a = random.randint(0,255)
        b = random.randint(0,255)
        snowstr = sbox[a]
        witchy = sbox[b]
        c = a ^ b
        saddiepinn1 = hex(int(snowstr, 16) ^ int(witchy, 16))[2:]
        saddiepinn2 = sbox[c]


        if saddiepinn1 != saddiepinn2:
            diferencias += 1

    print("\tporcentaje de veces que se ha cumplido la desigualdad =", (diferencias / tests) * 100, "%")



def main():
    parser = argparse.ArgumentParser(description='Tests AES Sboxes')
    parser.add_argument('-t', '--tests', type=int,default=100000, help='numero de tests a realizar(100000 por defecto)')
    args = parser.parse_args()
    print("numero de tests :",args.tests)

    print("\n[*] TEST 1 : NO LINEALIDAD DEL AES (sbox-directa) \nComprobacion a realizar => F(A ^ B) != F(A) ^ F(B)")
    test1(args.tests,sboxes_directa)
    print("\n[*] TEST 2 : NO LINEALIDAD DEL AES (sbox-inversa)\nComprobacion a realizar => F(A ^ B) != F(A) ^ F(B)")
    test1(args.tests,sboxes_inversa)




if __name__ == "__main__":
    main()
