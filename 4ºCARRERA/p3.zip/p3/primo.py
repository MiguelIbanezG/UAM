import random
import argparse
import constants
import potencia
import math
import gmpy2
import time
from gmpy2 import mpz




def primo(n,m):
    numero = random.getrandbits(n)
    binxein = format(numero, f'0{n}b')
    binxein = '1' + binxein[1:-1] + '1'
    selek = int(binxein, 2)
 

    butx = 0
    rnda = 0
    while butx == 0:
        butx = 1
        rnda += 1
        for p in constants.primeros2000primos:
            if (selek % p == 0) & (butx == 1) & (selek != p):
                butx = 0
                selek += 2
                break

    binxein = format(selek, f'0{n}b')
    xekin =0
    while xekin == 0:
        xekin = 1
        if miillerTest(selek, m) == False:
            selek+=2
            xekin = 0

    compro = gmpy2.is_prime(selek)
    if  compro==False:
        print("NOPRIMO")
    elif compro == True:
        return selek

def miillerTest(n, k):
    d = n - 1
    s = 0
    while d % 2 == 0:
        d //= 2
        s += 1

    for _ in range(k):
        a = random.randint(2, n - 2)
        x = potencia.powmod(a, d, n)
        if x == 1 or x == n - 1:
            continue
        for _ in range(s - 1):
            x = potencia.powmod(x, 2, n)
            if x == n - 1:
                break
        else:
            return False

    return True

def m_creator(p, nbits):
    m = math.log(((nbits*(math.log(2))/p)-1), 4)
    return round(m)

def main():

    parser = argparse.ArgumentParser(description='Primo')
    parser.add_argument('-n', '--nbits', type=int, help='numero de bits')
    parser.add_argument('-p', '--sec', type=float, help='prob de fallo del algoritmo')
    args = parser.parse_args()
    if args.sec is None or args.nbits is None:
        print("ERROR: Ambos argumentos -n y -p son requeridos.")
        return 1
    if args.sec <= 0 or args.sec >= 100 or args.nbits <= 1:
        print("ERROR: Valores inválidos para -n o -p.")
        return 1
    m = m_creator(args.sec, args.nbits)
    print("Seguridad (m):", m)

    start_time = time.time()
    pospir = primo(args.nbits, m)
    end_time = time.time()

    print("Un posible primo de", args.nbits, "bits:")
    print(pospir)
    print("Resultado del test Miller-Rabin:", miillerTest(pospir, m))
    print("Resultado de GMP is_prime:", gmpy2.is_prime(pospir))
    print("Seguridad del primo (prob. de equivocación, veces que pasa el test):", args.sec, m)
    print("Tiempo de generación:", end_time - start_time, "segundos")
    return 0



if __name__ == "__main__":
    main()
