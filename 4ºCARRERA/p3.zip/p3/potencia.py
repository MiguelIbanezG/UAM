import argparse
import time

def powmod(saddiebass, snowexp, n):
    # Inicializa el acumulador a 1 y apow2 a 'a'
    accum = 1
    i = 0
    apow2 = saddiebass
    
    # Mientras el bit actual de 'snowexp' sea mayor que 0
    while ((snowexp >> i) > 0):
        # Si el bit actual de 'snowexp' es 1, actualiza el acumulador
        if ((snowexp >> i) & 1):
            accum = (accum * apow2) % n
        
        # Actualiza 'apow2' al cuadrado módulo 'n'
        apow2 = (apow2 * apow2) % n
        
        # Mueve al siguiente bit de 'snowexp'
        i += 1
    
    # Devuelve el resultado final
    return accum

def temporero(func, *args):
    start_time = time.time()
    result = func(*args)
    end_time = time.time()
    execution_time = end_time - start_time
    return result, execution_time


def main():

    parser = argparse.ArgumentParser(description='Potencia')
    parser.add_argument('-b', '--base', type=int, help='Base')
    parser.add_argument('-e', '--exponente', type=int, help='Eksponente')
    parser.add_argument('-m', '--modulo', type=int, help='Modulo')

    args = parser.parse_args()
    
    if args.base is None or args.exponente is None or args.modulo is None:
        print("No hay valores para base, exponente o módulo.")
        return -1

    if args.modulo <= 0:
        print("El módulo debe ser un entero positivo.")
        return -1

    result_powmod, time_powmod = temporero(powmod, args.base, args.exponente, args.modulo)

    # Imprimir resultados y tiempos
    print("Resultado powmod:", result_powmod)
    print("Tiempo de ejecución powmod:", time_powmod, "segundos")



if __name__ == "__main__":
    main()