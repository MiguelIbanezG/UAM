/** 
 * @brief Implementa las funciones necesarias para el test del modulo inventory
 * 
 * @file inventory_test.h
 * @author Mario García
 * @version 2.0 
 * @date 05-05-2021
 * @copyright GNU Public License
 */

#ifndef INVENTORY_TEST_H
#define INVENOTRY_TEST_H

#include <stdio.h>

void test1_inventory_create();
void test2_inventory_create();
void test1_inventory_set_addId();
void test2_inventory_set_addId();
void test3_inventory_set_addId();
void test1_inventory_set_delId();
void test2_inventory_set_delId();
void test3_inventory_set_delId();
void test4_inventory_set_delId();
void test1_inventory_setMax();
void test2_inventory_setMax();
void test3_inventory_setMax();
void test1_inventory_getId();
void test2_inventory_getId();
void test3_inventory_getId();
void test1_inventory_getMax();
void test2_inventory_getMax();
void test1_inventory_existId();
void test2_inventory_existId();
void test3_inventory_existId();
void test4_inventory_existId();
void test1_inventory_getTam();
void test2_inventory_getTam();
void test3_inventory_getTam();

#endif /*INVENTORY_TEST_H*/