/** 
 * @brief Implementa las funciones necesarias para el test del modulo set
 * 
 * @file set_test.h
 * @author Miguel Ibáñez
 * @version 2.0 
 * @date 05-05-2021
 * @copyright GNU Public License
 */

#ifndef SET_TEST_H
#define SET_TEST_H

#include <stdio.h>

void test1_set_create();
void test2_set_create();
void test1_set_add_id();
void test2_set_add_id();
void test3_set_add_id();
void test1_set_del_id();
void test2_set_del_id();
void test3_set_del_id();
void test1_set_findId();
void test2_set_findId();
void test1_set_idCheck();
void test2_set_idCheck();
void test1_set_getnIds();
void test2_set_getnIds();
void test3_set_getnIds();

#endif /*SET_TEST_H*/