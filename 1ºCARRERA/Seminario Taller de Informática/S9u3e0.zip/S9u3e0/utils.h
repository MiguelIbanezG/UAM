#ifndef UTILS_H
#define UTILS_H

#include "point.h"

float distance (Point p1, Point p2);

float norm (Point p);

#endif

