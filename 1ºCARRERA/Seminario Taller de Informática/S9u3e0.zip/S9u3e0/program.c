#include <stdio.h>
#include "point.h"
#include "utils.h"

int main (int argc, char *argv[]){
	Point a, b;

	a.x = 1; a.y = 1;
	b.x = 0; b.y = 0;
	printf("Distance: %f\n", distance(a, b));
	printf("Norm: %f\n", norm(a));
	printf("Norm: %f\n", norm(b));
	return 0;
}

