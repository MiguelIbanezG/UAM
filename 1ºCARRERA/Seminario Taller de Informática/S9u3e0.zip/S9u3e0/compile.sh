#!/bin/bash

OUT=exercise
task="compile"
if [ $# -gt 0 ] ; then
	task=$1
fi

if [ $task = "compile" ] ; then
	rm -f *.o
	gcc -c main.c
	gcc -c utils.c
elif [ $task = "link" ] ; then
	rm -f $OUT
	gcc main.o utils.o -lm -o $OUT
elif [ $task = "execute" ] ; then
	./$OUT
elif [ $task = "clean" ] ; then
	rm -f $OUT 
	rm -f *.o
fi

exit 0

