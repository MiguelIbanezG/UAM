#ifndef POINT_H
#define POINT_H
typedef struct _Point {
float x,y;
} Point;
#endif
