#include <stdio.h>
#include <math.h>
typedef struct _Point {
float x,y;
} Point;
float distance (Point p1, Point p2){
return sqrt( (p1.x-p2.x)*(p1.x-p2.x) + (p1.y-p2.y)*(p1.y-p2.y) );
}
float norm (Point p){
return sqrt( p.x*p.x + p.y*p.y );
}
int main (int argc, char *argv[]){
Point a, b;
a.x = 1; a.y = 1;
b.x = 0; b.y = 0;
printf("Distanc: %f\n", distance(a, b));
printf("Norm: %f\n", norm(a));
printf("Norm: %f\n", norm(b));
return 0;
