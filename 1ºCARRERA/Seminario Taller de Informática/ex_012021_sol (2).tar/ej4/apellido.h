#include <stdio.h>

int mayor(int v1, int v2);
