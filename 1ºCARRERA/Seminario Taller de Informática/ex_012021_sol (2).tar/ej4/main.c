#include "apellido.h"

int main() {
	int uno, dos, resultado;
	printf("Introduce el primer numero: ");
	scanf("%d", &uno);

	printf("Introduce el segundo numero: ");
	scanf("%d", &dos);

	resultado = mayor(uno, dos);
	printf("El mayor numero de los dos es: %d", resultado);

	return 0;
}
