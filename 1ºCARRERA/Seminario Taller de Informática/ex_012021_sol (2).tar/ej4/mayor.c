#include "apellido.h"

int mayor(int v1, int v2) {
	if (v1<v2) {
		return v2;
	}
	if (v2<v1) {
		return v1;
	}
}

