#!/bin/bash
read -p "Introduzca el directorio: " dir_name
read -p "Extension antigua: " old
read -p "Extension nueva: " new
for fo in $(ls *.$old)
do
  fn=${fo/%$old/$new}
  cp $fo $dir_name/$fn
  echo "Moviendo $fo -> $fn ..."
done
