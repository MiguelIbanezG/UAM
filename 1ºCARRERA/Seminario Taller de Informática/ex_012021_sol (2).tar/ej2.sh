#!/bin/bash
if [ $# -ne 1 ]
then
  echo "Sintaxis: $0 numero"
  exit 1
fi

if [ $(($1 % 2)) -ne 0 ]
then
  num=$(($1 -1))
else
  num=$1
fi
while [ $num -ge 0 ]
do
  echo "Cuenta: $num"
  num=$((num - 2))
done
