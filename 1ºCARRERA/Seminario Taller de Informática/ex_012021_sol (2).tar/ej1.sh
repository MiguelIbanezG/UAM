#!/bin/bash
x=0; i=1
while true
do
  echo "Introduzca la palabra $i"
  i=i+1;  read x
  if [ $x = "salir" ]
  then
    rm ord && exit
  else
    echo $x >> ord;  sort ord
  fi
done 
