#!/bin/bash

if [ $# -ne 1 ]
	then
	echo "El comando necesita como argumentos un fichero"
	exit 1;
fi

if [ -e $1 ]
then
	echo -n "El fichero $1 existe "
	if [ -x $1 ]
	then
		echo "y tienes el permiso para ejecutarlo."
	else
		echo "y no tienes el permiso para ejecutarlo."
	fi
else
	echo "El fichero $1 no existe"
fi

exit 0

