#!/bin/bash

declare -i cont0=0
declare -i cont1=0

for ((i=0; i<3*5; i++))
do
    if [ $2 -gt $1 ]
    then
        array[$i]=$((((RANDOM % ($2 - $1 + 1) ))+$1)) 	# utilizamos % y + para rescalar y desplazar (respectivamente) el rango de numeros aleatorios devueltos por $RANDOM
    fi

    if [ $1 -gt $2 ]
    then
        array[$i]=$((((RANDOM % ($1 - $2 + 1) ))+$2))
    fi

    if [ ${array[$i]} -eq 1 ]
    then
        let cont1++
    fi

    if [ ${array[$i]} -eq 0 ]
    then
        let cont0++
    fi

done

echo "La matriz aleatoria es"
for ((i=0; i<3; i++))
	do
	 for ((j=0; j<5; j++))
		do
		echo -n "${array[$j+$i*5]} "
		done
	echo ""
done

echo "La cantidad de unos en la tabla es $cont1 "

echo "La cantidad de ceros en la tabla es $cont0 "

exit 0

