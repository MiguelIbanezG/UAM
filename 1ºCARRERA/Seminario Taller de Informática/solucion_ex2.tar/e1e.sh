#!/bin/bash

for ((i=0; i<$1*$2; i++))
do
        array1[$i]=`echo $RANDOM`
        array2[$i]=`echo $RANDOM`
done

echo "La matriz aleatoria mat1 es"
for ((i=0; i<$1; i++))
	do
	 for ((j=0; j<$2; j++))
		do
		echo -n "${array1[$j+$i*$2]} "
		done
	echo ""
done

echo ""

echo "La matriz aleatoria mat2 es"
for ((i=0; i<$1; i++))
	do
	 for ((j=0; j<$2; j++))
		do
		echo -n "${array2[$j+$i*$2]} "
		done
	echo ""
done

echo ""
echo ""

echo "La diferencia mat1-mat2 es"
for ((i=0; i<$1; i++))
	do
	 for ((j=0; j<$2; j++))
		do
		echo -n "$((${array1[$j+$i*$2]}-${array2[$j+$i*$2]})) "
		done
	echo ""
done

exit 0

