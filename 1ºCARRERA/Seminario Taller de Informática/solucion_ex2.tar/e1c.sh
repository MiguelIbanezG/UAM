#!/bin/bash

for(( i=0; i<$1; i++ ))
do
	vector[$i]=$(($RANDOM))
done

echo "El vector original es ${vector[*]}."

for (( i=0; i<$(( $1/2 )); i++ ))
do
	cambio=${vector[i]}
	vector[$i]=${vector[$(( $1-(1+$i) ))]}
	vector[$(( $1-(1+$i) ))]=$cambio
done

echo "El vector invertido es ${vector[*]}."

exit 0

