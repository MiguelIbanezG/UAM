#!/bin/bash

if [ $# -ne 1 ]
   then
   echo "Debe indicar el directorio"
   exit 1
fi    

if [ -d $1 ]
   then
   cd $1
   ficheros=$(ls *.jpg)
   fecha=$(date +'%Y%m%d')
   contador=0
   for fichero in $ficheros
   do
     echo "Fichero actual:$fichero Fichero renombrado:${fecha}_${fichero}"
     mv $fichero "${fecha}_${fichero}"
     let "contador++"
   done

   echo "Se han renombrado $contador ficheros"
else
   echo "El directorio no existe"
   exit 1
fi 

exit 0

