#!/bin/bash

for ((i=0;i<3;i++))
do
read -p "Introduzca una frase: " tabla[i]
done

while true
	do
	echo "${tabla[$(($RANDOM%3))]}"
	sleep 40m
done


