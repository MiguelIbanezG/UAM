#!/bin/bash

dias=0
horas=0
semanas=0
empleado=1
sueldo_por_hora=0
empleados=0
sueldo=0
total=0

echo -n "Cantidad empleados: "
read empleados

echo -n "Sueldo por hora: "
read sueldo_por_hora

echo "--------" 
for ((empleado=1;$empleado<=$empleados;empleado++))
 do

   echo -n "Cuantas semanas ha trabajado en el mes el empleado $empleado? "
   read semanas

   echo -n "Cuantas dias ha trabajado cada semana el empleado $empleado? "
   read dias

   echo -n "Cuantas horas ha trabajado cada día el empleado $empleado? "
   read horas

   let "sueldo=$horas*$dias*$semanas*$sueldo_por_hora"

   echo "El empleado $empleado cobra un sueldo de: $sueldo"

   let "total+=$sueldo"

   echo "--------" 
done

echo "La empresa paga $total por $empleados empleados"

exit 0

