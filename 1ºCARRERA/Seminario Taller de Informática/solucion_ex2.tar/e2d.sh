#!/bin/bash
if [ -d $1 ]
	then
	echo "$1 existe"
else
	echo "$1 no existe"
	exit 1
fi

if [ $2 -lt 0 ]
	then
	echo "el numero no es valido"
	exit 1
fi

echo "el numero de ficheros en $1 es"
find $1 -maxdepth 1 -type f | wc -l	# -maxdepth 1 para que no baje en los subdirectorios
echo "el numero de ficheros que superan el tamaño de $2 bytes: "
find $1 -maxdepth 1 -type f -size +${2}c | wc -l      # + para indicar que queremos los ficheros más grandes del límite indicado; c para indicar que el tamaño es en bytes
exit 0

