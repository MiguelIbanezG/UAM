#!/bin/bash

if [ $# -ne 1 ]
	then
	echo "El comando necesita como argumentos el nombre de un usuario"
	exit 1;
fi

ps -u $1 aux --sort -rss | head    # opción sort para ordenar en base a la clave rss (resident set size: the non-swapped physical memory that a task has used) en orden decreciente (-)

