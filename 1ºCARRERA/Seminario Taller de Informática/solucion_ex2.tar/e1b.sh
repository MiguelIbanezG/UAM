#!/bin/bash

declare -i suma=0

for((i=0 ; i<$1; i++));
do
	let array[i]=$RANDOM;
done
for((i=0 ; i<$1; i++));
do
	let array[i]=array[i]*array[i];
	let suma=suma+array[i];
done
echo "La suma de los cuadrados de los elementos del vector de $1 elementos es $suma";
exit 0;

