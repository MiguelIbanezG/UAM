#include <stdio.h> 
#include <stdlib.h> 


int main() 
{ 
    char caracter; 
    int i,j,an,al; 
    FILE *out = fopen ( "y", "w" );
    i=0;j=0;an=0;al=0; 

    printf("Introduce caracter: "); 
    scanf("%c", &caracter); 
    printf("Introduce altura: "); 
    scanf("%i", &al); 
    printf("Introduce ancho: "); 
    scanf("%i", &an); 

    for(i=0;i<al;i++) 
    { 
        for(j=0;j<an;j++) 
        {   printf("%d %d\n",i,j); 
            fprintf (out, "%d %d\n", i,j );
        } 
     //printf("\n"); 
    } 
    return 0; 
} 

