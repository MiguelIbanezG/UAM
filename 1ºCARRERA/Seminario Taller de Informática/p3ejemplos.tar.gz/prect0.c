#include <stdio.h> 
#include <stdlib.h> 


int main() 
{ 
    char caracter; 
    int i,j,an,al; 

    i=0;j=0;an=0;al=0; 

    printf("Introduce caracter: "); 
    scanf("%c", &caracter); 
    printf("Introduce altura: "); 
    scanf("%i", &al); 
    printf("Introduce ancho: "); 
    scanf("%i", &an); 

    for(i=0;i<al;i++) 
    { 
        for(j=0;j<an;j++) 
        {   printf("%c",caracter); 
        } 
     printf("\n"); 
    } 
    return 0; 
} 

