
#include <stdio.h>
#include <stdlib.h>

int main()
{
  int i, j, X=0, Y=0;
  double slope;
  while (X<2 || Y<2){
    printf("Height of the triangle: ");
    scanf("%d",&Y);
    printf("Width of the triangle: ");
    scanf("%d",&X);
    if (X<2 || Y<2){
      printf("Dimensions must be bigger than 1.\n");
    }
  }

  Y--;
  X--;

  slope = (double)Y/X;

  for (i = Y; i >= 0; i--){
    for (j = 0; j <= X; j++){
      if ((i+(slope)*j) <= Y){
        printf("*");
      }
    }
    printf("\n");
  }

  return 0;
}
