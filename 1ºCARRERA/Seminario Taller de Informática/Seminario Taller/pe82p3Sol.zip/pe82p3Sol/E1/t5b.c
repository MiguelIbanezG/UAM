
#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main()
{
  int i, j, R=0;
  while (R<1){
    printf("Radius of the circle: ");
    scanf("%d",&R);
    if (R<1){
      printf("Radius must be bigger than 0.\n");
    }
  }


  for (i = 2*R; i >= 0; i--){
    for (j = 0; j <= 2*R; j++){
      if ((pow((i-R),2)+pow((j-R),2)) <= pow(R,2)){
        printf("*");
      }else{
        printf(" ");
      }
      printf(" ");
    }
    printf("\n");
  }

  return 0;
}
