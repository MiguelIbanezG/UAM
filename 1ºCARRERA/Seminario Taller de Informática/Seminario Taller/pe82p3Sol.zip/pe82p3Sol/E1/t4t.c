
#include <stdio.h>
#include <stdlib.h>


int main()
{
  int i, j, X=0, Y=0, n;
  double slope;


  printf("For a better result, it is recommended to use an odd number for the width.\n");

  while(X<2 || Y<2){
    printf("Height of the christmas tree: ");
    scanf("%d",&Y);
    printf("Width of the christmas tree: ");
    scanf("%d",&X);
    if (X<2 || Y<2){
      printf("Dimensions must be bigger than 2.\n");
    }
  }


  Y--;
  X--;


  slope = (double)Y/((double)X/2);

  for (i = Y; i >= 0; i--){
    if (i==Y && X%2){
      for (j = 0; j < X/2; j++){
        printf(" ");
      }
      printf("**");
    }
    for (j = 0; j <= X; j++){
      if (((i+(slope*j) <= 2*Y) && (i-(slope*j) <= 0))){
        n = rand()%10;
        if (!n){
          printf("$");
        }else if (n == 1){
          printf("%%");
        }else if (n == 2){
          printf("&");
        }else{
        printf("*");
        }
      }else{
        printf(" ");
      }
    }
    printf("\n");
  }

  if (X%2){
    for (j = 0; j < 2; j++){
      for (i = 0; i < (X/2); i++){
        printf(" ");
      }
      printf("HH");
      printf("\n");
    }
  }else {
    for (j = 0; j < 2; j++){
      for (i = 0; i < (X/2)-1; i++){
        printf(" ");
      }
      printf("HHH");
      printf("\n");
    }
    }

  return 0;
}
