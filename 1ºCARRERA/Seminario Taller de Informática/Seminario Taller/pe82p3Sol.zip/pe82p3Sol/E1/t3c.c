
#include <stdio.h>
#include <stdlib.h>

int main()
{
  int i,j,X=0,Y = 0,T = 0;
  while (Y < 3 || T < 1 || X < T+1){
    printf("Height of the letter: ");
    scanf("%d",&Y);
    printf("Width of the letter: ");
    scanf("%d",&X);
    printf("Thickness of the letter: ");
    scanf("%d",&T);
    if (Y < 3){
      printf("Recommended using a height bigger than 2.\n");
    }
    if (T < 1){
      printf("Recommended using a thickness bigger than 0.\n");
    }
    if (X < T+1){
      printf("Recommended using a width bigger than the thickness.\n");
    }
  }

  for (i = 0; i < Y; i++){
    if (i < T || i > Y-1-T){
      for (j = 0; j < X; j++){
        printf("*");
      }
    }else {
      for (j = 0; j < T; j++){
        printf("*");
      }
    }
    printf("\n");
  }
  return 0;
}
