
 #include <stdio.h>
 #include <stdlib.h>

 int main()
 {
   int i,j,X=0,Y=0;

   while (X < 3 || Y < 3){
     printf("Height of the rectangle: ");
     scanf("%d",&Y);
     printf("Width of the rectangle: ");
     scanf("%d",&X);
     if (X < 3 || Y < 3){
       printf("Dimensions must be bigger than 2.\n");
     }
   }


   for (j = 0; j < X; j++){
     printf("*");
   }
   printf("\n");

   for (i = 1; i < Y-1; i++){
      printf("*");
      for (j = 1; j < X-1; j++){
          printf(" ");
      }
      printf("*");
     printf("\n");
   }

   for (j = 0; j < X; j++){
     printf("*");
   }
   printf("\n");

   return 0;
 }
