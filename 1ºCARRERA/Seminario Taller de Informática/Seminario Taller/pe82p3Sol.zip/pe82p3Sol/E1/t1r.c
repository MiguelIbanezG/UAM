//e1=2.5, e2=2.5, e3=2.5, e4=2.5, t=10

#include <stdio.h>
#include <stdlib.h>


int main()
{
    int i,j,X = 0,Y = 0;
    while (X < 1 || Y < 1){
      printf("Height of the rectangle: ");
      scanf("%i", &Y);
      printf("Width of the rectangle: ");
      scanf("%i", &X);
      if (X < 1 || Y < 1){
        printf("Dimensions must be bigger than 0.\n");
      }
    }

    for(i=0;i<Y;i++){
        for(j=0;j<X;j++){
          printf("*");
        }
     printf("\n");
    }
    return 0;
}
