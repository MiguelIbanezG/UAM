
 #include <stdio.h>
 #include <math.h>

 int main()
 {
 	int y, i, S = 0;
 	while (S < 1){
 		printf("Size of the fractal: ");
 		scanf("%d",&S);
 		if (S < 1){
 			printf("Size must be bigger than 0.\n");
 		}
 	}
 	for (y = pow(2,S+1) - 1; y >= 0; y--, putchar('\n')) {
 		for (i = 0; i < y; i++) putchar(' ');
 		for (i = 0; i+y  < pow(2,S+1); i++)
 			if((i & y)) printf("  ") ;
 			else printf("* ");
 	}
 	return 0;
 }
