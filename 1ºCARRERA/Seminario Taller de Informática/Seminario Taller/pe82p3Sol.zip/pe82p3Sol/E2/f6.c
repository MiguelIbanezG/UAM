
 #include <stdio.h>
 #include <stdlib.h>
 #include "fig.h"

 void f6(int X, int Y){
   int i,j;

   for (j = 0; j < X; j++){
     printf("*");
   }
   printf("\n");

   for (i = 1; i < Y-1; i++){
      printf("*");
      for (j = 1; j < X-1; j++){
          printf(" ");
      }
      printf("*");
     printf("\n");
   }

   for (j = 0; j < X; j++){
     printf("*");
   }
   printf("\n");

 }
