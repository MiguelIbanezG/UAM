
#include <stdio.h>
#include <stdlib.h>
#include "fig.h"

void f2(int X, int Y){
  int i, j;
  double slope;
  Y--;
  X--;

  slope = (double)Y/X;

  for (i = Y; i >= 0; i--){
    for (j = 0; j <= X; j++){
      if ((i+(slope)*j) <= Y){
        printf("*");
      }
    }
    printf("\n");
  }
}
