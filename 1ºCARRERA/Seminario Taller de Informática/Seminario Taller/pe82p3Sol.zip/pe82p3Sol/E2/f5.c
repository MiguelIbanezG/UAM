
 #include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 #include "fig.h"

void f5(int R){
   int i,j;

   for (i = 2*R; i >= 0; i--){
     for (j = 0; j <= 2*R; j++){
       if ((pow((i-R),2)+pow((j-R),2)) <= pow(R,2)){
         printf("*");
       }else{
         printf(" ");
       }
       printf(" ");
     }
     printf("\n");
   }
 }
