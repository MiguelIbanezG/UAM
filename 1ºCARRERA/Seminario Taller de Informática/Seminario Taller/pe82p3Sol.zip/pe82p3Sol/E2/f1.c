
#include <stdio.h>
#include <stdlib.h>
#include "fig.h"

void f1(int X, int Y){
  int i,j;
  for(i=0;i<Y;i++)
  {
      for(j=0;j<X;j++)
      {   printf("*");
      }
   printf("\n");
  }
}
