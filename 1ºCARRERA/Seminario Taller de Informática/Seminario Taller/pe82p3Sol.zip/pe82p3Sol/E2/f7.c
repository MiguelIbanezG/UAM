
 #include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 #include "fig.h"

 void f7(int S){
   int i,y;

   for (y = pow(2,S+1) - 1; y >= 0; y--, putchar('\n')) {
  		for (i = 0; i < y; i++) putchar(' ');
  		for (i = 0; i+y  < pow(2,S+1); i++)
  			if((i & y)) printf("  ") ;
  			else printf("* ");
  	}
 }
