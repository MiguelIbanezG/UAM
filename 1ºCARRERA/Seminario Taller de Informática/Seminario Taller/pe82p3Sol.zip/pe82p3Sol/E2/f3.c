
#include <stdio.h>
#include <stdlib.h>
#include "fig.h"

void f3(int X, int Y, int T){
  int i, j;

  for (i = 0; i < Y; i++){
    if (i < T || i > Y-1-T){
      for (j = 0; j < X; j++){
        printf("*");
      }
    }else {
      for (j = 0; j < T; j++){
        printf("*");
      }
    }
    printf("\n");
  }

}
