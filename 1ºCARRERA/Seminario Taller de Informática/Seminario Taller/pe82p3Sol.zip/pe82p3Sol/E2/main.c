
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "fig.h"

int main(void){

  int option = 0, X=0,Y=0,R=0,T=0,S=0;

  printf("1. Rectangle\n2. Right Triangle\n3. Letter C\n4. Christmas Tree\n5. Circle\n6. Perimeter of Rectangle\n7. Sierpinski Fractal\n");

  while (option < 1 || option > 7){
    printf("Choose an option: ");
    scanf("%d",&option);
    if (option < 1 || option > 7){
      printf("Invalid number.\n");
    }
  }

  switch (option){
    case 1:
      while (X < 1 || Y < 1){
        printf("Height of the rectangle: ");
        scanf("%i", &Y);
        printf("Width of the rectangle: ");
        scanf("%i", &X);
        if (X < 1 || Y < 1){
          printf("Dimensions must be bigger than 0.\n");
        }
      }
      f1(X,Y);
    break;
    case 2:
      while (X<2 || Y<2){
	printf("Height of the triangle: ");
	scanf("%d",&Y);
	printf("Width of the triangle: ");
	scanf("%d",&X);
	if (X<2 || Y<2){
	  printf("Dimensions must be bigger than 1.\n");
	}
      }
      f2(X,Y);
    break;
    case 3:
      while (Y < 3 || T < 1 || X < T+1){
	printf("Height of the letter: ");
	scanf("%d",&Y);
	printf("Width of the letter: ");
	scanf("%d",&X);
	printf("Thickness of the letter: ");
	scanf("%d",&T);
	if (Y < 3){
	  printf("Recommended using a height bigger than 2.\n");
	}
	if (T < 1){
	  printf("Recommended using a thickness bigger than 0.\n");
	}
	if (X < T+1){
	  printf("Recommended using a width bigger than the thickness.\n");
	}
      }
      f3(X,Y,T);
    break;
    case 4:
      printf("For a better result, it is recommended to use an odd number for the width.\n");

      while(X<2 || Y<2){
	printf("Height of the christmas tree: ");
	scanf("%d",&Y);
	printf("Width of the christmas tree: ");
	scanf("%d",&X);
	if (X<2 || Y<2){
	  printf("Dimensions must be bigger than 2.\n");
	}
      }
      f4(X,Y);
    break;
    case 5:
      while (R<1){
	printf("Radius of the circle: ");
	scanf("%d",&R);
	if (R<1){
	  printf("Radius must be bigger than 0.\n");
	}
      }
      f5(R);
    break;
    case 6:
      while (X < 3 || Y < 3){
	printf("Height of the rectangle: ");
	scanf("%d",&Y);
	printf("Width of the rectangle: ");
	scanf("%d",&X);
	if (X < 3 || Y < 3){
	  printf("Dimensions must be bigger than 2.\n");
	}
      }
      f6(X,Y);
    break;
    case 7:
      while (S < 1){
	printf("Size of the fractal: ");
	scanf("%d",&S);
	if (S < 1){
	  printf("Size must be bigger than 0.\n");
	}
      }
      f7(S);
    break;
    default:
      printf("Error in switch.\n");
    break;
  }


  return 0;
}
