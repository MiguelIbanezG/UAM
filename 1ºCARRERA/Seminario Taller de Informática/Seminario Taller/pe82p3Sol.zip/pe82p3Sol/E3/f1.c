
#include <stdio.h>
#include <stdlib.h>
#include "fig.h"

void f1(int X, int Y){
  int i,j;
  FILE *f;

  if (!(f=fopen("fig","w"))){
    printf("Error opening file.\n");
  }

  for(i=0;i<Y;i++)
  {
      for(j=0;j<X;j++)
      {   fprintf(f,"%d\t%d\n",j,i);
      }
  }
  fclose(f);
}
