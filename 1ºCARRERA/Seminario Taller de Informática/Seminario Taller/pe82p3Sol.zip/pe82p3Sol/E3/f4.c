
#include <stdio.h>
#include <stdlib.h>
#include "fig.h"

void f4(int X, int Y){
  int i,j;
  double slope;
  FILE *f;

  if (!(f=fopen("fig","w"))){
    printf("Error opening file.\n");
  }

  Y--;
  X--;


  slope = (double)Y/((double)X/2);

  for (i = Y; i >= 0; i--){
    if (i==Y && X%2){
      fprintf(f,"%d\t%d\n%d\t%d\n",(X/2),Y,(X/2)+1,Y);
    }
    for (j = 0; j <= X; j++){
      if ((i+(slope*j) <= 2*Y) && (i-(slope*j) <= 0)){
          fprintf(f,"%d\t%d\n",j,i);
      }
    }
  }

  if (X%2){
    fprintf(f,"%d\t%d\n%d\t%d\n%d\t%d\n%d\t%d\n",(X/2),-1,(X/2)+1,-1,(X/2),-2,(X/2)+1,-2);
  }else {
    fprintf(f,"%d\t%d\n%d\t%d\n%d\t%d\n%d\t%d\n%d\t%d\n%d\t%d\n",(X/2)-1,-1,X/2,-1,(X/2)+1,-1,(X/2)-1,-2,X/2,-2,(X/2)+1,-2);
  }

  fclose(f);
}
