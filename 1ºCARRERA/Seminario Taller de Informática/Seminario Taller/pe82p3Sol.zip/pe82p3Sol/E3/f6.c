
 #include <stdio.h>
 #include <stdlib.h>
 #include "fig.h"

 void f6(int X, int Y){
   int i,j;
   FILE *f;

   if (!(f=fopen("fig","w"))){
     printf("Error opening file.\n");
   }

   for (j = 0; j < X; j++){
     fprintf(f,"%d\t%d\n",j,Y-1);
   }

   for (i = 1; i < Y-1; i++){
      fprintf(f,"%d\t%d\n%d\t%d\n",0,Y-1-i,X-1,Y-1-i);
   }

   for (j = 0; j < X; j++){
     fprintf(f,"%d\t%d\n",j,0);
   }

   fclose(f);
 }
