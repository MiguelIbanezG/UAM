#ifndef FIG_H
#define FIG_H
void f1(int X, int Y);
void f2(int X, int Y);
void f3(int X, int Y, int T);
void f4(int X, int Y);
void f5(int R);
void f6(int X, int Y);
#endif
