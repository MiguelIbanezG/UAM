
#include <stdio.h>
#include <stdlib.h>
#include "fig.h"

void f2(int X, int Y){
  int i, j;
  double slope;
  FILE *f;

  if (!(f=fopen("fig","w"))){
    printf("Error opening file.\n");
  }

  Y--;
  X--;

  slope = (double)Y/X;

  for (i = Y; i >= 0; i--){
    for (j = 0; j <= X; j++){
      if ((i+(slope)*j) <= Y){
        fprintf(f,"%d\t%d\n",j,i);
      }
    }
  }
  fclose(f);
}
