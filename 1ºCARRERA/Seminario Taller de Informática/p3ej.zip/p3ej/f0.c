#include <stdio.h> 
#include <stdlib.h> 

int func()
{
printf("\n"); 
return 1;
}
