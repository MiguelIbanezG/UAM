#include "elements.h"
#include "list.h"
#include "types.h"
#include <stdlib.h>

/**
 * @brief Public function that pushes an element into a sorted List.
 *
 * Inserts into the corresponding position the element received as argument.
 *
 * @param pl Pointer to the List.
 * @param e Element to be inserted into the List.
 * @param f Pointer to the compare function.

 *
 * @return Status value OK if the insertion could be done, Status value ERROR
 * otherwise.
 */
Status list_pushSorted(List *pl, const void *e, elem_cmp_fn elem_cmp) {
  return ERROR;
}

/**
 * @brief Public function that sorts an integer array.
 *
 *
 * @param array An integer array.
 * @param n_elem Size of array

 *
 * @return Status value OK if array sorted without problems, Status value ERROR
 * otherwise. The array is sorted in decreasing order upon return.
 */

Status sort_int_array(int *array, int n_elem) { return ERROR; }