/*Creado por Sergio Hidalgo, Programación 2, 213*/
#include <stdio.h>
#include <stdlib.h>
#include "queue.h"
#include "types.h"

/* Include here any other headers you need */

/**
 * @brief Returns a new queue that interleaves the elements in the first and 
 * second halves of a queue.
 *
 * Examples:
 *
 * Input:  [1, 2, 3, 4, 5, 6]
 * Output: [1, 4, 2, 5, 3, 6]
 *
 * Input:  [1, 2, 3, 4, 5]
 * Output: [1, 4, 2, 5, 3]
 *
 * @see https://www.geeksforgeeks.org/interleave-first-half-queue-second-half/
 *
 * @param q, pointer to the queue.
 *
 * @return A new queue with the elements in the first and second halves of q
 * interleaved. See example above.
 **/
Queue *interleave(Queue *q)
{
  Queue *qinter = NULL;
  int tam, i;
  char **cola1 = NULL, **cola2 = NULL;

  if (q == NULL)
  {
    return q;
  }
  

  qinter = queue_new();
  if (!qinter)
  {
    return NULL;
  }

  tam = (int)queue_size(q);

  if ((tam % 2) == 0)
  {

    cola1 = (char **)calloc((tam / 2), sizeof(int *));
    cola2 = (char **)calloc((tam / 2), sizeof(int *));

    for (i = 0; i < tam / 2; i++)
    {
      cola1[i] = queue_pop(q);
    }

    for (i = 0; i < tam / 2; i++)
    {
      cola2[i] = queue_pop(q);
    }

    for (i = 0; i < tam / 2; i++)
    {

      queue_push(qinter, cola1[i]);
      queue_push(qinter, cola2[i]);
    }
  }
  else
  {
    cola1 = (char **)calloc((tam / 2) + 1, sizeof(int *));
    cola2 = (char **)calloc((tam / 2), sizeof(int *));

    for (i = 0; i < (tam / 2) +1; i++)
    {
      cola1[i] = queue_pop(q);
    }

    for (i = 0; i < tam / 2; i++)
    {
      cola2[i] = queue_pop(q);
    }

    for (i = 0; i < (tam / 2); i++)
    {

      queue_push(qinter, cola1[i]);
      queue_push(qinter, cola2[i]);
    }
    queue_push(qinter, cola1[i]);

  }
    
    free (cola1);
    free (cola2);

    return qinter;
  }

  /**
 * @brief Concatenates two queues by adding all the elements in the second queue
 * to the first one. Upon successful exit the first queue will contain the 
 * elements from both queues and the second queue will be empty. In case of 
 * error the two queues will be unchanged.
 *
 * Example:
 *
 * Before concatenation: qa = [1, 2, 3, 4, 5, 6]
 *                       qb = [1, 2, 3, 4]
 *
 * After concatenation:  qa = [1, 2, 3, 4, 5, 6, 1, 2, 3, 4]
 *                       qb = []
 *
 * @param qa, pointer to the first queue.
 * @param qb, pointer to the second queue.
 *
 * @return OK on success, ERROR if there is any error. In case of error the 
 * contents of both queues must remain unchanged.
 **/
  Status concatenate(Queue * qa, Queue * qb)
  {
    int i;

    if (qb == NULL || qa == NULL)
    {
      return ERROR;
    }
    
    if (queue_size (qb) < queue_size (qa))
    {
        for (i = 0; i < queue_size (qb) ; i++)
      {
        queue_push (qa, queue_pop (qb));
      }
      queue_push (qa, queue_pop (qb));
    }
    else
    {
      for (i = 0; i < queue_size (qa) ; i++)
      {
        queue_push (qa, queue_pop (qb));
      }
      queue_push (qa, queue_pop (qb));
    }
    
    return OK;
  }
